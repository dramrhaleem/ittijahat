#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""تثبيت سكيل «كاتب مباحث الرسالة» في مجلدات المهارات على هذا الجهاز (كلود، وChatGPT/Codex)، ثم تهيئة مجلد العمل.

    python3 install_skill.py            # من داخل المجلد المفكوك من thesis-chapter-writer-skill.zip

يفعل ثلاثة أشياء: (١) ينسخ مجلد thesis-chapter-writer إلى ~/.agents/skills/ (المستوى العام) وإلى ./.agents/skills/ في مجلد العمل الحالي،
(٢) يشغّل scripts/setup.py الذي يهيّئ مجلد العمل «عدة_كتابة_المباحث» في المجلد الحالي ويفحص البيئة ويطبع تقريرًا عربيًّا،
(٣) يطبع الجملة التي يبدأ بها الباحث. لا يحتاج إلى شبكة، ولا يغيّر شيئًا خارج هذين المسارين.
"""
import os, sys, shutil, subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'thesis-chapter-writer')
if not os.path.isfile(os.path.join(SRC, 'SKILL.md')):
    sys.exit('لم أجد مجلد thesis-chapter-writer بجوار هذا الملف. فكّ الملف المضغوط كاملًا ثم أعد التشغيل.')

home = os.path.expanduser('~')
targets = [os.path.join(home, '.agents', 'skills', 'thesis-chapter-writer'),   # ChatGPT (Work) وCodex
           os.path.join(home, '.claude', 'skills', 'thesis-chapter-writer'),   # كلود على هذا الجهاز
           os.path.join(os.getcwd(), '.agents', 'skills', 'thesis-chapter-writer'),
           os.path.join(os.getcwd(), '.claude', 'skills', 'thesis-chapter-writer')]
done = []
for t in targets:
    if os.path.abspath(t) == os.path.abspath(SRC):
        continue
    try:
        os.makedirs(os.path.dirname(t), exist_ok=True)
        if os.path.isdir(t):
            shutil.rmtree(t)
        shutil.copytree(SRC, t, ignore=shutil.ignore_patterns('__pycache__', 'node_modules'))
        done.append(t)
    except Exception as e:
        print(f'⚠️  تعذّر النسخ إلى {t}: {e}')
print('✅ ثُبِّت السكيل في:')
for t in done:
    print('   ', t)

# تهيئة مجلد العمل في المجلد الحالي (ينسخ الأداة إلى ./عدة_كتابة_المباحث ويفحص البيئة)
setup = os.path.join(done[0] if done else SRC, 'scripts', 'setup.py')
print('\n… تهيئة مجلد العمل وفحص البيئة (قد تستغرق دقيقة):')
r = subprocess.run([sys.executable, setup])
if r.returncode != 0:
    print('\n⚠️  التهيئة فيها نقص؛ اقرأ التقرير أعلاه. إن كانت الشبكة أو الصلاحيات هي السبب فشغّل الفحص بلا تركيب:\n    '
          f'{sys.executable} "{os.path.join(done[0] if done else SRC, "scripts", "setup_gpt.py")}"')
print('\nتمّ. ابدأ الآن بكتابة: «ماذا تحمّل عندك؟» ثم «راجع التصنيف».')
