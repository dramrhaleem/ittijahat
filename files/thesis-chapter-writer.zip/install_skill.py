#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""تثبيت سكيل «كاتب مباحث الرسالة» على هذا الجهاز — يكتشف البيئة (كلود / ChatGPT-Codex) ويثبّت فيها وينظّف ويهيّئ.

    python3 install_skill.py                 # اكتشاف تلقائي
    python3 install_skill.py --env claude    # أو: --env chatgpt · --env both
    python3 install_skill.py --keep          # لا يحذف مجلد المصدر والملف المضغوط بعد التثبيت

ما يفعله: (١) يكتشف البيئة من متغيّراتها ومجلداتها، (٢) ينسخ السكيل إلى مجلد المهارات المناسب (~/.claude/skills أو ~/.agents/skills،
وداخل مجلد العمل الحالي أيضًا)، (٣) يحذف ما لا تحتاجه البيئة (ملفات مؤقتة، ووثائق البيئة الأخرى)، (٤) يشغّل scripts/setup.py الذي
ينشئ مجلد العمل «عدة_كتابة_المباحث» في المجلد الحالي ويفحص البيئة ويطبع تقريرًا عربيًّا، (٥) ينظّف المجلد الحالي من المصدر المفكوك
والملف المضغوط، (٦) يطبع الجملة التي يبدأ بها الباحث. لا يحتاج إلى شبكة.
"""
import os, sys, shutil, subprocess, glob, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'thesis-chapter-writer')
NAME = 'thesis-chapter-writer'


def detect_env():
    env = os.environ
    home = os.path.expanduser('~')
    claude = any(k in env for k in ('CLAUDECODE', 'CLAUDE_CODE_ENTRYPOINT', 'CLAUDE_CODE_SSE_PORT', 'ANTHROPIC_API_KEY')) \
        or 'claude' in (env.get('TERM_PROGRAM', '') + env.get('__CFBundleIdentifier', '')).lower()
    gpt = any(k in env for k in ('CODEX_SANDBOX', 'CODEX_HOME', 'OPENAI_API_KEY', 'CODEX_CI', 'CODEX_THREAD_ID')) \
        or os.path.isdir('/mnt/data') and os.path.exists('/mnt/data') and 'sandbox' in env.get('HOSTNAME', '')
    if claude and not gpt:
        return 'claude'
    if gpt and not claude:
        return 'chatgpt'
    # قرائن أضعف: أيّ المجلدين موجود في البيت
    has_claude = os.path.isdir(os.path.join(home, '.claude'))
    has_agents = os.path.isdir(os.path.join(home, '.agents')) or os.path.isdir(os.path.join(home, '.codex'))
    if has_claude and not has_agents:
        return 'claude'
    if has_agents and not has_claude:
        return 'chatgpt'
    return 'both'


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--env', choices=['auto', 'claude', 'chatgpt', 'both'], default='auto')
    ap.add_argument('--keep', action='store_true', help='لا يحذف مجلد المصدر والملف المضغوط بعد التثبيت')
    a = ap.parse_args()
    if not os.path.isfile(os.path.join(SRC, 'SKILL.md')):
        sys.exit('لم أجد مجلد thesis-chapter-writer بجوار هذا الملف. فكّ الملف المضغوط كاملًا ثم أعد التشغيل.')
    env = detect_env() if a.env == 'auto' else a.env
    label = {'claude': 'كلود', 'chatgpt': 'شات جي بي تي / كودكس', 'both': 'غير محدَّدة — سيُثبَّت للبيئتين'}[env]
    print(f'البيئة: {label}')

    home = os.path.expanduser('~'); cwd = os.getcwd()
    targets = []
    if env in ('claude', 'both'):
        targets += [os.path.join(home, '.claude', 'skills', NAME), os.path.join(cwd, '.claude', 'skills', NAME)]
    if env in ('chatgpt', 'both'):
        targets += [os.path.join(home, '.agents', 'skills', NAME), os.path.join(cwd, '.agents', 'skills', NAME)]

    # ما لا تحتاجه البيئة
    drop = ['__pycache__', 'node_modules', '.DS_Store', 'Thumbs.db']
    drop_paths = []
    if env == 'claude':
        drop_paths += ['agents', 'دليل_التشغيل_في_ChatGPT.md']
    ignore = shutil.ignore_patterns(*drop)
    done = []
    for t in targets:
        if os.path.abspath(t) == os.path.abspath(SRC):
            continue
        try:
            os.makedirs(os.path.dirname(t), exist_ok=True)
            if os.path.isdir(t):
                shutil.rmtree(t)
            shutil.copytree(SRC, t, ignore=ignore)
            for rel in drop_paths:
                p = os.path.join(t, rel)
                if os.path.isdir(p):
                    shutil.rmtree(p)
                elif os.path.isfile(p):
                    os.remove(p)
            done.append(t)
        except Exception as e:
            print(f'⚠️  تعذّر النسخ إلى {t}: {e}')
    if not done:
        sys.exit('لم يُثبَّت السكيل في أي مجلد.')
    print('✅ ثُبِّت السكيل في:')
    for t in done:
        print('   ', t)

    # تهيئة مجلد العمل في المجلد الحالي
    print('\n… تهيئة مجلد العمل وفحص البيئة (قد تستغرق دقيقة):')
    r = subprocess.run([sys.executable, os.path.join(done[0], 'scripts', 'setup.py')], cwd=cwd)
    if r.returncode != 0:
        print('\n⚠️  التهيئة فيها نقص؛ اقرأ التقرير أعلاه. فإن كان السبب الشبكة أو الصلاحيات فشغّل الفحص بلا تركيب:\n    '
              f'{sys.executable} "{os.path.join(done[0], "scripts", "setup_gpt.py")}"')

    # تنظيف المجلد الحالي: المصدر المفكوك والملف المضغوط
    if not a.keep:
        try:
            if os.path.abspath(HERE) != os.path.abspath(cwd) and HERE.startswith(cwd) and os.path.isdir(SRC):
                shutil.rmtree(HERE)          # الحزمة فُكّت في مجلد فرعي: يُحذف كله
            elif os.path.isdir(SRC):
                shutil.rmtree(SRC)           # الحزمة فُكّت في المجلد الحالي مباشرة: يُحذف مجلد المصدر فقط
            for z in glob.glob(os.path.join(cwd, 'thesis-chapter-writer*.zip')):
                os.remove(z)
            print('🧹 نُظِّف مجلد العمل من المصدر المفكوك والملف المضغوط؛ بقي مجلد «عدة_كتابة_المباحث» وحده.')
        except Exception as e:
            print(f'(لم يُنظَّف كل شيء: {e})')

    print('\nتمّ. ابدأ الآن بكتابة: «ماذا تحمّل عندك؟» ثم «راجع التصنيف».')


if __name__ == '__main__':
    main()
