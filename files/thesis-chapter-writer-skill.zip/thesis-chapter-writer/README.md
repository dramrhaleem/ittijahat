# أداة كتابة مباحث الرسالة

الأداة سكيلٌ واحد **«كاتب مباحث الرسالة»** — رسالة «الاتجاهات الحديثيّة في العقد الرابع من القرن
الخامس عشر الهجري في المملكة العربية السعودية».

**للاستعمال:** اقرأ `دليل_الاستخدام.md`. هذا الملف للبنية والتفاصيل التقنية.

---

## البدء

الأداة تُسلَّم **سكيلًا واحدًا** (`thesis-chapter-writer.skill`) يحفظه الباحث مرةً واحدة. مجلد السكيل قد يكون
للقراءة فقط، فأول أمر ينسخ الأداة إلى مجلد عمل:

```bash
python3 "<مجلد السكيل>/scripts/setup.py"   # ينسخ إلى ./عدة_كتابة_المباحث/ ثم يهيّئ ويفحص
cd عدة_كتابة_المباحث
python3 scripts/setup.py --check            # فحص فقط (من مجلد العمل)
```

وتُرفض نقاط الدخول (`stats.py`، `validate.py`، `resolve_qr.py`، `fetch_thesis.py`) إن شُغّلت داخل مجلد السكيل.

---

## البنية

```
دليل_الاستخدام.md              دليل الباحث — ابدأ منه
القرارات_المطلوبة.md            مسائل تنتظر قرار الباحث (وفي أولها حصيلة مراجعة التصنيف)
التغييرات.md                    سجلّ تغييرات الأداة

materials/                      وثائق الباحث الأصلية: القائمة الشاملة، وثيقة العيّنة (QR)، خطة البحث، أداة البحث، بطاقاته اليدوية (Excel)، قائمة رسائل الجرح

data/
  theses_norm.json              القائمة الشاملة بعد التوحيد — ١١٢١ رسالة
  theses_urls.json              رموز QR محلولة إلى روابط PDF مباشرة + بيانات كل صفّ (يبنيه resolve_qr.py)
  normalization_issues.tsv      الصفوف التي احتاجت توحيدًا أو فيها نقص
  clusters/<المبحث>.json        التصنيف الموضوعي: كل محور وعناوين رسائله
  samples/<المبحث>.json         عيّنة المبحث
  cards/<المبحث>/<رمز>.json     بطاقات التحليل المملوءة (٢٨ آلية) + manual_NN.json بطاقات الباحث اليدوية (١١، بوسم manual)
  تصنيف/سجل_النقل.tsv           كل نقلٍ بين المباحث (لا يُمحى)؛ والمعتمد.json التصنيف المعتمد ببصمته

references/
  flow.md                       تجربة الباحث: الوقفات الثلاث، شكل التقارير، الأسئلة بالأداة لا بالنص
  lexicon.md                    معجم الصيغ: الترجيح والنقد والمنهج — لا يُحكم على المعنى بغياب اللفظ
  structure.md                  تشريح المبحث: المطالب الأربعة وبنية كل عنصر وقواعد الحواشي
  style-profile.md              صوت الباحث: الإيقاع، العبارات المفصلية، المعجم، الممنوعات
  card-template.md              نصّ بطاقة التحليل وضوابط تطبيقها
  card-example.md               بطاقتان مملوءتان بقلم الباحث — النموذج المُحتذى
  muhaddith-mind.md             عقل المحدّث: مراتب الجرح والتعديل، ألفاظ محتملة، علوم الإسناد والمتن — يُقرأ قبل كل حكم
  mabahith-criteria.md          معايير المباحث السبعة عشر + ١٣ قاعدة حسم للتصنيف (المرجع عند كل نقلٍ أو مراجعة)
  classification-commands.md    أوامر التصنيف بالعربية: كيف تُفهم وتُنفَّذ وتُعرض نتائجها
  review-instructions.md        تعليمات وكيل مراجعة التصنيف (تُنسخ إلى out/تصنيف/in/ مع الدفعات)
  formatting.md                 معايير قالب إثراء المتون المطبَّقة في Word، وما افتُرض
  upload-guide.md               دليل رفع الملفات للباحث (بلا مصطلحات تقنية)

assets/fonts/                   خط Amiri مشحون مع الأداة (رخصة OFL) — الرسوم لا تعتمد على خطوط النظام
vendor/                         arabic_reshaper + python-bidi (نسخ بايثون خالصة، OFL/GPL) لبيئةٍ بلا pip مثل ChatGPT

scripts/
  setup.py                      تهيئة البيئة والتحقّق منها  ← ابدأ به
  validate.py                   فحص البيانات قبل الافتتاح وفحص المسوّدة قبل التسليم — قائمة فحوصه في رأسه
  fetch_thesis.py               تنزيل رسالة/مبحث من دليل الروابط + استخراج + حزمة قراءة
  stats.py                      أرقام المطلب الأول + الرسوم البيانية العربية
  normalize_data.py             توحيد القائمة الشاملة → theses_norm.json
  resolve_qr.py                 وثيقة العيّنة (QR) ← دليل الروابط + ملف عيّنة كل مبحث  ← عند غياب الدليل
  decode_qr.py                  (تستعمله resolve_qr.py) فكّ رموز QR وربطها بصفوفها
  extract_text.py               استخراج نصّ رسالة صفحةً صفحةً مع تصحيح انعكاس الحروف
  ocr_thesis.sh                 OCR للرسائل المصوَّرة، يبدأ بالمواضع المهمّة
  page_offset_ocr.py            تقدير الفرق بين رقم صفحة PDF والرقم المطبوع
  reading_pack.py               حزمة القراءة (مقدمة/فهرس/عيّنات متن/خاتمة)
  fill_card_prompt.md           تعليمات ملء البطاقة (تُعطى لوكيل فرعي)
  cards_to_xlsx.py              البطاقات → Excel (ملخص + ورقة لكل رسالة)
  import_manual_cards.py        بطاقات الباحث اليدوية (Excel) → data/cards/<المبحث>/manual_NN.json بوسم manual
  build_docx.js                 مسوّدة Markdown → Word عربي بقالب إثراء المتون (حواشٍ بقوسين، رقم الصفحة في الرأس، CH_TITLE)
  docx_to_pdf.sh                Word → PDF بـLibreOffice (مهلة ٢٤٠ ثانية، اسم مؤقّت لاتيني)
  html_to_pdf.py                صفحة HTML → PDF بمتصفّح Playwright وخط Amiri (القوائم والتقارير)
  md_to_pdf.py                  تقرير Markdown → PDF (عبر pandoc + html_to_pdf.py) — للتقارير والأدلة لا للمبحث
  classification.py             التصنيف: status · find · move · apply · verify · sync-check · approve · export · reanalyze
  classification_batches.py     يقسم القائمة دفعاتٍ (~٢٠٠) في out/تصنيف/in/ لوكلاء المراجعة
  classification_report.py      يجمع review_*.json → التقرير + Excel + القائمة المعلَّمة (Word/HTML) + العدّاد
  build_docx.py                 المولّد نفسه ببايثون خالص (OOXML مباشرة) — حيث لا نود، كبيئة ChatGPT
  setup_gpt.py                  تهيئة بيئة ChatGPT: فحص بلا تركيب، ونسخ vendor/ عند غياب الحزم
  state.py                      تصدير/استيراد حالة العمل (data/ وout/ وpacks/) في ملف واحد بين محادثات ChatGPT
  add_thesis.py                 تسجيل رسالة رفعها الباحث ملفًا (بلا شبكة) + استخراج نصّها وحزمة قراءتها

examples/                       ثلاثة مباحث مكتوبة بهذه الأداة — مسوّدات للمقابلة لا نصوص نهائية
out/<المبحث>/                   مخرجات جاهزة: stats.json + الرسوم
out/تصنيف/                      مخرجات المراجعة: التقرير، Excel، القائمة المعلَّمة، تقرير التطابق، حالة.json، in/ (الدفعات)
```

---

## أوامر التصنيف (سطر الأوامر)

```bash
python3 scripts/classification.py status                       # الجرد وحال الاعتماد وآخر نقل
python3 scripts/classification.py find "جزء من العنوان"          # المعرّف والمبحث والرمز
python3 scripts/classification.py move "1437/72" --to "علل الحديث" --reason "قال الباحث…"
python3 scripts/classification.py apply --rules 3,4            # تطبيق اقتراحات قواعد بعينها من الاقتراحات.json
python3 scripts/classification.py apply --ids 1433/12 1437/5   # أو رسائل بعينها؛ أو --all
python3 scripts/classification.py verify "علل الحديث"           # دفعة تحقّق لوكيل فرعي
python3 scripts/classification.py sync-check                   # تقرير التطابق قائمة/عيّنة/بطاقات
python3 scripts/classification.py approve --note "اعتمد"       # لقطة معتمدة ببصمة
python3 scripts/classification.py export                       # القائمة المصنَّفة Word/HTML/PDF
python3 scripts/classification.py reanalyze                    # إعادة الأرقام والرسوم وطبع البطاقات المعلَّمة

# المراجعة الكاملة
python3 scripts/classification_batches.py                      # الدفعات → out/تصنيف/in/
#   … وكيل فرعي لكل دفعة يكتب out/تصنيف/review_<الدفعة>.json
python3 scripts/classification_report.py                       # التقرير + Excel + المعلَّمة
python3 scripts/html_to_pdf.py "out/تصنيف/القائمة_المعلَّمة.html" "out/تصنيف/القائمة_المعلَّمة.pdf"
```

المعرّف القياسي للرسالة: `السنة/ترتيبها في جدول سنتها` (مثل `1437/72`)؛ لأن عمود «م» فارغٌ في ٩٣١ صفًّا من الأصل.

---

## أوامر متكرّرة

```bash
# أرقام مبحث ورسومه
python3 scripts/stats.py "علل الحديث"

# استعراض رسائل مبحث في دليل الروابط (بلا تنزيل)
python3 scripts/fetch_thesis.py --list "الجرح والتعديل"

# تنزيل رسالة واحدة + استخراج نصّها + حزمة قراءتها
python3 scripts/fetch_thesis.py SZ5LbY

# تنزيل رسائل مبحث كامل
python3 scripts/fetch_thesis.py --mabhath "مصطلح الحديث"

# رسالة بلا طبقة نصّ صالحة (صور)
mv ocr/SZ5LbY ocr/SZ5LbY_textlayer
bash scripts/ocr_thesis.sh theses/SZ5LbY.pdf ocr/SZ5LbY/ 2
python3 scripts/reading_pack.py SZ5LbY --pages-dir ocr/SZ5LbY --out packs/SZ5LbY

# بناء ملف Word
CH_MD=out/علل_الحديث.md CH_OUT=out/علل_الحديث \
CH_DOCX="out/الفصل_الأول_المبحث_الثاني_علل_الحديث.docx" node scripts/build_docx.js
```

---

## التحقّق بعد بناء Word

```bash
unzip -l "<الملف>.docx" | grep -c media                                # = عدد الرسوم
unzip -p "<الملف>.docx" word/footnotes.xml | grep -o "<w:footnote " | wc -l     # = عدد الحواشي + ٢
pandoc -t plain "<الملف>.docx" | grep -c "يوضع هنا"                     # = صفر
```

LibreOffice غير موثوق في هذه البيئة (يتعلّق، ويخفق مع أسماء الملفات العربية)، فالتحقّق
بـ`pandoc` و`unzip` لا بفتح الملف.

---

## مواضع الخطأ المعروفة

| الموضع | القاعدة |
|---|---|
| مطابقة العناوين آليًّا | **تخطئ.** يجب مقابلة صفّ الجدول بالعنوان المطابَق، والتحقّق من الغلاف — لا الاعتماد على درجة التشابه |
| ترقيم الصفحات | إن كانت `offset_confidence` منخفضة فحقّق الفرق بالعين. **رقم خاطئ في شاهد يُسقط الشاهد كله** |
| `ocr_thesis.sh` | يتخطّى كل صفحة لها ملف نصّ غير فارغ. انقل المجلد القديم قبل تشغيله |
| نصوص PDF العربية | حروف معكوسة: `اإل→الإ` `األ→الأ` `اال→الا` `امل→الم` `احل→الح` `اجل→الج` `خل→الخ` `يف→في` |
| أرقام OCR | لا تُعتمد إلا إذا تأيّدت من موضع آخر |
| مجموع المحاور | يجب أن يساوي مجموع رسائل المبحث بالضبط |
| السنة | **المعتمد سنة المناقشة** لا سنة التسجيل ولا بدء البحث |
| الحواشي | **ممنوع «المصدر نفسه» و«المرجع السابق»** — تُعاد الإحالة كاملة في كل موضع |
| المطلبان ٣ و٤ | من العيّنة حصرًا؛ لا يُعزى فيهما لرسالة خارجها |
| الحكم السلبي | لا يُحكم بغياب الترجيح أو النقد ببحثٍ لفظيّ — انظر `references/lexicon.md` |

---

## نسخة ChatGPT

المصدر واحد. تُبنى حزمة «جي بي تي مخصَّص» من هذا المجلد: `تعليمات_GPT_القصيرة.txt` (تُلصق في الإعدادات)، و`تعليمات_الأداة_ChatGPT.md`
(التعليمات الكاملة، تُقرأ في بداية كل محادثة)، والمجلد كله مضغوطًا `thesis-chapter-writer-gpt.zip` ملفَ معرفة. الخطوات في `دليل_إنشاء_GPT.md`،
واستعمال الباحث في `دليل_الاستخدام_ChatGPT.md`. الفروق: لا شبكة (رفع الرسائل ملفات)، لا وكلاء، لا OCR، لا PDF، وحالة العمل تُصدَّر بـ`state.py`.
**الملف المضغوط يُبنى ببايثون (`zipfile`) لا بأمر `zip`** حتى تبقى الأسماء العربية سليمة عند الفكّ.

## الاعتمادات

بايثون: `matplotlib` · `arabic-reshaper` · `python-bidi` · `pillow` · `pymupdf` · `openpyxl` · `python-docx` · `playwright` (لـPDF القوائم)
نود: `docx` (ومعه `jszip`)
سطر الأوامر: `poppler-utils` (pdftotext/pdftoppm/pdfimages) · `tesseract-ocr` + `tesseract-ocr-ara` · `libreoffice` (اختياري، لـPDF من Word)
الخطّ: `fonts-hosny-amiri`

`scripts/setup.py` يركّبها ويتحقّق منها.
