# -*- coding: utf-8 -*-
"""فكّ رموز QR من وثيقة العينة الإحصائية، وربط كل رمز بصفّه، واستخراج رابط PDF الرسالة.
الاستخدام:
  python3 scripts/decode_qr.py العينة.pdf --out qr/            # يفكّ الرموز ويربطها بالصفوف
المخرجات: qr/decoded.json (رمز لكل صورة)، qr/rows.json (الرمز + نص صفّه + المبحث والفترة)
ثم يُجلب رابط الـPDF لكل رمز من: https://scanned.page/api/qr-code?uId=<code>  (الحقل data.pdf)
"""
import sys, os, re, json, argparse, subprocess, glob, unicodedata
def decode(pdf, out):
    os.makedirs(out, exist_ok=True)
    import shutil
    if shutil.which('pdfimages'):
        subprocess.run(['pdfimages','-png',pdf,os.path.join(out,'img')],check=True)
    else:                                                   # بلا poppler (مثل ChatGPT): استخراج الصور بـpymupdf بالترتيب نفسه
        import pymupdf as fitz
        doc=fitz.open(pdf); k=0
        for pno in range(len(doc)):
            for im in doc[pno].get_images(full=True):
                pix=fitz.Pixmap(doc, im[0])
                if pix.n-pix.alpha>=4: pix=fitz.Pixmap(fitz.csRGB, pix)
                pix.save(os.path.join(out, f'img-{k:03d}.png')); k+=1
    import cv2
    try:
        from pyzbar.pyzbar import decode as zdec
    except Exception:
        zdec=None
    det=cv2.QRCodeDetector(); res={}
    for f in sorted(glob.glob(os.path.join(out,'img-*.png'))):
        img=cv2.imread(f); big=cv2.resize(img,None,fx=4,fy=4,interpolation=cv2.INTER_CUBIC)
        gray=cv2.cvtColor(big,cv2.COLOR_BGR2GRAY); _,thr=cv2.threshold(gray,128,255,cv2.THRESH_BINARY)
        v=None
        if zdec:
            d=zdec(thr)
            if d: v=d[0].data.decode('utf-8','replace')
        if not v:
            v,_,_=det.detectAndDecode(thr); v=v or None
        res[os.path.basename(f)]=v
    json.dump(res,open(os.path.join(out,'decoded.json'),'w'),ensure_ascii=False,indent=1)
    ok=sum(1 for v in res.values() if v)
    print(f'فُكّ {ok} من {len(res)} رمزًا')
    return res
def rows(pdf, out, res):
    import pymupdf as fitz
    BIDI=re.compile('[‪-‮⁦-⁩‎‏]')
    def norm(s): return BIDI.sub('',unicodedata.normalize('NFKC',s))
    doc=fitz.open(pdf); codes=[v.split('/')[-1] for v in res.values() if v]
    idx=0; out_rows=[]; mabhath=period=None
    for pno in range(len(doc)):
        page=doc[pno]; W=page.rect.width
        words=[(w[0],w[1],w[2],w[3],norm(w[4])) for w in page.get_text('words')]
        lines={}
        for w in words: lines.setdefault(round((w[1]+w[3])/2/3),[]).append(w)
        items=[]
        for k in sorted(lines):
            ws=sorted(lines[k],key=lambda w:-w[0])
            items.append((min(w[1] for w in ws), ' '.join(w[4] for w in ws)))
        ev=[(y,'hdr',t) for y,t in items if t.startswith('مبحث') or re.match(r'^(العلوم|عام\s*\d)',t)]
        ev+= [(w[1],'row',w[4]) for w in words if re.fullmatch(r'[1-5]',w[4]) and w[0]>0.80*W]
        ev.sort()
        imgs=[i['bbox'] for i in page.get_image_info()]
        for i,(y,kind,t) in enumerate(ev):
            if kind=='hdr':
                if t.startswith('مبحث'): mabhath=t
                elif t.startswith('عام'): period=t
                continue
            ynext=ev[i+1][0] if i+1<len(ev) else page.rect.height
            txt=' / '.join(x[1] for x in items if y-2<=x[0]<ynext-2 and not x[1].startswith(('عام','مبحث')))
            code=None
            for b in imgs:
                if b[1]>=y-2 and b[1]<ynext-2 and b[1]-y<8:
                    if idx<len(codes): code=codes[idx]; idx+=1
                    break
            out_rows.append(dict(page=pno+1,mabhath=mabhath,period=period,row=t,code=code,text=txt[:400]))
    json.dump(out_rows,open(os.path.join(out,'rows.json'),'w'),ensure_ascii=False,indent=1)
    print(f'رُبط {idx} رمزًا بصفوفها؛ المجموع {len(out_rows)} صفًّا')
    return out_rows
if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('pdf'); ap.add_argument('--out',default='qr')
    a=ap.parse_args(); rows(a.pdf,a.out,decode(a.pdf,a.out))
    print('\nلجلب رابط PDF لكل رمز: https://scanned.page/api/qr-code?uId=<code>  → الحقل data.pdf')
