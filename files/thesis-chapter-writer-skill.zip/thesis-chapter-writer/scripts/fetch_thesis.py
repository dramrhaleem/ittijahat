#!/usr/bin/env python3
"""ينزّل رسالةً (أو أكثر) من دليل الروابط، ويستخرج نصّها، ويبني حزمة القراءة.

    python3 scripts/fetch_thesis.py SZ5LbY
    python3 scripts/fetch_thesis.py --mabhath "الجرح والتعديل"     # كل رسائل المبحث
    python3 scripts/fetch_thesis.py --list "علل الحديث"            # عرض بلا تنزيل
    python3 scripts/fetch_thesis.py SZ5LbY --no-pack               # تنزيل فقط

المخرجات:  theses/<رمز>.pdf   ·   ocr/<رمز>/   ·   packs/<رمز>/
"""
import argparse
import json
import os
import subprocess
import sys
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# لا يعمل داخل مجلد السكيل (للقراءة فقط) — شغّل scripts/setup.py أولًا لينسخ الأداة إلى مجلد العمل
if "/skills/" in ROOT.replace("\\", "/") or not os.access(ROOT, os.W_OK):
    sys.exit("هذا مجلد السكيل لا مجلد العمل. شغّل أولًا: python3 \"" + os.path.join(ROOT, "scripts", "setup.py") + "\"  ثم اعمل داخل عدة_كتابة_المباحث/")
MAN = os.path.join(ROOT, "data", "theses_urls.json")

ap = argparse.ArgumentParser(add_help=True)
ap.add_argument("codes", nargs="*", help="رموز الرسائل")
ap.add_argument("--mabhath", help="تنزيل كل رسائل مبحث")
ap.add_argument("--list", dest="listing", nargs="?", const="", help="عرض دون تنزيل")
ap.add_argument("--no-pack", action="store_true", help="بلا استخراج نصّ ولا حزمة قراءة")
ap.add_argument("--out", default=ROOT)
a = ap.parse_args()

if not os.path.exists(MAN):
    sys.exit("دليل الروابط غير موجود: data/theses_urls.json")
man = json.load(open(MAN, encoding="utf-8"))


def norm(s):
    return (s or "").replace("ـ", "").replace("  ", " ").strip()


def pick(mab):
    key = norm(mab)
    out = []
    for c, v in man.items():
        m = norm(v.get("mabhath")) or norm(v.get("topic"))
        if key and key.replace("مبحث ", "") in m.replace("مبحث ", ""):
            out.append(c)
    return sorted(out)


if a.listing is not None:
    sel = pick(a.listing) if a.listing else sorted(man)
    print(f"{len(sel)} رسالة\n")
    for c in sel:
        v = man[c]
        print(f"{c}  {v.get('year','----')}  {(v.get('degree') or '')[:8]:8}  "
              f"{(v.get('university') or '')[:14]:14}  {(v.get('match_title') or '')[:60]}")
        if not v.get("pdf"):
            print("      ⚠️  لا رابط PDF لهذا الرمز")
    sys.exit(0)

codes = list(a.codes)
if a.mabhath:
    codes += pick(a.mabhath)
if not codes:
    sys.exit("حدّد رمزًا أو --mabhath أو --list")

os.makedirs(os.path.join(a.out, "theses"), exist_ok=True)
done, failed = [], []

for c in dict.fromkeys(codes):
    v = man.get(c)
    if not v:
        failed.append((c, "رمز غير موجود في الدليل"))
        continue
    url = v.get("pdf")
    if not url:
        failed.append((c, "لا رابط PDF"))
        continue
    pdf = os.path.join(a.out, "theses", c + ".pdf")
    if not (os.path.exists(pdf) and os.path.getsize(pdf) > 100000):
        print(f"… تنزيل {c}: {(v.get('match_title') or '')[:55]}", flush=True)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=180) as r, open(pdf, "wb") as f:
                while True:
                    b = r.read(1 << 20)
                    if not b:
                        break
                    f.write(b)
        except Exception as e:
            failed.append((c, f"تعذّر التنزيل: {e}"))
            continue
    mb = os.path.getsize(pdf) / 2**20
    print(f"  ✅ {c}.pdf ({mb:.1f} م.ب)", flush=True)

    if a.no_pack:
        done.append(c)
        continue

    pages = os.path.join(a.out, "ocr", c)
    subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "extract_text.py"), pdf, pages])
    txts = [f for f in os.listdir(pages)] if os.path.isdir(pages) else []
    chars = sum(os.path.getsize(os.path.join(pages, f)) for f in txts) if txts else 0
    if txts and chars / max(1, len(txts)) < 200:
        print(f"  ⚠️  {c}: طبقة النصّ شبه فارغة — الملف صور، يلزم OCR:", flush=True)
        print(f"      mv ocr/{c} ocr/{c}_textlayer && bash scripts/ocr_thesis.sh theses/{c}.pdf ocr/{c}/ 2")
    subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "reading_pack.py"), c,
                    "--pages-dir", pages, "--out", os.path.join(a.out, "packs", c)])
    done.append(c)

print()
print(f"تمّ: {len(done)}   —   أخفق: {len(failed)}")
for c, why in failed:
    print(f"  ❌ {c}: {why}")
