#!/usr/bin/env python3
"""تهيئة بيئة الأداة: يركّب ما ينقص، ويتحقّق أن كل شيء يعمل، ويطبع تقريرًا بالعربية.

    python3 scripts/setup.py            # تهيئة + فحص
    python3 scripts/setup.py --check    # فحص فقط دون تركيب

يُشغَّل مرة واحدة في أول جلسة، وإعادة تشغيله بلا ضرر.
"""
import glob
import json
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CHECK_ONLY = "--check" in sys.argv

# ── التمهيد: الأداة تعيش داخل مجلد السكيل (قد يكون للقراءة فقط ويُعاد تزامنه)،
#    فتُنسخ مرةً واحدة إلى مجلد عمل قابل للكتابة ويجري كل شيء فيه. ──────────────
WORK_NAME = "عدة_كتابة_المباحث"


def in_skill_dir(path):
    p = path.replace("\\", "/")
    return "/skills/" in p or "/.claude/" in p or not os.access(path, os.W_OK)


def find_workdir():
    """مجلد العمل: من البيئة، أو المجلد الحالي إن كان هو مجلد العمل (أو داخله)، وإلا ./عدة_كتابة_المباحث."""
    env = os.environ.get("THESIS_WORKDIR")
    if env:
        return env
    p = os.getcwd()
    while True:
        if os.path.basename(p) == WORK_NAME and os.path.isdir(os.path.join(p, "scripts")):
            return p
        parent = os.path.dirname(p)
        if parent == p:
            break
        p = parent
    return os.path.join(os.getcwd(), WORK_NAME)


if in_skill_dir(ROOT) or "--init" in sys.argv:
    work = find_workdir()
    if os.path.abspath(work) != os.path.abspath(ROOT):
        if not os.path.isdir(work):
            shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store", "node_modules"))
            print(f"نُسخت الأداة إلى مجلد العمل: {work}", flush=True)
        else:
            print(f"مجلد العمل موجود ويُستأنف فيه: {work}", flush=True)
        args = [a for a in sys.argv[1:] if a != "--init"]
        os.execv(sys.executable, [sys.executable, os.path.join(work, "scripts", "setup.py"), *args])

PY_PKGS = [
    ("matplotlib", "matplotlib"),
    ("arabic_reshaper", "arabic-reshaper"),
    ("bidi", "python-bidi"),
    ("PIL", "pillow"),
    ("fitz", "pymupdf"),
    ("cv2", "opencv-python-headless"),
    ("openpyxl", "openpyxl"),
    ("docx", "python-docx"),                          # القائمة المعلَّمة والمصنَّفة (Word) في مراجعة التصنيف
]
OPT_PY_PKGS = [("pyzbar", "pyzbar", "libzbar0"),     # يحسّن فكّ رموز QR؛ وبدونه يُستعمل كاشف OpenCV
               ("playwright", "playwright", "")]     # PDF للقوائم والتقارير (html_to_pdf.py)؛ يحتاج متصفّح Chromium
NODE_PKGS = [("docx", "docx")]
APT_FONTS = ["fonts-hosny-amiri", "fonts-noto-core"]
CLI_TOOLS = [
    ("pdftotext", "poppler-utils", "استخراج نصّ الرسائل"),
    ("pdftoppm", "poppler-utils", "تصيير صفحات للتحقّق من الترقيم"),
    ("pdfimages", "poppler-utils", "استخراج صور رموز QR"),
    ("tesseract", "tesseract-ocr tesseract-ocr-ara", "OCR للرسائل المصوَّرة"),
]

ok, warn, fail = [], [], []


def run(cmd, timeout=600):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except Exception as e:
        return 1, str(e)


def have_module(mod):
    return subprocess.run([sys.executable, "-c", f"import {mod}"],
                          capture_output=True).returncode == 0


# ── بايثون ──────────────────────────────────────────────────────────────
missing = [(m, p) for m, p in PY_PKGS if not have_module(m)]
if missing and not CHECK_ONLY:
    pkgs = " ".join(p for _, p in missing)
    print(f"… تركيب حزم بايثون: {pkgs}", flush=True)
    rc, out = run(f"{sys.executable} -m pip install --quiet --break-system-packages {pkgs}")
    if rc:
        rc, out = run(f"{sys.executable} -m pip install --quiet {pkgs}")
    missing = [(m, p) for m, p in PY_PKGS if not have_module(m)]
for m, p in PY_PKGS:
    (ok if have_module(m) else fail).append(f"بايثون · {p}")
for m, p, apt in OPT_PY_PKGS:
    if not have_module(m) and not CHECK_ONLY:
        if apt and shutil.which("apt-get"):
            run(f"apt-get install -y -qq {apt}", timeout=600)
        run(f"{sys.executable} -m pip install --quiet --break-system-packages {p}")
        if m == "playwright" and have_module(m):
            run(f"{sys.executable} -m playwright install chromium", timeout=900)
    note = {"pyzbar": " · اختياري؛ سيُستعمل كاشف OpenCV لرموز QR",
            "playwright": " · اختياري؛ بدونه تُسلَّم القوائم Word وHTML بلا PDF"}.get(m, " · اختياري")
    (ok if have_module(m) else warn).append(f"بايثون · {p}" + ("" if have_module(m) else note))

# ── نود ─────────────────────────────────────────────────────────────────
node_rc, node_v = run("node --version")
if node_rc:
    fail.append("نود · غير مركّب (يلزم لبناء ملفات Word)")
else:
    ok.append(f"نود · {node_v.strip()}")
    need_node = [n for mod, n in NODE_PKGS
                 if subprocess.run(f"node -e \"require('{mod}')\"", shell=True,
                                   capture_output=True, cwd=ROOT).returncode != 0]
    if need_node and not CHECK_ONLY:
        print(f"… تركيب حزم نود: {' '.join(need_node)}", flush=True)
        run(f"npm install --silent --no-fund --no-audit {' '.join(need_node)}", timeout=900)
    for mod, n in NODE_PKGS:
        good = subprocess.run(f"node -e \"require('{mod}')\"", shell=True,
                              capture_output=True, cwd=ROOT).returncode == 0
        (ok if good else fail).append(f"نود · {n}")

# ── الخطّ العربي ────────────────────────────────────────────────────────
def amiri_present():
    if glob.glob(os.path.join(ROOT, "assets", "fonts", "Amiri*.ttf")):
        return True                                   # مشحون مع الأداة؛ stats.py يسجّله بنفسه
    try:
        from matplotlib import font_manager
        return any("amiri" in (f.name or "").lower()
                   for f in font_manager.fontManager.ttflist)
    except Exception:
        return False


if not amiri_present() and not CHECK_ONLY and shutil.which("apt-get"):
    print("… تركيب خطّ Amiri العربي", flush=True)
    run(f"apt-get install -y -qq {' '.join(APT_FONTS)}", timeout=900)
    try:
        from matplotlib import font_manager
        font_manager._load_fontmanager(try_read_cache=False)
    except Exception:
        pass
(ok if amiri_present() else warn).append(
    "خطّ Amiri" + ("" if amiri_present() else " · غير موجود؛ الرسوم ستُبنى بخطّ بديل قد يقطّع الحروف"))

# ── أدوات سطر الأوامر ───────────────────────────────────────────────────
missing_cli = [(t, pkg, why) for t, pkg, why in CLI_TOOLS if not shutil.which(t)]
if missing_cli and not CHECK_ONLY and shutil.which("apt-get"):
    pkgs = " ".join(sorted({pkg for _, pkg, _ in missing_cli}))
    print(f"… تركيب أدوات: {pkgs}", flush=True)
    run("apt-get update -qq", timeout=600)
    run(f"apt-get install -y -qq {pkgs}", timeout=1200)
for t, pkg, why in CLI_TOOLS:
    (ok if shutil.which(t) else warn).append(f"{t} · {why}" + ("" if shutil.which(t) else " — مفقود"))
# حزمة العربية للتعرّف الضوئي — وجود الأداة لا يكفي
if shutil.which("tesseract"):
    def has_ara():
        rc, o = run("tesseract --list-langs")
        return "ara" in o.split()
    if not has_ara() and not CHECK_ONLY and shutil.which("apt-get"):
        print("… تركيب حزمة العربية للتعرّف الضوئي", flush=True)
        run("apt-get install -y -qq tesseract-ocr-ara", timeout=900)
    (ok if has_ara() else warn).append("tesseract · حزمة العربية (ara)" + ("" if has_ara() else " — مفقودة؛ التعرّف الضوئي سيخرج فارغًا"))

# ── سلامة البيانات ──────────────────────────────────────────────────────
def data_check():
    p = os.path.join(ROOT, "data", "theses_norm.json")
    if not os.path.exists(p):
        fail.append("data/theses_norm.json مفقود — الأداة ناقصة")
        return
    t = json.load(open(p, encoding="utf-8"))
    ok.append(f"قائمة الرسائل · {len(t)} رسالة")
    for sub, label in (("clusters", "تصنيفات موضوعية"),
                       ("samples", "عيّنات"),
                       ("cards", "مجلدات بطاقات")):
        d = os.path.join(ROOT, "data", sub)
        n = len(os.listdir(d)) if os.path.isdir(d) else 0
        ok.append(f"{label} · {n}")
    u = os.path.join(ROOT, "data", "theses_urls.json")
    if os.path.exists(u):
        m = json.load(open(u, encoding="utf-8"))
        n = sum(1 for v in m.values() if v.get("pdf"))
        ok.append(f"دليل روابط الرسائل · {n} من {len(m)} لها رابط PDF مباشر")
    else:
        mats = os.path.join(ROOT, "materials")
        pdfs = [f for f in os.listdir(mats)] if os.path.isdir(mats) else []
        warn.append("دليل روابط الرسائل · غير مبنيّ بعد — يُبنى من وثيقة العيّنة: "
                    "python3 scripts/resolve_qr.py materials/<وثيقة العيّنة>.pdf"
                    + (f"  (في materials/: {', '.join(pdfs[:4])})" if pdfs else ""))


data_check()

# ── حال التصنيف: هل اعتمد الباحث تصنيف القائمة؟ ──────────────────────
approved = os.path.join(ROOT, "data", "تصنيف", "المعتمد.json")
if os.path.isfile(approved):
    try:
        import json as _json
        _a = _json.load(open(approved, encoding="utf-8"))
        ok.append(f"تصنيف القائمة · معتمد ({_a.get('date', '')[:10]}) — أي نقلٍ بعده يظهر في classification.py status")
    except Exception:
        ok.append("تصنيف القائمة · معتمد")
else:
    warn.append("تصنيف القائمة · لم يُعتمد بعد — الترتيب الملزم: «راجع التصنيف» ← اعتماد ← «افحص التطابق» ← «اعتمد هذا التصنيف بالضبط» ← ثم الكتابة")

# ── فحص عملي من طرف إلى طرف ─────────────────────────────────────────────
if not CHECK_ONLY:
    rc, out = run(f'{sys.executable} "{ROOT}/scripts/stats.py" "علل الحديث"', timeout=600)
    if rc == 0:
        ok.append("فحص عملي · stats.py أنتج الأرقام والرسوم")
    else:
        fail.append("فحص عملي · stats.py أخفق:\n    " + out.strip().splitlines()[-1][:200])

# ── التقرير ─────────────────────────────────────────────────────────────
print()
print("=" * 56)
print("  تقرير تهيئة أداة كتابة المباحث")
print("=" * 56)
for x in ok:
    print("  ✅", x)
for x in warn:
    print("  ⚠️ ", x)
for x in fail:
    print("  ❌", x)
print("-" * 56)
print(f"  مجلد العمل: {ROOT}")
if fail:
    print("  الحالة: ناقصة — عالج ما عليه ❌ قبل البدء.")
elif warn:
    print("  الحالة: صالحة للعمل، مع ملحوظات ⚠️ (اقرأها؛ بعضها يؤثر في شكل المخرجات).")
else:
    print("  الحالة: جاهزة تمامًا. ابدأ بقول: «راجع التصنيف»، وبعد الاعتماد: «اكتب مبحث كذا».")
print("=" * 56)
sys.exit(1 if fail else 0)
