#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""تسجيل رسالةٍ رفعها الباحث ملفًا (بلا تنزيل من الشبكة): تُنسخ إلى theses/<الرمز>.pdf ويُستخرج نصّها وتُبنى حزمة قراءتها.

    python3 scripts/add_thesis.py <الملف.pdf> <الرمز>                 # رمز من دليل الروابط (مثل PvF2Vf)
    python3 scripts/add_thesis.py <الملف.pdf> --title "جزء من العنوان"   # رسالة بلا رمز: تُطابَق بالقائمة ويُصنع لها رمز

المخرجات كما في fetch_thesis.py: theses/<رمز>.pdf · ocr/<رمز>/ · packs/<رمز>/ — وتُضاف إلى data/theses_urls.json إن لم تكن فيه.
"""
import os, sys, re, json, shutil, argparse, subprocess, hashlib, difflib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)


def ntitle(s):
    s = re.sub(r'[ً-ْٰ]', '', str(s or '')); s = re.sub(r'[أإآ]', 'ا', s).replace('ة', 'ه').replace('ى', 'ي')
    return re.sub(r'\s+', ' ', re.sub(r'[^\w\s]', ' ', s)).strip()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('pdf'); ap.add_argument('code', nargs='?'); ap.add_argument('--title'); ap.add_argument('--no-pack', action='store_true')
    a = ap.parse_args()
    if not os.path.isfile(a.pdf):
        sys.exit(f'الملف غير موجود: {a.pdf}')
    urls_p = 'data/theses_urls.json'
    man = json.load(open(urls_p, encoding='utf-8')) if os.path.exists(urls_p) else {}
    rows = json.load(open('data/theses_norm.json', encoding='utf-8'))
    code = a.code
    if not code:
        if not a.title:
            sys.exit('حدّد الرمز أو --title')
        k = ntitle(a.title)
        # رمز موجود بعنوان مطابق؟
        for c, v in man.items():
            if k and k in ntitle(v.get('match_title') or ''):
                code = c; break
        if not code:
            best = difflib.get_close_matches(k, [ntitle(r['title']) for r in rows], n=1, cutoff=0.5)
            if not best:
                sys.exit('لم يُعثر على الرسالة في القائمة الشاملة؛ أعطني عنوانها كما في القائمة')
            row = next(r for r in rows if ntitle(r['title']) == best[0])
            code = 'L' + hashlib.sha1(best[0].encode()).hexdigest()[:5]
            man[code] = {'pdf': 'local', 'match_title': row['title'], 'year': row.get('year'), 'topic': row.get('topic_norm'),
                         'researcher': row.get('researcher'), 'university': row.get('university_norm'), 'degree': row.get('degree_norm'),
                         'source': 'رفعها الباحث ملفًا'}
            print(f'رسالة بلا رمز في العيّنة؛ صُنع لها الرمز {code} وطُوبقت بـ: {row["title"][:70]}')
    if code not in man:
        man[code] = {'pdf': 'local', 'match_title': a.title or os.path.basename(a.pdf), 'source': 'رفعها الباحث ملفًا'}
        print(f'الرمز {code} ليس في دليل الروابط؛ أُضيف بعنوان: {man[code]["match_title"][:70]}')
    elif not man[code].get('pdf'):
        man[code]['pdf'] = 'local'
    os.makedirs('theses', exist_ok=True)
    dst = os.path.join('theses', code + '.pdf')
    if os.path.abspath(a.pdf) != os.path.abspath(dst):
        shutil.copyfile(a.pdf, dst)
    json.dump(man, open(urls_p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'✅ theses/{code}.pdf ({os.path.getsize(dst) / 2**20:.1f} م.ب) — {man[code].get("match_title", "")[:60]}')
    if a.no_pack:
        return
    pages = os.path.join('ocr', code)
    subprocess.run([sys.executable, 'scripts/extract_text.py', dst, pages])
    txts = os.listdir(pages) if os.path.isdir(pages) else []
    chars = sum(os.path.getsize(os.path.join(pages, f)) for f in txts) if txts else 0
    if txts and chars / max(1, len(txts)) < 200:
        print(f'⚠️  {code}: طبقة النصّ شبه فارغة — الملف صورٌ على الأرجح؛ لا OCR في هذه البيئة. اطلب نسخةً نصّية أو اقرأ الصفحات صورًا.')
    subprocess.run([sys.executable, 'scripts/reading_pack.py', code, '--pages-dir', pages, '--out', os.path.join('packs', code)])


if __name__ == '__main__':
    main()
