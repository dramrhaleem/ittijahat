#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""تقرير Markdown عربي → PDF بلا متصفّح ولا pandoc (لبيئة ChatGPT): reportlab + خطّ Amiri المشحون + تشكيل عربي من vendor/.

    python3 scripts/pdf_rl.py <تقرير.md> <تقرير.pdf> [--title "سطر في رأس الصفحة"]

يدعم: العناوين (#، ##، ###)، الفقرات، القوائم (-، *، 1.)، الجداول |…|، الفواصل ---، واقتباسات >. العريض **…** يُطبع عاديًّا.
الجداول تُرسم من اليمين إلى اليسار بأعمدة تُقاس من محتواها، وتُكرَّر ترويستها في كل صفحة. يُستعمل احتياطًا في md_to_pdf.py
وclassification.py حين يغيب المتصفّح؛ والمبحث نفسه يُخرَج Word (build_docx.py) ثم PDF من Word.
"""
import os, re, sys, glob, argparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
try:
    import arabic_reshaper
    from bidi.algorithm import get_display
except ImportError:
    sys.path.insert(0, os.path.join(ROOT, 'vendor'))
    import arabic_reshaper
    from bidi.algorithm import get_display
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
M_L, M_R, M_T, M_B = 42, 42, 54, 48
TEXT_W = PAGE_W - M_L - M_R
FONT, FONT_B = 'Amiri', 'Amiri-Bold'
SIZES = {'h1': 18, 'h2': 15, 'h3': 13, 'p': 11.5, 'tbl': 9.5, 'foot': 9}
LEAD = 1.65
_reshaper = arabic_reshaper.ArabicReshaper({'delete_harakat': False, 'support_ligatures': True})


def register_fonts():
    d = os.path.join(ROOT, 'assets', 'fonts')
    reg = (glob.glob(os.path.join(d, 'Amiri-Regular*.ttf')) or glob.glob(os.path.join(d, 'Amiri*.ttf')))[0]
    bold = (glob.glob(os.path.join(d, 'Amiri-Bold*.ttf')) or [reg])[0]
    pdfmetrics.registerFont(TTFont(FONT, reg))
    pdfmetrics.registerFont(TTFont(FONT_B, bold))


def shape(s):
    return get_display(_reshaper.reshape(s))


def clean_inline(t):
    t = re.sub(r'\*\*(.+?)\*\*', r'\1', t)
    t = re.sub(r'`([^`]*)`', r'\1', t)
    t = re.sub(r'\[([^\]]+)\]\([^)]*\)', r'\1', t)
    return t.replace('\u00a0', ' ')


from functools import lru_cache


@lru_cache(maxsize=200000)
def _reshaped(w):
    return _reshaper.reshape(w)


@lru_cache(maxsize=200000)
def word_w(w, font, size):
    return pdfmetrics.stringWidth(_reshaped(w), font, size)


def wrap(text, font, size, width):
    """يقسم النصّ أسطرًا بحيث لا يتجاوز عرض السطر المتاح، بالقياس بعد التشكيل (عرض كل كلمة يُحسب مرة واحدة)."""
    words = text.split()
    lines, cur, cur_w = [], [], 0.0
    space = pdfmetrics.stringWidth(' ', font, size)
    for w in words:
        ww = word_w(w, font, size)
        if cur and cur_w + space + ww > width:
            lines.append(' '.join(cur)); cur, cur_w = [w], ww
        else:
            cur_w = cur_w + (space if cur else 0) + ww; cur.append(w)
    if cur:
        lines.append(' '.join(cur))
    return lines or ['']


class Doc:
    def __init__(self, path, title=''):
        self.c = canvas.Canvas(path, pagesize=A4)
        self.c.setTitle(title or os.path.basename(path))
        self.title = title
        self.y = PAGE_H - M_T
        self.page = 1
        self._header()

    def _header(self):
        if self.title:
            self.c.setFont(FONT, 9); self.c.setFillGray(0.35)
            self.c.drawRightString(PAGE_W - M_R, PAGE_H - 30, shape(self.title))
            self.c.setFillGray(0)
        self.c.setFont(FONT, SIZES['foot'])
        self.c.drawCentredString(PAGE_W / 2, M_B - 24, shape(str(self.page)))

    def new_page(self):
        self.c.showPage(); self.page += 1; self.y = PAGE_H - M_T; self._header()

    def need(self, h):
        if self.y - h < M_B:
            self.new_page()

    def line(self, text, font, size, indent=0, align='right'):
        self.c.setFont(font, size)
        if align == 'center':
            self.c.drawCentredString(PAGE_W / 2, self.y, shape(text))
        else:
            self.c.drawRightString(PAGE_W - M_R - indent, self.y, shape(text))
        self.y -= size * LEAD

    def para(self, text, font=FONT, size=None, indent=0, first_prefix=None, before=2, after=5, align='right'):
        size = size or SIZES['p']
        avail = TEXT_W - indent
        lines = wrap(text, font, size, avail)
        self.y -= before
        for i, ln in enumerate(lines):
            self.need(size * LEAD)
            if i == 0 and first_prefix:
                ln = first_prefix + ln
            self.line(ln, font, size, indent if (i or not first_prefix) else indent, align)
        self.y -= after

    def heading(self, level, text):
        size = SIZES['h1' if level == 1 else 'h2' if level == 2 else 'h3']
        self.need(size * 3)
        self.y -= size * (0.9 if level > 1 else 0.6)
        self.para(text, FONT_B, size, before=0, after=4 if level > 1 else 8, align='center' if level == 1 else 'right')
        if level == 2:
            self.c.setLineWidth(0.4); self.c.setStrokeGray(0.6)
            self.c.line(M_L, self.y + 4, PAGE_W - M_R, self.y + 4); self.c.setStrokeGray(0)
            self.y -= 4

    def rule(self):
        self.need(10); self.y -= 4
        self.c.setLineWidth(0.5); self.c.setStrokeGray(0.7); self.c.line(M_L, self.y, PAGE_W - M_R, self.y); self.c.setStrokeGray(0)
        self.y -= 8

    def table(self, rows):
        if not rows:
            return
        n = max(len(r) for r in rows)
        rows = [(r + [''] * n)[:n] for r in rows]
        size = SIZES['tbl']; pad = 3; lh = size * 1.55
        # عرض الأعمدة من طول المحتوى (بحد أدنى وأقصى)
        raw = [max(word_w(r[i][:60], FONT, size) + 2 * pad for r in rows) for i in range(n)]
        raw = [min(max(w, 28), TEXT_W * 0.55) for w in raw]
        # الحدّ الأدنى لكل عمود: أطول كلمة فيه (لا تُكسر الكلمة)
        minw = [min(max([word_w(w, FONT_B, size) for r in rows for w in r[i].split()] + [20]) + 2 * pad, TEXT_W * 0.35) for i in range(n)]
        k = TEXT_W / sum(raw); widths = [w * k for w in raw]
        for _ in range(3):
            fixed = [i for i in range(n) if widths[i] < minw[i]]
            if not fixed:
                break
            for i in fixed:
                widths[i] = minw[i]
            free = [i for i in range(n) if i not in fixed]
            rest = TEXT_W - sum(widths[i] for i in fixed)
            tot = sum(widths[i] for i in free) or 1
            for i in free:
                widths[i] = widths[i] * rest / tot
        # مواضع الأعمدة من اليمين إلى اليسار
        xs = []; x = PAGE_W - M_R
        for w in widths:
            xs.append((x - w, x)); x -= w

        def draw_row(cells, header=False):
            wrapped = [wrap(clean_inline(c), FONT_B if header else FONT, size, widths[i] - 2 * pad) for i, c in enumerate(cells)]
            h = max(len(w) for w in wrapped) * lh + 2 * pad
            self.need(h + 2)
            top = self.y
            if header:
                self.c.setFillGray(0.9); self.c.rect(M_L, top - h, TEXT_W, h, stroke=0, fill=1); self.c.setFillGray(0)
            self.c.setLineWidth(0.4); self.c.setStrokeGray(0.55)
            for i, (x0, x1) in enumerate(xs):
                self.c.rect(x0, top - h, x1 - x0, h, stroke=1, fill=0)
                self.c.setFont(FONT_B if header else FONT, size)
                yy = top - pad - size
                for ln in wrapped[i]:
                    self.c.drawRightString(x1 - pad, yy, shape(ln)); yy -= lh
            self.c.setStrokeGray(0)
            self.y = top - h

        header = rows[0]
        draw_row(header, header=True)
        for r in rows[1:]:
            before = self.page
            # إن انكسرت الصفحة قبل الصفّ فأعد الترويسة
            wrapped_h = max(len(wrap(clean_inline(c), FONT, size, widths[i] - 2 * pad)) for i, c in enumerate(r)) * lh + 2 * pad
            if self.y - wrapped_h < M_B:
                self.new_page(); draw_row(header, header=True)
            draw_row(r)
        self.y -= 8

    def save(self):
        self.c.save()


def render_md(md_path, pdf_path, title=''):
    register_fonts()
    d = Doc(pdf_path, title)
    lines = open(md_path, encoding='utf-8').read().split('\n')
    i = 0
    while i < len(lines):
        t = lines[i].rstrip()
        s = t.strip()
        if not s:
            i += 1; continue
        if s in ('---', '***', '___'):
            d.rule(); i += 1; continue
        m = re.match(r'^(#{1,6})\s+(.*)$', s)
        if m:
            d.heading(min(len(m.group(1)), 3), clean_inline(m.group(2))); i += 1; continue
        if s.startswith('|'):
            rows = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                r = lines[i].strip()
                if not re.fullmatch(r'\|[\s:\-|]+\|', r):
                    rows.append([c.strip() for c in r.strip('|').split('|')])
                i += 1
            d.table(rows); continue
        if s.startswith('>'):
            d.para(clean_inline(s.lstrip('> ')), indent=14, before=2, after=4); i += 1; continue
        m = re.match(r'^([-*•])\s+(.*)$', s)
        if m:
            d.para(clean_inline(m.group(2)), indent=16, first_prefix='• ', before=0, after=2); i += 1; continue
        m = re.match(r'^(\d+[.)])\s+(.*)$', s)
        if m:
            d.para(clean_inline(m.group(2)), indent=18, first_prefix=m.group(1) + ' ', before=0, after=2); i += 1; continue
        # فقرة قد تمتد على أسطر متتالية
        buf = [s]; i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r'^(#{1,6}\s|\||>|[-*•]\s|\d+[.)]\s|---)', lines[i].strip()):
            buf.append(lines[i].strip()); i += 1
        d.para(clean_inline(' '.join(buf)))
    d.save()
    return pdf_path


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('md'); ap.add_argument('pdf'); ap.add_argument('--title', default='')
    a = ap.parse_args()
    render_md(a.md, a.pdf, a.title)
    print('written', a.pdf, os.path.getsize(a.pdf))


if __name__ == '__main__':
    main()
