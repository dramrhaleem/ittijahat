#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""تهيئة الأداة في بيئة ChatGPT (مفسّر الشيفرة): لا شبكة، ولا pip، ولا نود — يفحص ما هو موجود ويطبع تقريرًا بالعربية.

    python3 scripts/setup_gpt.py            # فحص + تجربة عملية (stats.py)
    python3 scripts/setup_gpt.py --check    # فحص فقط

لا يركّب شيئًا؛ ما ينقص يُستبدل بالنسخ المشحونة في vendor/ أو يُصرَّح بغيابه (OCR، تنزيل الرسائل، PDF).
"""
import os, sys, glob, json, subprocess, socket

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
CHECK_ONLY = '--check' in sys.argv
ok, warn, fail = [], [], []


def have(mod):
    return subprocess.run([sys.executable, '-c', f'import {mod}'], capture_output=True).returncode == 0


# ── حزم بايثون اللازمة (موجودة عادةً في ChatGPT) ─────────────────────────
for mod, name, why in [('matplotlib', 'matplotlib', 'الرسوم البيانية'), ('openpyxl', 'openpyxl', 'ملفات Excel'),
                       ('docx', 'python-docx', 'القائمة المعلَّمة والمصنَّفة'), ('fitz', 'pymupdf', 'قراءة PDF'),
                       ('PIL', 'pillow', 'الصور')]:
    (ok if have(mod) else fail).append(f'بايثون · {name} — {why}')
for mod, name in [('cv2', 'opencv'), ('numpy', 'numpy')]:
    (ok if have(mod) else warn).append(f'بايثون · {name}' + ('' if have(mod) else ' · غائب؛ فكّ رموز QR غير متاح'))

# ── الحزم المشحونة (vendor/) ─────────────────────────────────────────────
vend = os.path.join(ROOT, 'vendor')
for mod in ['arabic_reshaper', 'bidi.algorithm']:
    if have(mod):
        ok.append(f'بايثون · {mod}')
    elif os.path.isdir(vend) and subprocess.run([sys.executable, '-c', f'import sys; sys.path.insert(0, {vend!r}); import {mod}'], capture_output=True).returncode == 0:
        ok.append(f'بايثون · {mod} (نسخة مشحونة في vendor/)')
    else:
        fail.append(f'بايثون · {mod} غائب ولا نسخة مشحونة — الرسوم العربية ستُقطَّع')

# ── الخط ──────────────────────────────────────────────────────────────────
(ok if glob.glob(os.path.join(ROOT, 'assets', 'fonts', 'Amiri*.ttf')) else fail).append('خطّ Amiri (assets/fonts/)')

# ── ما لا يتوفّر في ChatGPT (يُصرَّح به) ─────────────────────────────────
def has_net():
    try:
        socket.create_connection(('example.com', 80), timeout=3).close(); return True
    except Exception:
        return False
packs = sorted(d for d in glob.glob('packs/*') if os.path.isdir(d))
try:
    _u = json.load(open('data/theses_urls.json', encoding='utf-8')); _n_sample = len(_u)
except Exception:
    _n_sample = 0
if packs:
    ok.append(f'نصوص رسائل العيّنة · {len(packs)} من {_n_sample} محمَّلة سلفًا (packs/ وocr/) — لا تنزيل ولا رفع لرسائل العيّنة')
else:
    warn.append('نصوص رسائل العيّنة · غير محمَّلة — ارفع theses-text.zip في المعرفة، أو ارفع الرسائل PDF ثم add_thesis.py')
if has_net():
    ok.append('الشبكة · متاحة')
else:
    ok.append('الشبكة · غير متاحة (طبيعي هنا) — رسالة خارج العيّنة يرفعها الباحث PDF ثم: python3 scripts/add_thesis.py <الملف.pdf> <الرمز>')
import shutil
if shutil.which('tesseract'):
    ok.append('tesseract · OCR متاح')
else:
    ok.append('OCR · غير متاح هنا؛ رسائل العيّنة المصوَّرة مقروءة ضوئيًّا سلفًا، ورسالة جديدة مصوَّرة تُقرأ صفحاتها صورًا')
if shutil.which('node'):
    ok.append('نود · متاح (build_docx.js)')
else:
    ok.append('Word · بمولّد بايثون build_docx.py (لا يلزم نود)')
if have('reportlab'):
    ok.append('PDF · التقارير والقوائم بالمولّد البديل (reportlab)؛ المبحث يُحفظ PDF من Word')
else:
    warn.append('PDF · reportlab غائب — التقارير تُسلَّم Word/Markdown؛ المبحث يُحفظ PDF من Word')

# ── البيانات ──────────────────────────────────────────────────────────────
def data_check():
    p = os.path.join(ROOT, 'data', 'theses_norm.json')
    if not os.path.exists(p):
        fail.append('data/theses_norm.json مفقود — الأداة ناقصة'); return
    n = len(json.load(open(p, encoding='utf-8')))
    ok.append(f'قائمة الرسائل · {n} رسالة')
    ok.append(f'تصنيفات موضوعية · {len(glob.glob("data/clusters/*.json"))}')
    ok.append(f'عيّنات · {len(glob.glob("data/samples/*.json"))}')
    cards = glob.glob('data/cards/*/*.json')
    manual = [c for c in cards if os.path.basename(c).startswith('manual_')]
    ok.append(f'بطاقات · {len(cards) - len(manual)} من الأداة + {len(manual)} يدوية من الباحث')
    urls = os.path.join(ROOT, 'data', 'theses_urls.json')
    if os.path.exists(urls):
        u = json.load(open(urls, encoding='utf-8')); ok.append(f'دليل روابط الرسائل · {sum(1 for v in u.values() if v.get("pdf"))} من {len(u)} لها رابط')
    else:
        warn.append('دليل روابط الرسائل · غير مبنيّ — python3 scripts/resolve_qr.py materials/العينة_الإحصائية.pdf (فكّ الرموز يعمل بلا شبكة؛ الروابط تُعطى للباحث لينزّل الملفات)')
    ap = os.path.join(ROOT, 'data', 'تصنيف', 'المعتمد.json')
    if os.path.isfile(ap):
        ok.append('تصنيف القائمة · معتمد')
    else:
        warn.append('تصنيف القائمة · لم يُعتمد بعد — الترتيب: «راجع التصنيف» ← اعتماد ← «افحص التطابق» ← «اعتمد هذا التصنيف بالضبط» ← ثم الكتابة')
    th = glob.glob('theses/*.pdf')
    if th:
        ok.append(f'رسائل مرفوعة · {len(th)} ملف PDF')
data_check()

# ── تجربة عملية ───────────────────────────────────────────────────────────
if not CHECK_ONLY:
    r = subprocess.run([sys.executable, os.path.join(ROOT, 'scripts', 'stats.py'), 'علل الحديث'], capture_output=True, text=True, timeout=600)
    if r.returncode == 0:
        ok.append('فحص عملي · stats.py أنتج الأرقام والرسوم')
    else:
        fail.append('فحص عملي · stats.py أخفق:\n    ' + (r.stderr or r.stdout).strip().splitlines()[-1][:200])

print('\n' + '=' * 56 + '\n  تقرير تهيئة أداة كتابة المباحث — نسخة ChatGPT\n' + '=' * 56)
for x in ok: print('  ✅', x)
for x in warn: print('  ⚠️ ', x)
for x in fail: print('  ❌', x)
print('-' * 56 + f'\n  مجلد العمل: {ROOT}')
if fail:
    print('  الحالة: ناقصة — عالج ما عليه ❌ قبل البدء.')
else:
    print('  الحالة: صالحة للعمل. ابدأ بقول: «راجع التصنيف»، وبعد الاعتماد: «اكتب مبحث كذا».')
print('=' * 56)
sys.exit(1 if fail else 0)
