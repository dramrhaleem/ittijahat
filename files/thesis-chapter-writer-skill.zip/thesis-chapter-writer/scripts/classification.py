#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""أوامر التصنيف — نقل الرسائل بين المباحث، وتزامن العيّنة مع القائمة، والاعتماد، والإخراج.

    python3 scripts/classification.py status                              # عدّاد المباحث، وسجلّ النقل، وحال الاعتماد
    python3 scripts/classification.py find "جزء من العنوان"                # أين هذه الرسالة؟ (المعرّف والمبحث والرمز)
    python3 scripts/classification.py move "<معرّف أو جزء من العنوان>" --to "<المبحث>" [--reason "..."]
    python3 scripts/classification.py apply [--rules 3,4,10] [--ids 1433/12,1437/5] [--all] [--from out/تصنيف/الاقتراحات.json]
    python3 scripts/classification.py sync-check                          # تقرير تطابق القائمة والعيّنة → out/تصنيف/تقرير_التطابق.md
    python3 scripts/classification.py approve [--note "..."]              # تثبيت التصنيف الحالي مرجعًا → data/تصنيف/المعتمد.json
    python3 scripts/classification.py export                              # القائمة مصنَّفةً: out/تصنيف/القائمة_المصنفة.docx + .html (+ .pdf)
    python3 scripts/classification.py verify "<المبحث>" [--ids ...]      # يجهّز دفعة مراجعة مركّزة للوكيل: out/تصنيف/in/verify_<المبحث>.json
    python3 scripts/classification.py reanalyze [--mabhath "<المبحث>"]    # بعد النقل: تُحدَّث بطاقات الرسائل المنقولة وتُعاد الأرقام

القاعدة: الأداة تقترح، والباحث يعتمد، والأداة تنفّذ بعد الاعتماد. كل نقلٍ يُسجَّل في data/تصنيف/سجل_النقل.tsv ولا يُمحى.
النقل يمسّ القائمة (theses_norm.json) والتصنيف الموضوعي (clusters/) والعيّنة (samples/) والبطاقات (cards/) معًا — فلا يفترقان.
"""
import sys, os, re, json, glob, csv, shutil, argparse, datetime, collections, hashlib, subprocess, unicodedata

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
LIST = 'data/theses_norm.json'; LOG = 'data/تصنيف/سجل_النقل.tsv'; APPROVED = 'data/تصنيف/المعتمد.json'
MABAHITH = ['الجرح والتعديل','علل الحديث','الاتصال والانقطاع','فقه الحديث','الناسخ والمنسوخ','مشكل الحديث','مختلف الحديث',
            'غريب الحديث','الحديث الموضوعي','مصطلح الحديث','تحقيق الكتب الحديثية','الحديث التحليلي','الموضوعات البينية',
            'الدفاع عن السنة','مناهج المحدثين','جهود المحدثين','الاستدراك الحديثي']
TOPIC_RAW = {'مناهج المحدثين': 'مناهج المُحدِّثين', 'جهود المحدثين': 'جهود المُحدِّثين'}  # الرسم المستعمل في القائمة الأصلية

def strip_d(s): return re.sub(r'[ً-ْٰ]', '', str(s or ''))
def canon(t):
    t = strip_d(t).strip()
    for m in MABAHITH:
        if strip_d(m) == t: return m
    for m in MABAHITH:
        if t and (strip_d(m) in t or t in strip_d(m)) and len(t) >= 4: return m
    return None
def ntitle(s):
    s = strip_d(s); s = re.sub(r'[أإآ]', 'ا', s).replace('ة','ه').replace('ى','ي'); s = re.sub(r'[^\w\s]', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()
def fname(m): return m.replace(' ', '_')
def load_list(): return json.load(open(LIST, encoding='utf-8'))
def save_list(rows): json.dump(rows, open(LIST, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
def with_uid(rows):
    pos = collections.Counter()
    for r in rows:
        pos[r['year']] += 1; r['_uid'] = f"{r['year']}/{pos[r['year']]}"
    return rows
def topic_of(r): return canon(r.get('topic_norm')) or r.get('topic_norm') or 'غير مصنف'

# ---------- البحث عن رسالة ----------
AR_DIGITS = str.maketrans('٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹', '01234567890123456789')
def latin_digits(s): return str(s or '').translate(AR_DIGITS)   # الباحث قد يكتب المعرّف بالأرقام العربية: ١٤٣٧/٧٢

def find_rows(rows, key):
    key = latin_digits(key).strip()
    if re.fullmatch(r'1[34]\d\d/\d+', key): return [r for r in rows if r['_uid'] == key]
    if re.fullmatch(r'[A-Za-z0-9]{6}', key):
        for f in glob.glob('data/samples/*.json'):
            for s in json.load(open(f, encoding='utf-8')):
                if s['code'] == key:
                    hit = [r for r in rows if ntitle(r['title']) == ntitle(s['title'])]
                    if hit: return hit
    k = ntitle(key); exact = [r for r in rows if ntitle(r['title']) == k]
    if exact: return exact
    return [r for r in rows if k in ntitle(r['title'])]

def cmd_find(a):
    rows = with_uid(load_list()); hits = find_rows(rows, a.key)
    if not hits: print('لم أقف على رسالة بهذا المعرّف أو العنوان.'); return
    for r in hits: print(f"{r['_uid']} | {topic_of(r)} | {r['title']} | {r['university_norm']} | {r['degree_norm']}")

# ---------- النقل ----------
def sample_rows_all():
    out = {}
    for f in glob.glob('data/samples/*.json'): out[f] = json.load(open(f, encoding='utf-8'))
    return out

def move_one(rows, r, to, reason, by='الباحث', log=True):
    frm = topic_of(r)
    if to == frm: return False
    r['topic_norm'] = to; r['topic'] = TOPIC_RAW.get(to, to)
    nt = ntitle(r['title'])
    # التصنيف الموضوعي
    for m, mode in ((frm, 'del'), (to, 'add')):
        p = f'data/clusters/{fname(m)}.json'
        if not os.path.exists(p): continue
        cl = json.load(open(p, encoding='utf-8'))
        if mode == 'del':
            for k in list(cl):
                cl[k] = [t for t in cl[k] if ntitle(t) != nt]
                if not cl[k]: del cl[k]
        else:
            k = 'رسائل منقولة إلى هذا المبحث — تحتاج توزيعًا على المحاور'
            cl.setdefault(k, [])
            if not any(ntitle(t) == nt for v in cl.values() for t in v): cl[k].append(r['title'])
        json.dump(cl, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    # العيّنة: الصفّ ينتقل بكل حقوله
    for f, srows in sample_rows_all().items():
        hit = [s for s in srows if ntitle(s['title']) == nt]
        if not hit: continue
        rest = [s for s in srows if ntitle(s['title']) != nt]
        json.dump(rest, open(f, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        tgt = f'data/samples/{fname(to)}.json'
        trows = json.load(open(tgt, encoding='utf-8')) if os.path.exists(tgt) else []
        for s in hit:
            s['list_topic'] = to; s['moved_from'] = frm; s['moved_on'] = str(datetime.date.today()); trows.append(s)
        json.dump(trows, open(tgt, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    # البطاقات: تنتقل ويُحدَّث مبحثها
    src_dir = f'data/cards/{fname(frm)}'
    if os.path.isdir(src_dir):
        for cf in glob.glob(f'{src_dir}/*.json'):
            c = json.load(open(cf, encoding='utf-8'))
            if ntitle((c.get('meta') or {}).get('title', '')) == nt or ntitle((c.get('list_match') or {}).get('list_title', '')) == nt:
                c['meta']['mabhath'] = to; c.setdefault('moves', []).append(dict(frm=frm, to=to, on=str(datetime.date.today()), reason=reason))
                c['needs_reanalysis'] = True
                dst_dir = f'data/cards/{fname(to)}'; os.makedirs(dst_dir, exist_ok=True)
                json.dump(c, open(os.path.join(dst_dir, os.path.basename(cf)), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
                os.remove(cf)
    if log:
        os.makedirs('data/تصنيف', exist_ok=True); new = not os.path.exists(LOG)
        with open(LOG, 'a', encoding='utf-8') as f:
            if new: f.write('التاريخ\tالمعرّف\tالعنوان\tمن\tإلى\tالسبب\tبواسطة\n')
            f.write('\t'.join([str(datetime.date.today()), r['_uid'], r['title'], frm, to, reason or '', by]) + '\n')
    return True

def strip_uid(rows):
    for r in rows: r.pop('_uid', None)
    return rows

def cmd_move(a):
    to = canon(a.to)
    if not to: print(f'المبحث «{a.to}» ليس من المباحث السبعة عشر.'); sys.exit(2)
    rows = with_uid(load_list()); hits = find_rows(rows, a.key)
    if not hits: print('لم أقف على الرسالة.'); sys.exit(2)
    if len(hits) > 1 and not a.first:
        print('أكثر من رسالة تطابق؛ حدّد بالمعرّف:'); [print(f"  {r['_uid']} | {topic_of(r)} | {r['title'][:90]}") for r in hits]; sys.exit(2)
    r = hits[0]; frm = topic_of(r); uid = r['_uid']; title = r['title']
    if move_one(rows, r, to, a.reason): save_list(strip_uid(rows)); print(f"نُقلت: {uid} «{title[:70]}» من «{frm}» إلى «{to}». (القائمة والعيّنة والبطاقات والتصنيف الموضوعي)")
    else: print('الرسالة في هذا المبحث أصلًا.')
    cmd_status(a, quiet=True)

def cmd_apply(a):
    P = json.load(open(a.src, encoding='utf-8'))['proposals']
    sel = P
    if a.rules: rs = {int(latin_digits(x)) for x in a.rules.split(',')}; sel = [p for p in sel if str(p.get('rule')).isdigit() and int(p['rule']) in rs]
    if a.ids: ids = {latin_digits(x).strip() for x in a.ids.split(',')}; sel = [p for p in sel if p['uid'] in ids]
    if not (a.rules or a.ids or a.all): print('حدّد ما يُطبَّق: --rules أو --ids أو --all'); sys.exit(2)
    rows = with_uid(load_list()); byuid = {r['_uid']: r for r in rows}; n = 0
    for p in sel:
        r = byuid.get(p['uid'])
        if not r or ntitle(r['title']) != ntitle(p['title']): print('تجاوز (لم يطابق):', p['uid'], p['title'][:60]); continue
        if move_one(rows, r, canon(p['proposed']), f"اعتماد الباحث للاقتراح (القاعدة {p.get('rule')}): {p.get('reason','')}"): n += 1
    save_list(strip_uid(rows)); print(f'طُبِّق {n} نقلًا من {len(sel)} مختارًا.'); cmd_status(a, quiet=True)

# ---------- الحالة ----------
def cmd_status(a, quiet=False):
    rows = with_uid(load_list()); c = collections.Counter(topic_of(r) for r in rows)
    print('عدّاد المباحث الآن:')
    for m in MABAHITH + [t for t in c if t not in MABAHITH]:
        if c.get(m): print(f'  {c[m]:>4}  {m}')
    print(f'  {len(rows):>4}  المجموع')
    if os.path.exists(LOG):
        n = sum(1 for _ in open(LOG, encoding='utf-8')) - 1; print(f'سجلّ النقل: {n} نقلًا مسجَّلًا.')
    if os.path.exists(APPROVED):
        ap = json.load(open(APPROVED, encoding='utf-8')); cur = list_hash(rows)
        print(f"التصنيف المعتمد: بتاريخ {ap['date']} — " + ('مطابقٌ للحالي ✅' if ap['hash'] == cur else 'الحالي يختلف عنه (نُقل شيء بعد الاعتماد) ⚠️'))
    else: print('لا يوجد تصنيف معتمد بعد؛ اعتمده بالأمر approve بعد مراجعتك.')

def list_hash(rows): return hashlib.sha1('\n'.join(f"{r['_uid']}|{topic_of(r)}" for r in rows).encode()).hexdigest()[:12]

def cmd_approve(a):
    rows = with_uid(load_list()); c = collections.Counter(topic_of(r) for r in rows)
    os.makedirs('data/تصنيف', exist_ok=True)
    snap = dict(date=str(datetime.date.today()), note=a.note or '', hash=list_hash(rows), total=len(rows), counts=dict(c),
                rows=[dict(uid=r['_uid'], title=r['title'], topic=topic_of(r)) for r in rows])
    json.dump(snap, open(APPROVED, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f"اعتُمد التصنيف الحالي مرجعًا ({len(rows)} رسالة) بتاريخ {snap['date']}. أي تحليلٍ لاحق يبني عليه، وأي نقلٍ بعده يظهر في status.")

# ---------- التطابق بين القائمة والعيّنة ----------
def fix_lig(s):
    # ما يُخرجه استخراج نصّ وثيقة العيّنة من أشكال الحروف المتصلة
    s = unicodedata.normalize('NFKC', s)
    for a_, b_ in (('اجل', 'الج'), ('احل', 'الح'), ('اخل', 'الخ'), ('امل', 'الم'), ('اال', 'الا'), ('حل', 'حل')): s = s.replace(a_, b_)
    return s

def canon_letters(name):
    """اسم المبحث كما يُخرجه استخراج نصّ الوثيقة (حروف متصلة معكوسة) → الاسم المعتمد، بمطابقة مجموعة الحروف."""
    import difflib
    def key(s): return ''.join(sorted(re.sub(r'[\s\u064B-\u0652]', '', s)))
    best = max(MABAHITH, key=lambda m: difflib.SequenceMatcher(None, key(name), key(m)).ratio())
    r = difflib.SequenceMatcher(None, key(name), key(best)).ratio()
    if r >= 0.9: return best
    if 'التخريج' in name or 'الزوائد' in name or 'زوائد' in name: return 'التخريج والزوائد'
    return None

def sample_doc_counts():
    """عدد الرسائل وعدد العيّنة لكل مبحث كما في وثيقة العيّنة الإحصائية."""
    pdf = 'materials/العينة_الإحصائية.pdf'
    if not os.path.exists(pdf): return {}
    try: txt = subprocess.run(['pdftotext', '-layout', pdf, '-'], capture_output=True, text=True).stdout
    except Exception: return {}
    txt = fix_lig(re.sub('[‪-‮‎‏]', '', txt)); out = {}; cur = None
    for l in txt.split('\n'):
        m = re.search(r'مبحث\s+(.+?)\s*$', l.strip())
        if m and len(l.strip()) < 40:
            cur = canon_letters(m.group(1)) or m.group(1).strip()
            out.setdefault(cur, {}); continue
        m = re.search(r'عدد الرسائل\s*(\d+)', l)
        if m and cur is not None and 'المختارة' not in l: out[cur]['total'] = int(m.group(1))
        m = re.search(r'المختارة للعينة\s*(\d+)', l)
        if m and cur is not None: out[cur]['sample'] = int(m.group(1))
    return out

def cmd_sync(a):
    rows = with_uid(load_list()); by_nt = collections.defaultdict(list)
    for r in rows: by_nt[ntitle(r['title'])].append(r)
    L = ['# تقرير تطابق القائمة الشاملة مع العيّنة الإحصائية', f'التاريخ: {datetime.date.today()} · رسائل القائمة: {len(rows)}', '']
    probs = 0
    # (١) الأعداد لكل مبحث: القائمة مقابل وثيقة العيّنة مقابل العيّنة المبنية
    doc = sample_doc_counts(); built = {}
    for f in glob.glob('data/samples/*.json'):
        m = os.path.basename(f)[:-5].replace('_', ' '); built[canon(m) or m] = json.load(open(f, encoding='utf-8'))
    lc = collections.Counter(topic_of(r) for r in rows)
    L += ['## أولًا: الأعداد لكل مبحث', '', '| المبحث | القائمة الشاملة | وثيقة العيّنة | الفرق | عيّنة الوثيقة | العيّنة المبنية (برمز) |', '|---|---|---|---|---|---|']
    for m in MABAHITH + [t for t in doc if t not in MABAHITH]:
        a_ = lc.get(m, 0); d = doc.get(m, {}); b = len(built.get(m, []))
        diff = (a_ - d['total']) if 'total' in d else ''
        if diff not in ('', 0): probs += 1
        L.append(f"| {m} | {a_} | {d.get('total','—')} | {diff if diff != '' else '—'} | {d.get('sample','—')} | {b} |")
    L.append('')
    L.append('«وثيقة العيّنة» تعدّ «التخريج والزوائد» مبحثًا مستقلًّا وليس في القائمة ولا في خطة البحث؛ ورسائله في القائمة داخل «تحقيق الكتب الحديثية» (انظر وسوم مراجعة التصنيف).')
    # (٢) صفوف العيّنة التي لا تطابق القائمة
    L += ['', '## ثانيًا: صفوف في العيّنة لم تُطابق رسالةً في القائمة (أو طابقتها بضعف)', '']
    n2 = 0
    for m, srows in built.items():
        for s in srows:
            if s.get('score', 100) < 60 or ntitle(s['title']) not in by_nt:
                n2 += 1; L.append(f"- [{s['code']}] «{s['title'][:80]}» — درجة المطابقة {s.get('score')} — في عيّنة «{m}»")
    if not n2: L.append('لا شيء.')
    probs += n2
    # (٣) اختلاف المبحث بين القائمة والعيّنة
    L += ['', '## ثالثًا: رسائل مبحثها في العيّنة غير مبحثها في القائمة', '']
    n3 = 0
    for m, srows in built.items():
        for s in srows:
            hit = by_nt.get(ntitle(s['title']))
            if hit and topic_of(hit[0]) != m:
                n3 += 1; L.append(f"- [{s['code']}] «{s['title'][:80]}» — في العيّنة تحت «{m}» وفي القائمة تحت «{topic_of(hit[0])}»")
    if not n3: L.append('لا شيء — العيّنة متزامنة مع القائمة.')
    probs += n3
    # (٤) تكرار الرموز
    L += ['', '## رابعًا: رموز وصول مكرَّرة', '']
    codes = collections.Counter(s['code'] for srows in built.values() for s in srows if s.get('code'))
    dup = [(c, n) for c, n in codes.items() if n > 1]
    for c, n in dup: L.append(f'- {c}: {n} مرات')
    if not dup: L.append('لا شيء.')
    probs += len(dup)
    # (٥) عناوين مكرَّرة في القائمة
    L += ['', '## خامسًا: عناوين مكرَّرة حرفيًّا في القائمة', '']
    dt = [(k, v) for k, v in by_nt.items() if len(v) > 1]
    for k, v in dt: L.append(f"- «{v[0]['title'][:80]}» — {len(v)} مرات: " + '، '.join(r['_uid'] + ' (' + topic_of(r) + ')' for r in v))
    if not dt: L.append('لا شيء.')
    probs += len(dt)
    # (٦) رسائل بلا مبحث معتمد
    L += ['', '## سادسًا: رسائل مبحثها ليس من المباحث السبعة عشر', '']
    bad = [r for r in rows if topic_of(r) not in MABAHITH]
    for r in bad: L.append(f"- {r['_uid']} «{r['title'][:80]}» — «{topic_of(r)}»")
    if not bad: L.append('لا شيء.')
    probs += len(bad)
    # (٧) رموز في العيّنة تحتاج مراجعة من الغلاف
    L += ['', '## سابعًا: صفوف عيّنة معلَّمة «تحتاج مراجعة» (سنة أو مبحث أو مطابقة ضعيفة)', '']
    nr = [(m, s) for m, srows in built.items() for s in srows if s.get('needs_review')]
    for m, s in nr: L.append(f"- [{s['code']}] «{s['title'][:70]}» — عيّنة «{m}»")
    if not nr: L.append('لا شيء.')
    L += ['', f'**الحصيلة:** {probs} مسألة تحتاج نظرًا.' if probs else '**الحصيلة:** لا مسائل — الملفان متطابقان.']
    os.makedirs('out/تصنيف', exist_ok=True); open('out/تصنيف/تقرير_التطابق.md', 'w', encoding='utf-8').write('\n'.join(L))
    print('\n'.join(L[:40])); print(f'\n… كُتب التقرير كاملًا في out/تصنيف/تقرير_التطابق.md ({probs} مسألة)')

# ---------- الإخراج ----------
def cmd_export(a):
    from docx import Document
    from docx.shared import RGBColor
    rows = with_uid(load_list())
    doc = Document('materials/قائمة_الرسائل_الشاملة.docx')
    year_tables = [t for t in doc.tables if len(t.columns) in (9, 12)]; order = sorted(set(r['year'] for r in rows)); tbl = {}
    for t in year_tables:
        m = re.search(r'14\d\d', t.rows[0].cells[0].text); y = int(m.group()) if m else [yy for yy in order if yy not in tbl][0]; tbl[y] = t
    changed = 0
    for r in rows:
        t = tbl.get(r['year']); pos = int(r['_uid'].split('/')[1])
        if t is None or pos + 1 >= len(t.rows): continue
        row = t.rows[pos + 1]
        if ntitle(row.cells[1].text) != ntitle(r['title']): continue
        cell = row.cells[6]; want = TOPIC_RAW.get(topic_of(r), topic_of(r))
        if strip_d(cell.text.strip()) != strip_d(want):
            for par in cell.paragraphs[1:]: par._element.getparent().remove(par._element)
            p = cell.paragraphs[0]
            for run in p.runs[1:]: run._element.getparent().remove(run._element)
            if p.runs: p.runs[0].text = want
            else: p.add_run(want)
            changed += 1
    moved = 0
    if os.path.exists(LOG):
        with open(LOG, encoding='utf-8') as fh:
            moved = len({ln.split('\t')[1] for ln in fh.read().splitlines()[1:] if ln.strip()})
    first = doc.paragraphs[0]
    note = first.insert_paragraph_before(f"القائمة مصنَّفةً بعد اعتماد الباحث — {datetime.date.today()} — نُقلت ({moved}) رسالة بين المباحث، ووُحِّد رسم اسم المبحث في ({max(0, changed - moved)}) خانة. سجلّ النقل في الأداة.")
    for run in note.runs: run.bold = True
    os.makedirs('out/تصنيف', exist_ok=True); doc.save('out/تصنيف/القائمة_المصنفة.docx')
    # HTML → PDF
    norm = load_list()
    H = ['<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>القائمة المصنَّفة</title><style>',
         "body{font-family:'Amiri','Traditional Arabic',serif;font-size:12pt;margin:18mm 14mm} h1{font-size:16pt;text-align:center} h2{font-size:14pt;margin-top:18pt}",
         'table{border-collapse:collapse;width:100%;font-size:10.5pt} tr{page-break-inside:avoid} th,td{border:1px solid #999;padding:3pt 4pt;vertical-align:top} th{background:#e7ede3}',
         '</style></head><body><h1>قائمة الرسائل العلمية الشاملة — مصنَّفةً على المباحث</h1>',
         f'<p style="text-align:center">{datetime.date.today()} · {len(rows)} رسالة</p>']
    c = collections.Counter(topic_of(r) for r in rows)
    H.append('<table><thead><tr><th>المبحث</th><th>العدد</th></tr></thead><tbody>' + ''.join(f'<tr><td>{m}</td><td>{c[m]}</td></tr>' for m in MABAHITH + [t for t in c if t not in MABAHITH] if c.get(m)) + f'<tr><th>المجموع</th><th>{len(rows)}</th></tr></tbody></table>')
    for y in order:
        H.append(f'<h2>رسائل عام {y}هـ</h2><table><thead><tr><th>م</th><th>عنوان الرسالة</th><th>الباحث</th><th>الجامعة</th><th>الدرجة</th><th>نوع المبحث</th></tr></thead><tbody>')
        for r in [x for x in rows if x['year'] == y]:
            n = norm[rows.index(r)]
            H.append(f"<tr><td>{r['_uid'].split('/')[1]}</td><td>{r['title']}</td><td>{n['researcher']}</td><td>{n['university']}</td><td>{n['degree']}</td><td>{topic_of(r)}</td></tr>")
        H.append('</tbody></table>')
    H.append('</body></html>'); open('out/تصنيف/القائمة_المصنفة.html', 'w', encoding='utf-8').write('\n'.join(H))
    pdf_ok = False
    if os.path.exists('scripts/html_to_pdf.py'):
        rc = subprocess.run([sys.executable, 'scripts/html_to_pdf.py', 'out/تصنيف/القائمة_المصنفة.html', 'out/تصنيف/القائمة_المصنفة.pdf'], capture_output=True, text=True)
        pdf_ok = rc.returncode == 0
    if not pdf_ok:
        # بيئة بلا متصفّح (مثل ChatGPT): القائمة نفسها Markdown → PDF بالمولّد البديل reportlab
        try:
            M = ['# قائمة الرسائل العلمية الشاملة — مصنَّفةً على المباحث', f'{datetime.date.today()} · {len(rows)} رسالة', '',
                 '| المبحث | العدد |', '|---|---|'] + [f'| {m} | {c[m]} |' for m in MABAHITH + [t for t in c if t not in MABAHITH] if c.get(m)] + [f'| المجموع | {len(rows)} |', '']
            for y in order:
                M += [f'## رسائل عام {y}هـ', '', '| م | عنوان الرسالة | الباحث | الجامعة | الدرجة | نوع المبحث |', '|---|---|---|---|---|---|']
                for r in [x for x in rows if x['year'] == y]:
                    n = norm[rows.index(r)]
                    M.append(f"| {r['_uid'].split('/')[1]} | {r['title']} | {n['researcher']} | {n['university']} | {n['degree']} | {topic_of(r)} |")
                M.append('')
            open('out/تصنيف/القائمة_المصنفة.md', 'w', encoding='utf-8').write('\n'.join(M))
            sys.path.insert(0, 'scripts'); import pdf_rl
            pdf_rl.render_md('out/تصنيف/القائمة_المصنفة.md', 'out/تصنيف/القائمة_المصنفة.pdf', 'القائمة المصنَّفة')
            pdf_ok = True
        except Exception as e:
            print('(تعذّر PDF بالمولّد البديل:', e, ')')
    print(f'كُتبت القائمة المصنَّفة: out/تصنيف/القائمة_المصنفة.docx (نُقلت {moved} رسالة، ووُحِّد رسم المبحث في {max(0, changed - moved)} خانة)' + (' و.pdf' if pdf_ok else ' و.html (تعذّر PDF)'))

# ---------- دفعة تحقّق مركّزة ----------
def cmd_verify(a):
    rows = with_uid(load_list()); m = canon(a.mabhath)
    if not m: print('مبحث غير معروف'); sys.exit(2)
    sel = [r for r in rows if topic_of(r) == m]
    if a.ids: ids = {latin_digits(x).strip() for x in a.ids.split(',')}; sel = [r for r in rows if r['_uid'] in ids]
    codes = {}
    for f in glob.glob('data/samples/*.json'):
        for s in json.load(open(f, encoding='utf-8')): codes[ntitle(s['title'])] = s['code']
    batch = [dict(id=r['_uid'], code=codes.get(ntitle(r['title']), ''), title=r['title'], current=topic_of(r)) for r in sel]
    os.makedirs('out/تصنيف/in', exist_ok=True); p = f'out/تصنيف/in/verify_{fname(m)}.json'
    json.dump(batch, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    print(f'جُهّزت دفعة تحقّق: {p} ({len(batch)} رسالة). يراجعها الوكيل بتعليمات out/تصنيف/in/تعليمات_المراجعة.md ويكتب review_verify.json ثم classification_report.py.')

# ---------- إعادة التحليل بعد النقل ----------
def cmd_reanalyze(a):
    todo = []
    for cf in glob.glob('data/cards/*/*.json'):
        c = json.load(open(cf, encoding='utf-8'))
        if c.get('needs_reanalysis'): todo.append((cf, c))
    mab = canon(a.mabhath) if a.mabhath else None
    affected = set()
    for cf, c in todo:
        if mab and c['meta'].get('mabhath') != mab: continue
        affected.add(c['meta'].get('mabhath'))
        for mv in c.get('moves', []): affected.add(mv['frm'])
        print(f"بطاقة تحتاج إعادة تحليل تحت مبحثها الجديد «{c['meta'].get('mabhath')}»: {os.path.basename(cf)} — {c['meta'].get('title','')[:60]}")
    if not todo: print('لا بطاقات معلَّمة لإعادة التحليل.')
    for m in sorted(x for x in affected if x):
        rc = subprocess.run([sys.executable, 'scripts/stats.py', m], capture_output=True, text=True)
        print(f'أُعيدت أرقام «{m}»' + ('' if rc.returncode == 0 else ' — تعذّر: ' + rc.stderr[-200:]))
    print('التالي: لكل بطاقةٍ أعلاه، يعيد الوكيل ملء chapter_notes بمنظور المبحث الجديد (scripts/fill_card_prompt.md)، ثم يُزال العلَم needs_reanalysis.')

def write_state(cmd):
    """out/تصنيف/حالة.json — آخر أمر، وعدّاد المباحث، وحال الاعتماد، وما ينتظر من الاقتراحات (لأمر «فين وصلنا؟»)."""
    try:
        rows = with_uid(load_list()); c = collections.Counter(topic_of(r) for r in rows)
        st = {'last_command': cmd, 'at': datetime.datetime.now().isoformat(timespec='minutes'),
              'total': len(rows), 'counters': dict(c), 'moves_logged': 0, 'approved': None, 'pending_proposals': None}
        if os.path.exists(LOG): st['moves_logged'] = max(0, sum(1 for _ in open(LOG, encoding='utf-8')) - 1)
        if os.path.exists(APPROVED):
            ap = json.load(open(APPROVED, encoding='utf-8'))
            st['approved'] = {'date': ap.get('date'), 'hash': ap.get('hash'), 'matches_current': ap.get('hash') == list_hash(rows)}
        src = 'out/تصنيف/الاقتراحات.json'
        if os.path.exists(src):
            pr = json.load(open(src, encoding='utf-8')).get('proposals', [])
            cur = {r['_uid']: topic_of(r) for r in rows}
            pend = [p for p in pr if canon(cur.get(p.get('uid'))) == canon(p.get('current')) or cur.get(p.get('uid')) == p.get('current')]
            st['pending_proposals'] = len(pend); st['proposals_total'] = len(pr)
            st['pending_by_rule'] = dict(collections.Counter(str(p.get('rule')) for p in pend))
        st['next'] = ('«اعتمد هذا التصنيف بالضبط» أو تابع الكتابة' if st['approved'] and st['approved']['matches_current']
                      else 'اعتماد الاقتراحات المنتظرة أو رفضها، ثم «افحص التطابق»، ثم «اعتمد هذا التصنيف بالضبط»')
        os.makedirs('out/تصنيف', exist_ok=True)
        json.dump(st, open('out/تصنيف/حالة.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    except Exception as e:
        print(f'(تعذّر تحديث حالة.json: {e})', file=sys.stderr)

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter); sp = ap.add_subparsers(dest='cmd')
    s = sp.add_parser('status'); s.set_defaults(f=cmd_status)
    s = sp.add_parser('find'); s.add_argument('key'); s.set_defaults(f=cmd_find)
    s = sp.add_parser('move'); s.add_argument('key'); s.add_argument('--to', required=True); s.add_argument('--reason', default=''); s.add_argument('--first', action='store_true'); s.set_defaults(f=cmd_move)
    s = sp.add_parser('apply'); s.add_argument('--from', dest='src', default='out/تصنيف/الاقتراحات.json'); s.add_argument('--rules'); s.add_argument('--ids'); s.add_argument('--all', action='store_true'); s.set_defaults(f=cmd_apply)
    s = sp.add_parser('sync-check'); s.set_defaults(f=cmd_sync)
    s = sp.add_parser('approve'); s.add_argument('--note', default=''); s.set_defaults(f=cmd_approve)
    s = sp.add_parser('export'); s.set_defaults(f=cmd_export)
    s = sp.add_parser('verify'); s.add_argument('mabhath'); s.add_argument('--ids'); s.set_defaults(f=cmd_verify)
    s = sp.add_parser('reanalyze'); s.add_argument('--mabhath'); s.set_defaults(f=cmd_reanalyze)
    a = ap.parse_args()
    if not a.cmd: ap.print_help(); return
    a.f(a)
    write_state(' '.join(sys.argv[1:]))
if __name__ == '__main__': main()
