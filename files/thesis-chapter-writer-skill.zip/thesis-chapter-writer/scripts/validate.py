#!/usr/bin/env python3
"""فحص مبحثٍ قبل عرضه وقبل تسليمه. يُبلغ ولا يعدّل (يكتب ملفًا واحدًا: `out/<المبحث>/ترحيل.tsv`).

    python3 scripts/validate.py "علل الحديث"                    # فحص البيانات (قبل الوقفة الأولى)
    python3 scripts/validate.py "علل الحديث" out/علل_الحديث.md    # + فحص المسوّدة (قبل التسليم)
    python3 scripts/validate.py "علل الحديث" out/علل_الحديث.md --docx out/الملف.docx   # + فحص ملف Word

فحوص البيانات: انتماء الرسائل لمبحثها (وما يُقترح ترحيله من المبحث وإليه) · السنوات وسنة الغلاف ·
حجم العيّنة ونسبتها · هوية الرسائل (عنوان الغلاف مقابل القائمة).
فحوص المسوّدة: أرقام المطلب الأول مقابل stats.json · تقيّد المطلبين الثالث والرابع بالعيّنة ·
الحواشي (لا «مصدر نفسه»، وحاشية ببليوغرافية عند أول ذكر) · الألفاظ الحادّة · الجزم فيما يحتمل
الاحتراز · بنية المطلب الرابع · «خلاصة المبحث» ووجودها وخلوّها من رقم جديد · الأحكام السلبية على الترجيح ·
التعميمات العددية مقابل ورقة الأدلة · نسب الجداول · آثار الأداة (رموز، روابط، نُسخ، تعذُّر وقوف) · وملف Word (لا علامات Markdown).
"""
import glob
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# لا يعمل داخل مجلد السكيل (للقراءة فقط) — شغّل scripts/setup.py أولًا لينسخ الأداة إلى مجلد العمل
if "/skills/" in ROOT.replace("\\", "/") or not os.access(ROOT, os.W_OK):
    sys.exit("هذا مجلد السكيل لا مجلد العمل. شغّل أولًا: python3 \"" + os.path.join(ROOT, "scripts", "setup.py") + "\"  ثم اعمل داخل عدة_كتابة_المباحث/")
MABHATH = sys.argv[1].strip() if len(sys.argv) > 1 else sys.exit("حدّد اسم المبحث")
DRAFT = sys.argv[2] if len(sys.argv) > 2 and not sys.argv[2].startswith("--") else None
SLUG = MABHATH.replace(" ", "_")
OUT = os.path.join(ROOT, "out", SLUG)

theses = json.load(open(os.path.join(ROOT, "data", "theses_norm.json"), encoding="utf-8"))
TOPIC = next((k for k in theses[0] if k in ("مبحث", "topic", "المبحث")), "topic")
TITLE = next((k for k in theses[0] if k in ("العنوان", "title")), "title")
YEAR = next((k for k in theses[0] if k in ("السنة", "year")), "year")
mine = [t for t in theses if (t.get(TOPIC) or "").strip() == MABHATH]

findings = []          # (النوع، العنوان، [تفاصيل])
passed = []            # سطور ✅


def flag(kind, head, details=()):
    findings.append((kind, head, list(details)))


def ok(line):
    passed.append(line)


# ───────────────────────────── أدوات نصّية ─────────────────────────────
_TASHKEEL = re.compile(r"[ً-ْٰـ]")


def norm(s):
    """يوحّد الهمزات والياء والتاء، ويحذف التشكيل والترقيم."""
    s = _TASHKEEL.sub("", s or "")
    s = re.sub(r"[أإآ]", "ا", s).replace("ى", "ي").replace("ة", "ه").replace("ؤ", "و").replace("ئ", "ي")
    s = re.sub(r"[^ء-ي0-9 ]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


_STOP = {"في", "من", "على", "عن", "الى", "او", "مع", "بن", "ابن", "كتاب", "كتب", "دراسه", "جمعا",
         "وتخريجا", "ودراسه", "تخريجا", "الامام", "التي", "الذي", "قسم", "القسم", "الاول", "الثاني",
         "الثالث", "رحمه", "الله", "عنه", "رضي"}


def toks(s):
    return {w for w in norm(s).split() if len(w) > 2 and w not in _STOP}


def overlap(a, b):
    """نسبة كلمات (أ) الموجودة في (ب)."""
    ta, tb = toks(a), toks(b)
    return len(ta & tb) / len(ta) if ta else 0.0


def contains(a, b):
    """احتواء متبادل: يقبل أن يكون أحد العنوانين صورةً أوفى من الآخر."""
    ta, tb = toks(a), toks(b)
    if not ta or not tb:
        return 0.0
    return max(len(ta & tb) / len(ta), len(ta & tb) / len(tb))


def strip_quotes_and_notes(md):
    """يحذف الحواشي ^[…] والاقتباسات «…» — فلا يُحاسَب نصُّ غيرنا على نبرته."""
    out, i, n = [], 0, len(md)
    while i < n:
        if md.startswith("^[", i):
            d, j = 1, i + 2
            while j < n and d:
                d += (md[j] == "[") - (md[j] == "]")
                j += 1
            i = j
        elif md[i] == "«":
            j = md.find("»", i)
            i = n if j == -1 else j + 1
        else:
            out.append(md[i])
            i += 1
    return "".join(out)


def footnotes_in(seg):
    res, i, n = [], 0, len(seg)
    while i < n:
        if seg.startswith("^[", i):
            d, j = 1, i + 2
            while j < n and d:
                d += (seg[j] == "[") - (seg[j] == "]")
                j += 1
            res.append(seg[i + 2:j - 1])
            i = j
        else:
            i += 1
    return res


def leaves(o, acc):
    """كل الأعداد الصحيحة في بنية JSON."""
    if isinstance(o, dict):
        for v in o.values():
            leaves(v, acc)
    elif isinstance(o, list):
        for v in o:
            leaves(v, acc)
    elif isinstance(o, (int, float)) and float(o).is_integer():
        acc.append(int(o))
    return acc


def heading_pos(md, key):
    """موضع ترويسة Markdown تحمل النص (## key)، وإلا أول ورود له."""
    m = re.search(r"(?m)^#{1,4}\s*" + re.escape(key), md)
    return m.start() if m else md.find(key)


def section(md, start_key, end_keys):
    a = heading_pos(md, start_key)
    if a < 0:
        return ""
    ends = [heading_pos(md[a + len(start_key):], k) for k in end_keys]
    ends = [a + len(start_key) + e for e in ends if e >= 0]
    return md[a:min(ends)] if ends else md[a:]


# ═════════════════════════ (أ) فحوص البيانات ═════════════════════════
print(f"مبحث «{MABHATH}» — {len(mine)} رسالة في القائمة الشاملة")

# ── ١) الانتماء: دلائل لفظية لكل مبحث. الغياب ترشيحٌ للمراجعة لا حكم ──
CUES = {
    "الجرح والتعديل": ["جرح", "تعديل", "الرواة", "طبقات الروا", "ثقة", "الثقات", "صدوق", "مقبول",
                        "مجهول", "الكاشف", "التقريب", "التهذيب", "ميزان", "مروايات", "مروياته",
                        "مرويات", "توثيق", "وثقه", "ضعفه", "تراجم", "الراوي", "أصحاب الإمام",
                        "لا بأس به", "علم الرجال", "المؤتلف", "المختلف", "المتشابه", "الكنى",
                        "الأنساب", "الجمع والتفريق", "المدلسين", "الأكابر عن الأصاغر", "سماعهم",
                        "المكثرين", "المقلين", "الإمام عاصم"],
    "علل الحديث": ["علل", "العلل", "أعل", "الأحاديث التي أعل", "إعلال", "المعل", "معلول", "معلّ", "التعليل", "علة",
                    "خولف", "الاختلاف على", "الاختلاف في", "الوهم", "المحفوظ", "الشاذ", "المنكر",
                    "ضعفها", "ضعّفها", "تضعيف الأحاديث", "الرواية بالمعنى", "القدر المشترك"],
    "الاتصال والانقطاع": ["اتصال", "الاتصال", "الانقطاع", "المرسل", "مرسل", "المنقطع", "المعضل",
                           "تدليس", "التدليس", "المدلس", "مدلس", "السماع", "سماع", "المعنعن",
                           "عنعنة", "الإرسال", "اللقاء", "المعاصرة", "الرفع والوقف", "الوقف",
                           "الموقوف", "المرفوع", "زيادة الراوي", "زيادة الثقة", "المزيد في متصل",
                           "الوصل", "الوجادة", "المناولة", "الإجازة", "التضعيف المقيد بشيخ"],
    "مصطلح الحديث": ["مصطلح", "علوم الحديث", "قواعد الحديث", "المصطلح الحديثي"],
    "تحقيق الكتب الحديثية": ["دراسة وتحقيق", "تحقيقًا", "تحقيقا ودراسة", "تحقيق ودراسة", "تحقيقاً",
                              "مخطوط", "نسخة خطية", "المخطوط", "تحقيق كتاب", "دراسة و تحقيق", "تحقيق و دراسة",
                              "من أول", "إلى نهاية", "إلى آخر"],
    "فقه الحديث": ["فقه الحديث", "الأحكام الفقهية", "استنباط", "الفقهي", "أحاديث الأحكام"],
    "غريب الحديث": ["غريب الحديث", "الغريب"],
    "مشكل الحديث": ["مشكل الحديث", "المشكل", "إشكال"],
    "مختلف الحديث": ["مختلف الحديث", "التعارض", "الجمع بين"],
    "الحديث الموضوعي": ["الأحاديث الواردة في", "أحاديث الباب", "الموضوعي", "الأحاديث النبوية في"],
    "الناسخ والمنسوخ": ["ناسخ", "منسوخ", "النسخ"],
    "الدفاع عن السنة": ["الدفاع عن السنة", "شبهات", "الرد على", "المستشرق", "منكري السنة"],
    "مناهج المُحدِّثين": ["منهج الإمام", "مناهج المحدثين", "صنيع الإمام"],
    "جهود المُحدِّثين": ["جهود"],
    "الاستدراك الحديثي": ["استدراك", "الاستدراك", "تعقب", "التعقبات"],
    "الحديث التحليلي": ["دراسة تحليلية", "تحليلية"],
}


def score(title, topic):
    return sum(1 for c in CUES.get(topic, []) if c in (title or ""))


migrations, unclear = [], []
for t in mine:                                   # من هذا المبحث إلى غيره
    ttl = t.get(TITLE) or ""
    if score(ttl, MABHATH):
        continue
    best = max(((score(ttl, k), k) for k in CUES if k != MABHATH), default=(0, ""))
    if best[0] >= 2:
        migrations.append((ttl, MABHATH, best[1], best[0]))
    else:
        unclear.append(ttl)
if MABHATH in CUES:                              # من غيره إلى هذا المبحث
    for t in theses:
        tp = (t.get(TOPIC) or "").strip()
        if tp == MABHATH:
            continue
        ttl = t.get(TITLE) or ""
        if score(ttl, tp) == 0 and score(ttl, MABHATH) >= 2:
            migrations.append((ttl, tp, MABHATH, score(ttl, MABHATH)))

if migrations:
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, "ترحيل.tsv")
    with open(path, "w", encoding="utf-8") as f:
        f.write("العنوان\tمصنَّفة في\tيُقترح\tقوة الترشيح\n")
        for m in migrations:
            f.write("\t".join(str(x) for x in m) + "\n")
    flag("تصنيف", f"{len(migrations)} رسالة يُقترح ترحيلها (ترشيح لا حكم) — التفصيل في out/{SLUG}/ترحيل.tsv",
         [f"«{m[0][:55]}»  {m[1]} ← {m[2]}" for m in migrations[:6]])
if unclear:
    flag("تصنيف", f"{len(unclear)} رسالة لا دليل في عنوانها على انتمائها لهذا المبحث ولا لغيره — تُراجع بالعين",
         [f"«{u[:60]}»" for u in unclear[:6]])
if not migrations and not unclear:
    ok("الانتماء: عناوين المبحث كلها تشهد لموضوعه")

# ── ٢) السنوات ──
years = [t.get(YEAR) for t in mine if t.get(YEAR)]
bad = sorted({str(y) for y in years if not (isinstance(y, int) and 1431 <= y <= 1440)})
if bad:
    flag("سنوات", f"{len(bad)} قيمة خارج المدى 1431–1440 في القائمة: {bad[:6]}")
else:
    ok(f"السنوات: {len(years)} مثبتة داخل المدى {min(years)}–{max(years)}" if years else "السنوات: لا سنوات")

# ── ٣) العيّنة ──
sample_path = os.path.join(ROOT, "data", "samples", SLUG + ".json")
sample_rows, sample_titles, sample_by_code = [], [], {}
if os.path.exists(sample_path):
    s = json.load(open(sample_path, encoding="utf-8"))
    sample_rows = [r for r in (s if isinstance(s, list) else s.get("items", [])) if isinstance(r, dict)]
    for r in sample_rows:
        ts = [x for x in (r.get("cover_title"), r.get("match_title"), r.get(TITLE)) if x]
        sample_titles.extend(ts)
        if r.get("code"):
            sample_by_code[r["code"]] = r
n_sample, n_total = len(sample_rows), len(mine)
if n_total and n_total < 20:
    ok(f"المبحث دون العشرين رسالة — المجتمع كله مستقرأ، ولا عيّنة له")
elif not sample_rows:
    flag("عيّنة", f"لا ملف عيّنة لهذا المبحث — يُبنى من دليل الروابط أو من وثيقة العيّنة (decode_qr.py)")
else:
    pct = round(100 * n_sample / n_total) if n_total else 0
    if 15 <= pct <= 20:
        ok(f"العيّنة: {n_sample} من {n_total} = {pct}٪ — داخل الحدّ (15–20٪)")
    else:
        flag("عيّنة", f"{n_sample} من {n_total} = {pct}٪ — خارج الحدّ المعلن (15–20٪)؛ يُعرض على الباحث")

# ── ٤) الهوية والسنة من الغلاف (حيث توجد بطاقات) ──
cards_dir = os.path.join(ROOT, "data", "cards", SLUG)
cards = {}
if os.path.isdir(cards_dir):
    for f in sorted(os.listdir(cards_dir)):
        if f.endswith(".json"):
            cards[f[:-5]] = json.load(open(os.path.join(cards_dir, f), encoding="utf-8"))
urls_path = os.path.join(ROOT, "data", "theses_urls.json")
urls = json.load(open(urls_path, encoding="utf-8")) if os.path.exists(urls_path) else {}
if cards:
    id_mism, yr_mism = [], []
    for code, card in cards.items():
        meta = card.get("meta") or {}
        cover = meta.get("title") or ""
        listed = (sample_by_code.get(code) or {}).get("match_title") or (sample_by_code.get(code) or {}).get(TITLE) \
            or (urls.get(code) or {}).get("match_title") or ""
        if cover and listed and contains(cover, listed) < 0.55:
            id_mism.append((code, cover, listed))
        cy = meta.get("year_h") or meta.get("year")
        ly = (sample_by_code.get(code) or {}).get("year") or (urls.get(code) or {}).get("year")
        if cy and ly and int(cy) != int(ly):
            yr_mism.append((code, cy, ly, cover, listed))
    if id_mism:
        flag("هوية", "عنوان الغلاف يخالف عنوان القائمة — المعتمد الغلاف، والقائمة تُصحَّح بإذن الباحث",
             [f"[{c}] الغلاف: «{cov[:50]}»  |  القائمة: «{lst[:50]}»" for c, cov, lst in id_mism[:5]])
    else:
        ok(f"الهوية: أغلفة {len(cards)} بطاقة توافق القائمة")
    if yr_mism:
        flag("سنوات", "سنة الغلاف تخالف سنة القائمة — المعتمد سنة المناقشة؛ وإن بَعُد الفرق فلعلّها رسالةٌ أخرى",
             [f"[{c}] الغلاف {cy} «{cov[:38]}» | القائمة {ly} «{lst[:38]}»" if abs(int(cy) - int(ly)) > 1
              else f"[{c}] الغلاف {cy} | القائمة {ly}" for c, cy, ly, cov, lst in yr_mism[:6]])
    else:
        ok("سنة الغلاف توافق القائمة في البطاقات كلها")
    n_manual = sum(1 for c in cards.values() if c.get("manual"))
    n_auto = len(cards) - n_manual
    n_cards = len(cards)
    if n_manual:
        ok(f"بطاقات الباحث اليدوية: {n_manual} (تُقدَّم على بطاقات الأداة عند التعارض) + {n_auto} بطاقة أداة")
    if sample_rows and n_auto != n_sample:
        flag("عيّنة", f"بطاقات الأداة {n_auto} والعيّنة {n_sample}"
             + (f" (وبطاقات الباحث اليدوية {n_manual} بأسمائها هو)" if n_manual else "")
             + f" — المطلبان الثالث والرابع يُبنيان على ما قُرئ فعلًا ({n_cards})")

# ═════════════════════════ (ب) فحوص المسوّدة ═════════════════════════
if DRAFT and os.path.exists(DRAFT):
    md = open(DRAFT, encoding="utf-8").read()
    words = len(md.split())
    print(f"المسوّدة: {os.path.basename(DRAFT)} — {words} كلمة، {len(footnotes_in(md))} حاشية")

    # ── ٥) أرقام المطلب الأول مقابل stats.json ──
    m1 = section(md, "المطلب الأول", ["المطلب الثاني"])
    stats_path = os.path.join(OUT, "stats.json")
    if m1 and os.path.exists(stats_path):
        st_obj = json.load(open(stats_path, encoding="utf-8"))
        leaf = leaves(st_obj, [])
        total = st_obj.get("total") or 0
        known = set(leaf)
        # مشتقّات مسموح بها فقط: مجموع محورين، وفرق أعلى سنة وأدناها، وسنوات المراحل، والمجموع ناقص عدد
        clusters = [c.get("count") for c in (st_obj.get("clusters") or []) if isinstance(c, dict)]
        known |= {a + b for a in clusters for b in clusters}
        by_year = [v for v in (st_obj.get("by_year") or {}).values() if isinstance(v, int)]
        if by_year:
            known |= {max(by_year) - min(by_year)}
        known |= {total - a for a in leaf if 0 < a < total}
        known_pct = {round(100 * a / total) for a in leaf if total and 0 < a <= total}
        cpct = [c.get("pct") for c in (st_obj.get("clusters") or []) if isinstance(c, dict) and isinstance(c.get("pct"), int)]
        known_pct |= {a + b for a in cpct for b in cpct}
        if cpct:
            known_pct |= {sum(cpct), 100}                 # مجموع نسب الجدول (98٪ بأثر التقريب) والمئة
        known |= {n_sample, len(cards)} - {0}             # عدد العيّنة يُذكر في التوصيف المنهجي
        for other in glob.glob(os.path.join(ROOT, "out", "*", "stats.json")):   # أرقام مباحث أخرى للمقارنة
            if os.path.abspath(other) != os.path.abspath(stats_path):
                sib = json.load(open(other, encoding="utf-8"))
                sl, st = leaves(sib, []), sib.get("total") or 0
                known |= set(sl)
                known_pct |= {round(100 * a / st) for a in sl if st and 0 < a <= st}
        nums = [(int(m.group(1)), m.start(), m.group(0).endswith("٪)")) for m in re.finditer(r"\((\d{1,4})(٪?)\)", m1)]
        unsourced = [(v, m1[max(0, p - 60):p + 12].replace("\n", " "))
                     for v, p, is_pct in nums
                     if v not in known and not (is_pct and v in known_pct) and not 1431 <= v <= 1440]
        if unsourced:
            flag("أرقام", f"{len(unsourced)} رقمًا في المطلب الأول لا أصل له في stats.json — يُحسب لا يُكتب",
                 [f"({v}) …{ctx.strip()}" for v, ctx in unsourced[:6]])
        else:
            ok(f"أرقام المطلب الأول: {len(nums)} رقمًا كلها ترجع إلى stats.json")
    elif m1:
        flag("أرقام", f"لا stats.json في out/{SLUG}/ — شغّل stats.py قبل الكتابة")

    # ── ٦) تقيّد المطلبين الثالث والرابع بالعيّنة ──
    p3 = heading_pos(md, "المطلب الثالث")
    tail = md[p3:] if p3 >= 0 else ""
    cited34 = set(re.findall(r"«([^»]{12,120})»\s*\(\s*1[34]\d\d", tail))
    if sample_titles and cited34:
        outside = [c for c in cited34 if not any(overlap(c, st) >= 0.6 for st in sample_titles)]
        if outside:
            flag("عيّنة", "عُزيت في المطلبين الثالث والرابع رسائلُ خارج العيّنة",
                 [f"«{o[:60]}»" for o in outside[:8]])
        else:
            ok(f"المطلبان الثالث والرابع: {len(cited34)} رسالة مذكورة كلها من العيّنة")

    # ── ٧) الحواشي ──
    banned = re.findall(r"(المصدر نفسه|المرجع السابق|مصدر سابق|المرجع نفسه|نفسه، ص)", md)
    if banned:
        flag("حواشٍ", f"ورد «المصدر نفسه/المرجع السابق» {len(banned)} مرة — تُعاد الإحالة كاملة في كل موضع")
    else:
        ok("الحواشي: لا «مصدر نفسه» ولا «مرجع سابق»")
    bib_notes = [fn for fn in footnotes_in(md) if ("جامعة" in fn or "الجامعة" in fn) and "رسالة" in fn]
    distinct34 = []
    for c in cited34:
        if not any(overlap(c, d) >= 0.7 for d in distinct34):
            distinct34.append(c)
    no_bib = [c for c in distinct34 if not any(overlap(c, fn) >= 0.5 for fn in bib_notes)]
    if no_bib:
        flag("حواشٍ", f"{len(no_bib)} رسالة من المذكورة في المطلبين الثالث والرابع بلا حاشية ببليوغرافية (العنوان، الباحث، الدرجة، الجامعة، السنة، الصفحات)",
             [f"«{t[:60]}»" for t in no_bib[:6]])
    elif distinct34:
        ok(f"الحواشي: {len(distinct34)} رسالة مذكورة في المطلبين الثالث والرابع لكلٍّ حاشية ببليوغرافية")

    # ── ٨) النبرة و ٩) الجزم — على كلامنا نحن، لا على اقتباساتٍ ولا حواشٍ ──
    p2 = heading_pos(md, "المطلب الثاني")
    ours = strip_quotes_and_notes(md[p2:] if p2 >= 0 else md)
    ours_plain = _TASHKEEL.sub("", ours)
    HARSH = ["أعور", "عوراء", "أعرج", "مبتور", "بتر", "هزيل", "ركيك", "مشوه", "أخفق", "إخفاق",
             "تخبط", "سطحي", "مجرد جمع", "لا يعدو الجمع", "خلل", "اضطراب", "مضطرب", "ناقص", "مخل",
             "ضعف شديد", "أهمل", "تجاهل", "عجز عن", "فشل في", "قصور فاضح", "لا قيمة", "فاضح", "مبتذل",
             "عشوائي", "اعتباطي", "مهلهل", "متهافت"]
    def harsh_re(w):
        return re.compile(r"(?<![ء-ي])[وف]?(?:ال)?" + re.escape(w) + r"(?:ه|ها|ت|وا|ون|ين|ة|ا|ان|تين)?(?![ء-ي])")
    heads = [l for l in ours_plain.split("\n") if l.startswith("#")]
    found = []
    for w in HARSH:
        rx = harsh_re(w)
        if rx.search(ours_plain):
            where = "في عنوان" if any(rx.search(h) for h in heads) else "في المتن"
            found.append(f"{w} ({where})")
    if found:
        flag("نبرة", "ألفاظ حادّة في كلامنا يلزم تليينها — الجدول في references/style-profile.md",
             ["، ".join(found[:10])])
    else:
        ok("النبرة: لا ألفاظ حادّة في نقدنا ولا في عناويننا")
    HEDGES = ("قد ", "فيما يظهر", "في الغالب", "غالبا", "ربما", "لعل", "يبدو", "في الأغلب",
              "في بعض", "فيما يبدو", "لا يبعد", "أقرب", "كأن")
    CATEG = [r"(?<!\S)يتعذر(?![^\s.،؛:)])", r"(?<!\S)لا يمكن(?!\S)", r"(?<!\S)دائما(?![^\s.،؛:)])",
             r"(?<!\S)أبدا(?![^\s.،؛:)])", r"(?<!\S)يجب أن(?!\S)", r"من الخطأ", r"هذا يدل على",
             r"كل هذه الدراسات", r"(?<!\S)جميع الدراسات", r"(?<!\S)لا شك"]
    hits = []
    for pat in CATEG:
        for m in re.finditer(pat, ours_plain):
            before = ours_plain[max(0, m.start() - 30):m.start()]
            if not any(h in before for h in HEDGES):
                hits.append(ours_plain[max(0, m.start() - 35):m.end() + 30].replace("\n", " ").strip())
    if hits:
        flag("جزم", f"{len(hits)} موضعًا في أحكامنا التقويمية يحتمل الاحتراز («قد» / «فيما يظهر» / «في الغالب»)",
             [f"…{h}…" for h in hits[:5]])
    else:
        ok("الجزم: أحكامنا التقويمية محترَزة حيث يلزم")

    # ── ١٠) البنية: المطلب الرابع، والخلاصة ──
    m4 = section(md, "المطلب الرابع", ["خلاصة المبحث", "## فهرس"])
    if m4:
        heads = re.split(r"\n###\s+", m4)[1:]
        weak = []
        for h in heads:
            name = h.split("\n", 1)[0].strip(": ")
            if name.startswith("وخلاصة") or name.startswith("أوجه النقد"):
                continue
            EFFECT = ("وأثر ذلك", "وأثره", "وحاصل ذلك", "وثمرة ذلك", "ومؤدّى ذلك", "ومؤدى ذلك",
                      "ويترتّب على ذلك", "ويترتب على ذلك", "وينبني على ذلك", "فأثر ذلك")
            BETTER = ("ويجوّد", "ويجوَّد", "ويُجوَّد", "يُجوَّد ذلك", "ويحسن", "تجويد ذلك", "والأولى",
                      "ويُستدرك ذلك", "والمقترح")
            miss = [k for k, pats in (("«وأثر ذلك»", EFFECT), ("«ويجوّد ذلك»", BETTER))
                    if not any(p in h for p in pats)]
            if miss:
                weak.append(f"{name[:45]} — ينقصه {' و'.join(miss)}")
        if weak:
            flag("بنية", f"{len(weak)} من مواطن المطلب الرابع لا يستوفي خطواته الأربع (الملحوظة ← الشواهد ← وأثر ذلك ← ويجوّد ذلك)", weak[:6])
        else:
            ok(f"المطلب الرابع: {len(heads)} موطنًا كلٌّ على خطواته الأربع")
    if "خلاصة المبحث" not in md:
        flag("بنية", "لا «خلاصة المبحث» بعد المطلب الرابع — وهي لازمة (references/structure.md)")
    else:
        kh = section(md, "خلاصة المبحث", ["## فهرس", "\n## "])
        before = md[:md.find("خلاصة المبحث")]
        kh_words = len(kh.split())
        new_nums = sorted({x for x in re.findall(r"\((\d{1,4})٪?\)", kh) if f"({x}" not in before})
        notes = []
        if kh_words > 230:
            notes.append(f"طولها {kh_words} كلمة والحدّ مئتان")
        if new_nums:
            notes.append(f"فيها أرقام لم ترد قبلها: {new_nums[:6]}")
        if notes:
            flag("بنية", "«خلاصة المبحث» جمعٌ لما تقدّم لا زيادةٌ عليه", notes)
        else:
            ok(f"«خلاصة المبحث» موجودة ({kh_words} كلمة) وبلا رقم جديد")

    # ── ١٢) التعميمات العددية في المطالب ٢–٤ مقابل ورقة الأدلة والبطاقات ──
    WORDNUM = {"واحدة": 1, "واحد": 1, "اثنتين": 2, "اثنتان": 2, "اثنين": 2, "ثلاث": 3, "ثلاثة": 3, "أربع": 4, "أربعة": 4,
               "خمس": 5, "خمسة": 5, "ست": 6, "ستة": 6, "سبع": 7, "سبعة": 7, "ثمان": 8, "ثماني": 8, "ثمانية": 8,
               "تسع": 9, "تسعة": 9, "عشر": 10, "عشرة": 10, "إحدى عشرة": 11, "اثنتي عشرة": 12, "ثلاث عشرة": 13,
               "أربع عشرة": 14, "خمس عشرة": 15}
    ev_path = os.path.join(OUT, "ورقة_الأدلة.md")
    accepted = set()
    if os.path.exists(ev_path):
        ev = open(ev_path, encoding="utf-8").read()
        for m in re.finditer(r"([٠-٩\d]+)\s*من\s*([٠-٩\d]+)", ev):
            accepted.add(int(m.group(1).translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789"))))
    n_cards = len(cards) if cards else 0
    accepted |= {n_cards, n_sample}
    if os.path.exists(os.path.join(OUT, "stats.json")):
        accepted |= set(leaves(json.load(open(os.path.join(OUT, "stats.json"), encoding="utf-8")), []))
    later = section(md, "المطلب الثاني", ["خلاصة المبحث", "## فهرس"])
    later = _TASHKEEL.sub("", strip_quotes_and_notes(later))
    claims = []
    for m in re.finditer(r"\((\d{1,2})\)\s*(?:رسال|دراس)", later):
        claims.append((int(m.group(1)), m.start()))
    for w, v in WORDNUM.items():
        for m in re.finditer(r"(?<![ء-ي])" + w + r"\s+(?:رسائل|رسالة|دراسات|دراسة)", later):
            claims.append((v, m.start()))
    if claims and os.path.exists(ev_path):
        bad = [(v, later[max(0, pos - 45):pos + 30].replace("\n", " ")) for v, pos in claims if v not in accepted and v > 1]
        if bad:
            flag("تعميم", f"{len(bad)} تعميمًا عدديًّا في المطالب ٢–٤ لا يطابق عدًّا في ورقة الأدلة ولا في الإحصاء — يُعدّ من البطاقات",
                 [f"({v}) …{c.strip()}…" for v, c in bad[:6]])
        else:
            ok(f"التعميمات العددية: {len(claims)} تعميمًا كلها تطابق أعدادًا في ورقة الأدلة أو الإحصاء")
    elif claims:
        flag("تعميم", f"{len(claims)} تعميمًا عدديًّا في المطالب ٢–٤ ولا ورقة أدلة في out/{SLUG}/ لمقابلتها — تُحفظ ورقة الأدلة باسم ورقة_الأدلة.md ثم يُعاد الفحص")

    # ── ١٣) نسب الجداول تُتمّ المئة ──
    for tbl in re.finditer(r"((?:^\|.*\|\s*$\n?){3,})", md, flags=re.M):
        rows = [r for r in tbl.group(1).strip().split("\n") if "٪" in r and "المجموع" not in r]
        pcts = [int(x) for r in rows for x in re.findall(r"(\d{1,3})\s*٪", r)]
        if len(pcts) >= 3:
            tot = sum(pcts)
            after = md[tbl.end():tbl.end() + 400]               # التنبيه على التقريب يأتي في الجدول أو في الفقرة التي تليه
            if not 99 <= tot <= 101 and "التقريب" not in tbl.group(1) + after:
                flag("جداول", f"نسب جدولٍ مجموعها {tot}٪ لا {100}٪ — يُصحَّح أو يُنبَّه على أثر التقريب",
                     [rows[0][:70]])

    # ── ١٤) آثار الأداة: المبحث بصوت باحثٍ رسائلُه بين يديه — لا رموز ولا روابط ولا نُسخ ولا تعذُّر وقوف ──
    TRACE = ["رمز الوصول", "رمزُ الوصول", "رمز QR", "QR", "الرابط المثبت", "رابط الوصول", "الملف المرفوع", "النسخة المرفوعة",
             "النسخة المتاحة", "النسخة المقروءة", "النسخة الإلكترونية", "PDF", "التعرف الضوئي", "التعرّف الضوئي", "OCR",
             "حزمة القراءة", "بطاقة التحليل", "بطاقات التحليل", "الوكيل", "العينة المقروءة", "العيّنة المقروءة", "العينات المقروءة", "العيّنات المقروءة",
             "المواضع المقروءة", "تعذّر الوقوف", "تعذر الوقوف", "لم يُوقف على نص", "لم يوقف على نص", "وُقف على نصوصها",
             "قاعدة البيانات", "وثيقة العينة", "وثيقة العيّنة", "إزاحة الترقيم", "صفحة الغلاف", "بلا صفحة عنوان",
             "الجلسة", "الوقفة", "ما لم يُقرأ", "مجلد العمل", "السكربت", "stats", "json"]
    traces = []
    for label, seg in (("المتن", strip_quotes_and_notes(md)), ("الحواشي", "\n".join(footnotes_in(md)))):
        for w in TRACE:
            for m in re.finditer(re.escape(w), seg):
                traces.append((label, seg[max(0, m.start() - 40):m.end() + 40].replace("\n", " ").strip()))
                break
    if traces:
        flag("آثار الأداة", f"{len(traces)} موضعًا يحكي طريقة الوصول أو عمل الأداة — يُحذف من المبحث ويُنقل إلى مذكرة التسليم",
             [f"[{lb}] …{c}…" for lb, c in traces[:8]])
    else:
        ok("لا آثار للأداة في المتن ولا في الحواشي")

    # ── ١١) الحكم السلبي على الترجيح ──
    neg = [m.group(1) for m in re.finditer(r"(?<!ب)(لا (?:ترجيح|يرجّح|ترجّح|يرجح)[^.،؛]{0,40}|خلت من (?:النقد|الترجيح)[^.،؛]{0,30})", ours)
           if "٪" not in ours[max(0, m.start() - 90):m.start()]]
    if neg:
        flag("تحليل", "حُكم بنفي الترجيح أو النقد — الترجيح موقفٌ لا لفظ (references/lexicon.md)؛ الصيغة: «لم أقف على ترجيحٍ في المواضع المقروءة»",
             [f"«{n[:60]}»" for n in neg[:4]])
    else:
        ok("لا حكم بالنفي على الترجيح أو النقد")

# ═════════════════════════ (ج) فحص ملف Word إن أُعطي ═════════════════════════
if "--docx" in sys.argv:
    dx = sys.argv[sys.argv.index("--docx") + 1]
    if os.path.exists(dx):
        import html as _html
        import zipfile
        zz = zipfile.ZipFile(dx)
        parts = [zz.read(n).decode("utf-8", "replace") for n in zz.namelist() if n in ("word/document.xml", "word/footnotes.xml")]
        txt = "".join(_html.unescape(x) for part in parts for x in re.findall(r"<w:t[^>]*>(.*?)</w:t>", part, flags=re.S))
        arts = {"**": txt.count("**"), "*": txt.count("*") - 2 * txt.count("**"), "#": len(re.findall(r"(?m)(^|\s)#{1,4}\s", txt)),
                "^[": txt.count("^["), "](": txt.count("]("), "`": txt.count("`"), "يوضع هنا": txt.count("يوضع هنا")}
        arts = {k: v for k, v in arts.items() if v > 0}
        n_fn = len(re.findall(r"<w:footnote ", parts[1])) - 2 if len(parts) > 1 else 0
        if arts:
            flag("Word", "علامات Markdown أو عناصر نائبة بقيت في ملف Word — يُعاد البناء", [", ".join(f"{k} ×{v}" for k, v in arts.items())])
        else:
            ok(f"ملف Word نظيف: لا علامات Markdown ولا عناصر نائبة، {n_fn} حاشية")

# ═════════════════════════════ التقرير ═════════════════════════════
print()
for p in passed:
    print("  ✅", p)
if findings:
    print("  " + "─" * 54)
    for kind, head, details in findings:
        print(f"  ❌ {kind} · {head}")
        for d in details:
            print(f"        {d}")
    print("  " + "─" * 54)
    print(f"  {len(findings)} ملحوظة — لا يُعرض المبحث ولا يُسلَّم قبل معالجتها أو التصريح بها.")
else:
    print("  " + "─" * 54)
    print("  لا ملحوظات.")
