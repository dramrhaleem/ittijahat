#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""تقرير Markdown عربي → PDF (ومعه HTML) بخط Amiri المشحون مع الأداة، من اليمين إلى اليسار.
    python3 scripts/md_to_pdf.py <تقرير.md> <تقرير.pdf> [--title "عنوان في رأس الصفحة"]
للتقارير والقوائم فقط (مراجعة التصنيف، التطابق، دليل الرفع…)؛ أما المبحث فيُخرَج Word بقالب إثراء المتون ثم PDF منه.
يعتمد على pandoc وPlaywright؛ وإن غاب أحدهما أبلغ وترك HTML في موضع PDF نفسه بلاحقة .html.
"""
import sys, os, glob, subprocess, shutil

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT_DIR = os.path.join(ROOT, 'assets', 'fonts')

CSS = """
@font-face {{ font-family: 'Amiri'; src: url('file://{reg}'); font-weight: normal; }}
@font-face {{ font-family: 'Amiri'; src: url('file://{bold}'); font-weight: bold; }}
html {{ direction: rtl; }}
body {{ font-family: 'Amiri', 'Traditional Arabic', serif; font-size: 13pt; line-height: 1.7; direction: rtl; text-align: right;
        margin: 0; color: #111; }}
h1 {{ font-size: 20pt; text-align: center; margin: 0 0 12pt; }}
h2 {{ font-size: 16pt; margin: 18pt 0 6pt; border-bottom: 1px solid #999; padding-bottom: 2pt; }}
h3 {{ font-size: 14pt; margin: 14pt 0 4pt; }}
p {{ margin: 4pt 0; }}
table {{ border-collapse: collapse; width: 100%; font-size: 11pt; margin: 6pt 0 10pt; page-break-inside: auto; }}
tr {{ page-break-inside: avoid; }}
th, td {{ border: 1px solid #888; padding: 3pt 5pt; vertical-align: top; text-align: right; }}
th {{ background: #e8e8e8; }}
thead {{ display: table-header-group; }}
code {{ font-family: 'Amiri', monospace; font-size: 11pt; background: #f3f3f3; padding: 0 2pt; }}
pre {{ background: #f3f3f3; padding: 6pt; font-size: 10.5pt; white-space: pre-wrap; direction: rtl; }}
ol, ul {{ padding-right: 22pt; padding-left: 0; }}
blockquote {{ border-right: 3px solid #bbb; margin: 6pt 0; padding-right: 8pt; color: #333; }}
.title-note {{ text-align: center; color: #555; font-size: 11pt; margin-bottom: 14pt; }}
"""


def md_to_html(src, dst_html, title=None):
    reg = (glob.glob(os.path.join(FONT_DIR, 'Amiri-Regular*.ttf')) or glob.glob(os.path.join(FONT_DIR, 'Amiri*.ttf')) or [''])[0]
    bold = (glob.glob(os.path.join(FONT_DIR, 'Amiri-Bold*.ttf')) or [reg])[0]
    body = subprocess.run(['pandoc', src, '-f', 'gfm+footnotes', '-t', 'html5', '--wrap=none'],
                          capture_output=True, text=True, check=True).stdout
    t = title or ''
    html = ('<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">'
            f'<title>{t}</title><style>{CSS.format(reg=reg, bold=bold)}</style></head><body>'
            + (f'<div class="title-note">{t}</div>' if t else '') + body + '</body></html>')
    open(dst_html, 'w', encoding='utf-8').write(html)


def main():
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    src, dst = sys.argv[1], sys.argv[2]
    title = None
    if '--title' in sys.argv:
        title = sys.argv[sys.argv.index('--title') + 1]
    def have_playwright():
        return subprocess.run([sys.executable, '-c', 'import playwright.async_api'], capture_output=True).returncode == 0
    if not shutil.which('pandoc') or not have_playwright():
        # بيئة بلا pandoc/متصفّح (مثل ChatGPT): المولّد البديل reportlab
        try:
            sys.path.insert(0, os.path.join(ROOT, 'scripts')); import pdf_rl
            pdf_rl.render_md(src, dst, title or '')
            print('written', dst, os.path.getsize(dst), '(reportlab)'); return
        except Exception as e:
            print('تعذّر PDF بالمولّد البديل:', e); sys.exit(2)
    html = os.path.splitext(dst)[0] + '.html'
    md_to_html(src, html, title)
    r = subprocess.run([sys.executable, os.path.join(ROOT, 'scripts', 'html_to_pdf.py'), html, dst])
    if r.returncode:
        try:
            sys.path.insert(0, os.path.join(ROOT, 'scripts')); import pdf_rl
            pdf_rl.render_md(src, dst, title or ''); print('written', dst, os.path.getsize(dst), '(reportlab)'); return
        except Exception as e:
            print(f'بقي HTML في {html} (تعذّر PDF: {e}).'); sys.exit(r.returncode)
    print('written', dst, os.path.getsize(dst))


if __name__ == '__main__':
    main()
