# -*- coding: utf-8 -*-
"""استخراج نص رسالة صفحةً صفحةً مع تصحيح انعكاس الحروف الشائع في خطوط PDF العربية.
الاستخدام: python3 scripts/extract_text.py <ملف.pdf> <مجلد المخرج>
يُنتج p_0001.txt … ويُستعمل قبل reading_pack.py. إن خرج النص فارغًا فالملف صور → استعمل ocr_thesis.sh
"""
import unicodedata, re, os, sys, subprocess
BIDI = re.compile('[‪-‮⁦-⁩‎‏﻿￯]')
PREFIX = [('اإل','الإ'),('األ','الأ'),('اال','الا'),('اآل','الآ'),('امل','الم'),('احل','الح'),('اجل','الج'),('اخل','الخ')]
def fix_word(w):
    core=w; done=False
    for bad,good in PREFIX:
        if core.startswith(bad): core=good+core[len(bad):]; done=True; break
        for pre in ('و','ف','ب','ك','ل','وب','فب','ول','فل'):
            if core.startswith(pre+bad): core=pre+good+core[len(pre)+len(bad):]; done=True; break
        if done: break
    if core=='يف': core='في'
    elif core in ('ويف','فيف'): core=core[0]+'في'
    return core
def clean(t):
    t=BIDI.sub('',unicodedata.normalize('NFKC',t))
    return '\n'.join(' '.join(fix_word(w) for w in line.split(' ')) for line in t.split('\n'))
def main(pdf,out):
    os.makedirs(out,exist_ok=True)
    import shutil
    if shutil.which('pdftotext'):
        raw=subprocess.run(['pdftotext',pdf,'-'],capture_output=True).stdout.decode('utf-8','replace')
        pages=raw.split('\f')
    else:                                                   # بلا poppler (مثل ChatGPT): pymupdf
        import fitz
        with fitz.open(pdf) as doc: pages=[pg.get_text() for pg in doc]
    n=0; chars=0
    for i,t in enumerate(pages):
        if i>=len(pages)-1 and not t.strip(): break
        t=clean(t); open(f'{out}/p_{i+1:04d}.txt','w').write(t); n=i+1; chars+=len(t)
    print(f'{n} صفحة، {chars} حرفًا، بمعدل {chars//max(n,1)} حرفًا للصفحة')
    if chars/max(n,1) < 200: print('تحذير: النص شبه فارغ — الملف صور على الأرجح، فاستعمل scripts/ocr_thesis.sh')
if __name__=='__main__': main(sys.argv[1], sys.argv[2])
