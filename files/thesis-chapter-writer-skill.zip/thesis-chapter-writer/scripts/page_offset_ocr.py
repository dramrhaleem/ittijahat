# -*- coding: utf-8 -*-
"""تقدير الفرق بين رقم صفحة PDF ورقم الصفحة المطبوع بقراءة رأس/ذيل الصفحة بالـ OCR.
الاستخدام: python3 scripts/page_offset_ocr.py <pdf> [--samples 6]
"""
import sys, subprocess, re, os, tempfile, argparse, collections
from PIL import Image
AR_DIG=str.maketrans('٠١٢٣٤٥٦٧٨٩','0123456789')
def ocr_strip(img, box):
    crop=img.crop(box)
    with tempfile.NamedTemporaryFile(suffix='.png',delete=False) as t:
        crop.save(t.name); out=subprocess.run(['tesseract',t.name,'-','-l','ara+eng','--psm','7'],capture_output=True).stdout.decode('utf-8','replace')
    os.unlink(t.name)
    nums=[int(x.translate(AR_DIG)) for x in re.findall(r'[0-9٠-٩]{1,4}', out)]
    return nums
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('pdf'); ap.add_argument('--samples',type=int,default=6); a=ap.parse_args()
    n=int(re.search(r'Pages:\s+(\d+)',subprocess.run(['pdfinfo',a.pdf],capture_output=True).stdout.decode()).group(1))
    votes=collections.Counter(); details=[]
    for k in range(a.samples):
        p=int(n*0.25+ (n*0.6)*k/max(1,a.samples-1))
        with tempfile.TemporaryDirectory() as d:
            subprocess.run(['pdftoppm','-f',str(p),'-l',str(p),'-r','150','-gray','-png',a.pdf,os.path.join(d,'pg')],check=True)
            f=[x for x in os.listdir(d) if x.endswith('.png')][0]
            img=Image.open(os.path.join(d,f)); w,h=img.size
            nums=ocr_strip(img,(0,0,w,int(h*0.09)))+ocr_strip(img,(0,int(h*0.91),w,h))
        cands=[x for x in nums if abs(x-p)<=60]
        details.append((p,cands))
        for c in cands: votes[c-p]+=1
    best=votes.most_common(1)[0] if votes else (None,0)
    print({'pages':n,'offset':best[0],'votes':best[1],'samples':details})
if __name__=='__main__': main()
