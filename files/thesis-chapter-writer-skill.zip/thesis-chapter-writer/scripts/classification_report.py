#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""تجميع مراجعة التصنيف وإخراج تقريرها.

    python3 scripts/classification_report.py            # يقرأ out/تصنيف/review_g*.json ويُخرج:
        out/تصنيف/الاقتراحات.json                       — الاقتراحات موحَّدةً بمعرّف الصفّ القياسي
        out/تصنيف/تقرير_مراجعة_التصنيف.md               — الجدول + العدّادات + الوسوم + السلاسل + الشكوك
        out/تصنيف/مراجعة_التصنيف.xlsx                   — الجداول نفسها أوراقًا
        out/تصنيف/القائمة_المعلَّمة.docx                 — نسخة القائمة والصفوف المقترح نقلها ملوّنة ومعلَّقة
        out/تصنيف/القائمة_المعلَّمة.html                 — للتحويل إلى PDF

المعرّف القياسي للرسالة: «السنة/ترتيبها في جدول السنة» (كما تظهر في عمود «م» في القائمة)، ومعه رمز الوصول إن وُجد.
"""
import json, re, os, glob, collections, sys, datetime
from docx import Document
from docx.shared import RGBColor
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
OUT = 'out/تصنيف'
LIST_DOCX = 'materials/قائمة_الرسائل_الشاملة.docx'

MABAHITH = ['الجرح والتعديل','علل الحديث','الاتصال والانقطاع','فقه الحديث','الناسخ والمنسوخ','مشكل الحديث',
            'مختلف الحديث','غريب الحديث','الحديث الموضوعي','مصطلح الحديث','تحقيق الكتب الحديثية','الحديث التحليلي',
            'الموضوعات البينية','الدفاع عن السنة','مناهج المحدثين','جهود المحدثين','الاستدراك الحديثي']

def strip_d(s): return re.sub(r'[ً-ْٰ]', '', s or '')
def canon_topic(t):
    t = strip_d(t).strip()
    for m in MABAHITH:
        if strip_d(m) == t: return m
    return t
def ntitle(s):
    s = strip_d(s); s = re.sub(r'[أإآ]', 'ا', s).replace('ة','ه').replace('ى','ي')
    s = re.sub(r'[^\w\s]', ' ', s); return re.sub(r'\s+', ' ', s).strip()

# ---------- الصفوف القياسية ----------
norm = json.load(open('data/theses_norm.json', encoding='utf-8'))
code_of = {}
for f in glob.glob('data/samples/*.json'):
    for r in json.load(open(f, encoding='utf-8')): code_of[ntitle(r['title'])] = r['code']
rows = []; pos = collections.Counter()
for i, r in enumerate(norm):
    pos[r['year']] += 1
    rows.append(dict(i=i, year=r['year'], pos=pos[r['year']], num=r['num'].strip(), title=r['title'].strip(),
                     current=canon_topic(r['topic_norm']), code=code_of.get(ntitle(r['title']), ''),
                     university=r['university_norm'], degree=r['degree_norm']))
def uid(r): return f"{r['year']}/{r['pos']}"
by_nt = collections.defaultdict(list)
for r in rows: by_nt[ntitle(r['title'])].append(r)

# ---------- قراءة المراجعات ----------
batches = {os.path.basename(f)[:-5]: json.load(open(f, encoding='utf-8')) for f in sorted(glob.glob(f'{OUT}/in/g*.json'))}
def find_row(p, batch_rows):
    """يرجع الصفّ القياسي للاقتراح: بموضع الدفعة إن وُجد، وإلا بالعنوان والمبحث الحالي."""
    idx = p.get('row') or p.get('idx')
    if idx and 1 <= int(idx) <= len(batch_rows):
        br = batch_rows[int(idx)-1]
        if ntitle(br['title']) == ntitle(p['title']):
            cands = [r for r in by_nt[ntitle(br['title'])] if r['current'] == canon_topic(br['current'])]
            if len(cands) == 1: return cands[0]
    allc = by_nt.get(ntitle(p.get('title','')), [])
    cur = canon_topic(p.get('current','')) if p.get('current') else None
    cands = [r for r in allc if r['current'] == cur] if cur else list(allc)
    if not cands and batch_rows:  # الصفّ في الدفعة نفسها بالعنوان
        for br in batch_rows:
            if ntitle(br['title']) == ntitle(p.get('title','')):
                cands = [r for r in allc if r['current'] == canon_topic(br['current'])]; break
    if len(cands) == 1: return cands[0]
    if cands: return cands[0]  # عنوان مكرر بالمبحث نفسه — يؤخذ الأول
    return None

proposals = []; tags = {}; series_notes = []; doubts = []; unresolved = []
for f in sorted(glob.glob(f'{OUT}/review_g*.json')):
    d = json.load(open(f, encoding='utf-8')); bname = d.get('batch') or os.path.basename(f)
    key = [k for k in batches if k.split('_')[0] == os.path.basename(f)[7:9]]
    brows = batches[key[0]] if key else []
    for p in d.get('proposals', []):
        r = find_row(p, brows)
        if not r: unresolved.append(p); continue
        proposed = canon_topic(p['proposed'])
        if proposed not in MABAHITH: unresolved.append(dict(p, why='مبحث غير معروف')); continue
        if proposed == r['current']: continue
        proposals.append(dict(uid=uid(r), i=r['i'], year=r['year'], pos=r['pos'], num=r['num'], code=r['code'],
                              title=r['title'], current=r['current'], proposed=proposed, rule=p.get('rule'),
                              reason=p.get('reason','').strip(), batch=bname))
    for t in d.get('tags', []):
        r = find_row(t, brows)
        if r: tags[r['i']] = dict(tag=t.get('tag',''), note=t.get('note',''))
    series_notes += [f"[{bname}] {s}" for s in d.get('series_notes', [])]
    doubts += [f"[{bname}] {s}" for s in d.get('doubts', [])]
# حذف التكرار (اقتراح واحد لكل صفّ)
seen = set(); uniq = []
for p in sorted(proposals, key=lambda x: (x['year'], x['pos'])):
    if p['i'] in seen: continue
    seen.add(p['i']); uniq.append(p)
proposals = uniq

# ---------- السلاسل الموزَّعة على مبحثين (قبل وبعد) ----------
def series_key(title):
    w = ntitle(title).split()
    w = [x for x in w if x not in ('من','الي','في','و','او','بين','علي','ل','ب')]
    return ' '.join(w[:5])
after = {r['i']: r['current'] for r in rows}
for p in proposals: after[p['i']] = p['proposed']
groups = collections.defaultdict(list)
for r in rows: groups[series_key(r['title'])].append(r)
split_before, split_after = [], []
for k, g in groups.items():
    if len(g) < 2: continue
    cb = collections.Counter(r['current'] for r in g); ca = collections.Counter(after[r['i']] for r in g)
    if len(cb) > 1: split_before.append((k, len(g), dict(cb)))
    if len(ca) > 1: split_after.append((k, len(g), dict(ca)))

# ---------- العدّادات ----------
before = collections.Counter(r['current'] for r in rows)
outc = collections.Counter(p['current'] for p in proposals)
inc = collections.Counter(p['proposed'] for p in proposals)
all_topics = MABAHITH + [t for t in before if t not in MABAHITH]
counter_rows = []
for t in all_topics:
    b = before.get(t, 0); o = outc.get(t, 0); n = inc.get(t, 0)
    counter_rows.append(dict(topic=t, before=b, stays=b-o, out=o, into=n, after=b-o+n))
assert sum(c['after'] for c in counter_rows) == len(rows)

# ---------- وسوم التحقيق ----------
tag_count = collections.Counter(v['tag'] for k, v in tags.items())
tag_after = collections.Counter(v['tag'] for k, v in tags.items() if after[k] == 'تحقيق الكتب الحديثية')

# ---------- الاقتراحات مجموعةً بالقاعدة ----------
RULES = {1:'التصنيف بجوهر العمل لا باللفظ العارض',2:'سلسلة الرسائل الواحدة في مبحثٍ واحد',3:'تحقيق النصّ → تحقيق الكتب الحديثية',
         4:'أحاديث الكتب تخريجًا والزوائد → تحقيق الكتب الحديثية (إلا الغريب)',5:'النوع مؤصَّلًا → المصطلح، ومطبَّقًا → مبحث النوع',
         6:'منهج الإمام في فنٍّ له مبحث → مبحث الفن',7:'مختلف/اختلاف → مختلف الحديث؛ مشكل/يوهم التعارض → مشكل الحديث',
         8:'التعقبات على الرواة → الجرح؛ على الأحاديث → الاستدراك',9:'أحكام الوضع والبطلان → المناهج؛ الطعون → الدفاع',
         10:'«ذكر فيها اختلافًا» → علل الحديث',11:'موضوع → الموضوعي؛ فقهي محض → فقه الحديث؛ تقاطع علمين → البينية',
         12:'مرويات راوٍ: حاله → الجرح؛ أحاديثه → التحليلي',13:'يحتمل ويُرجَع إلى المقدمة'}
by_rule = collections.defaultdict(list)
for p in proposals: by_rule[int(p['rule']) if str(p['rule']).isdigit() else 0].append(p)

json.dump(dict(generated=str(datetime.date.today()), total_rows=len(rows), proposals=proposals,
               counters=counter_rows, tags={str(k): v for k, v in tags.items()}, series_split_before=split_before,
               series_split_after=split_after, series_notes=series_notes, doubts=doubts, unresolved=unresolved),
          open(f'{OUT}/الاقتراحات.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# ---------- التقرير ----------
def ar(n): return str(n)
L = []
L.append('# تقرير مراجعة تصنيف قائمة الرسائل العلمية الشاملة على المباحث\n')
L.append(f'تاريخ المراجعة: {datetime.date.today()} · عدد رسائل القائمة: ({len(rows)}) · المقترح نقله: ({len(proposals)}) رسالة، أي نحو ({round(len(proposals)/len(rows)*100)}٪) · الثابت في موضعه: ({len(rows)-len(proposals)}).\n')
L.append('**هذه اقتراحات لا قرارات.** لم يُنقل شيء في القائمة. كل اقتراحٍ مردودٌ إلى قاعدةٍ مرقَّمة من ملف معايير التصنيف، فيمكن اعتماد قاعدةٍ كاملة أو ردّها، أو الحكم في كل رسالة على حدة. ومعرّف الرسالة: السنة/ترتيبها في جدول السنة (عمود «م»)، ومعه رمز الوصول إن كان لها رمز.\n')
L.append('## أولًا: العدّاد قبل وبعد (على فرض اعتماد الاقتراحات كلها)\n')
L.append('| المبحث | قبل | يثبت | يخرج | يدخل | بعد |\n|---|---|---|---|---|---|')
for c in counter_rows:
    if c['before'] == 0 and c['after'] == 0: continue
    L.append(f"| {c['topic']} | {c['before']} | {c['stays']} | {c['out']} | {c['into']} | **{c['after']}** |")
L.append(f"| **المجموع** | **{len(rows)}** | | **{len(proposals)}** | **{len(proposals)}** | **{len(rows)}** |\n")
L.append('## ثانيًا: وسوم مبحث «تحقيق الكتب الحديثية» — للنظر في مسألة فصل «التخريج والزوائد»\n')
L.append('كل رسالةٍ في هذا المبحث وُسمت بنوع عملها من عنوانها. الوسم لا ينقل الرسالة؛ وإنما يعطي العدد الذي يُحتاج إليه للقرار: أيُفرد «التخريج والزوائد» مبحثًا كما في وثيقة العيّنة، أم يبقى داخل التحقيق كما في خطة البحث؟\n')
L.append('| الوسم | العدد الآن (594) | العدد بعد الاقتراحات |\n|---|---|---|')
for t in ['تحقيق','تخريج','زوائد','غير ذلك']:
    L.append(f"| {t} | {tag_count.get(t,0)} | {tag_after.get(t,0)} |")
inflow_tags = collections.Counter()
for p in proposals:
    if p['proposed'] == 'تحقيق الكتب الحديثية':
        nt = ntitle(p['title'])
        inflow_tags['زوائد' if 'زوائد' in nt else ('تحقيق' if re.search(r'تحقيق', nt) else 'تخريج')] += 1
L.append(f"\nوالداخل إلى المبحث من مباحث أخرى ({inc.get('تحقيق الكتب الحديثية',0)}) رسالة، تقديرُ وسومها من عناوينها: " + '، '.join(f"{k} {v}" for k, v in inflow_tags.items()) + '.\n')
L.append('## ثالثًا: الاقتراحات مجموعةً بالقاعدة\n')
for rn in sorted(by_rule):
    ps = by_rule[rn]
    L.append(f"### القاعدة {rn}: {RULES.get(rn,'—')} — ({len(ps)}) اقتراحًا\n")
    flows = collections.Counter((p['current'], p['proposed']) for p in ps)
    L.append('الاتجاهات: ' + '؛ '.join(f"{a} ← {b} ({n})" for (a, b), n in flows.most_common()) + '\n')
L.append('## رابعًا: جدول الاقتراحات كاملًا\n')
L.append('| المعرّف | الرمز | عنوان الرسالة | المبحث الحالي | المبحث المقترح | القاعدة | السبب |\n|---|---|---|---|---|---|---|')
for p in proposals:
    L.append(f"| {p['uid']} | {p['code'] or '—'} | {p['title']} | {p['current']} | **{p['proposed']}** | {p['rule']} | {p['reason']} |")
L.append('\n## خامسًا: سلاسل موزَّعة على أكثر من مبحث\n')
L.append(f"قبل الاقتراحات: ({len(split_before)}) سلسلة موزَّعة. بعدها: ({len(split_after)}).\n")
if split_after:
    L.append('ما يبقى موزَّعًا بعد الاقتراحات (يحتاج نظرًا):\n')
    for k, n, c in split_after: L.append(f"- «{k}…» ({n} رسائل): " + '، '.join(f"{a} {b}" for a, b in c.items()))
L.append('\n## سادسًا: ملحوظات المراجعين على السلاسل والتكرار\n')
for s in series_notes: L.append(f"- {s}")
L.append('\n## سابعًا: ما تعذّر الحكم فيه من العنوان وحده (يُرجَع إلى مقدمة الرسالة)\n')
for s in doubts: L.append(f"- {s}")
if unresolved:
    L.append('\n## ثامنًا: اقتراحات لم يُعثر على صفّها (تُراجع يدويًّا)\n')
    for p in unresolved: L.append(f"- {p.get('id')} | {p.get('title','')[:80]} | {p.get('proposed')} | {p.get('why','')}")
open(f'{OUT}/تقرير_مراجعة_التصنيف.md', 'w', encoding='utf-8').write('\n'.join(L))

# ---------- Excel ----------
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter
wb = Workbook(); wb.remove(wb.active)
H = Font(name='Arial', bold=True, color='FFFFFF'); F = PatternFill('solid', fgColor='4F6F52'); W = Alignment(wrap_text=True, vertical='top', horizontal='right')
def sheet(name, header, data, widths):
    ws = wb.create_sheet(name); ws.sheet_view.rightToLeft = True; ws.append(header)
    for c in ws[1]: c.font = H; c.fill = F; c.alignment = W
    for r in data: ws.append(r)
    for i, w in enumerate(widths, 1): ws.column_dimensions[get_column_letter(i)].width = w
    for row in ws.iter_rows(min_row=2):
        for c in row: c.alignment = W; c.font = Font(name='Arial', size=11)
sheet('الاقتراحات', ['المعرّف','الرمز','عنوان الرسالة','المبحث الحالي','المبحث المقترح','القاعدة','السبب','الجامعة','الدرجة','قرار الباحث'],
      [[p['uid'], p['code'], p['title'], p['current'], p['proposed'], p['rule'], p['reason'], rows[p['i']]['university'], rows[p['i']]['degree'], ''] for p in proposals],
      [10,9,70,18,18,7,60,22,10,14])
sheet('العدّاد', ['المبحث','قبل','يثبت','يخرج','يدخل','بعد'], [[c['topic'],c['before'],c['stays'],c['out'],c['into'],c['after']] for c in counter_rows if c['before'] or c['after']], [26,8,8,8,8,8])
sheet('وسوم التحقيق', ['المعرّف','الرمز','عنوان الرسالة','الوسم','ملحوظة','المبحث بعد الاقتراحات'],
      [[uid(rows[k]), rows[k]['code'], rows[k]['title'], v['tag'], v.get('note',''), after[k]] for k, v in sorted(tags.items())], [10,9,70,10,40,20])
sheet('السلاسل', ['السلسلة','عدد الرسائل','توزيعها بعد الاقتراحات'], [[k, n, '؛ '.join(f"{a} {b}" for a,b in c.items())] for k,n,c in split_after], [50,10,50])
sheet('ملحوظات المراجعين', ['الملحوظة'], [[s] for s in series_notes + doubts], [120])
wb.save(f'{OUT}/مراجعة_التصنيف.xlsx')

# ---------- النسخة المعلَّمة من القائمة (docx) ----------
doc = Document(LIST_DOCX)
year_tables = [t for t in doc.tables if len(t.columns) in (9, 12)]
# ترتيب جداول السنوات كترتيب السنوات في القائمة
order = sorted(set(r['year'] for r in rows))
tbl_by_year = {}
yi = 0
for t in year_tables:
    head = t.rows[0].cells[0].text
    m = re.search(r'14\d\d', head)
    y = int(m.group()) if m else None
    if y is None:  # الجدول بلا سنة في رأسه (1439)
        y = [yy for yy in order if yy not in tbl_by_year][0]
    tbl_by_year[y] = t
def shade(cell, hexcolor):
    tcPr = cell._tc.get_or_add_tcPr(); shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear'); shd.set(qn('w:color'), 'auto'); shd.set(qn('w:fill'), hexcolor); tcPr.append(shd)
prop_by_i = {p['i']: p for p in proposals}
marked = 0
for r in rows:
    p = prop_by_i.get(r['i'])
    if not p: continue
    t = tbl_by_year.get(r['year'])
    if t is None: continue
    row = t.rows[r['pos'] + 1]  # صفّان للرأس
    if ntitle(row.cells[1].text) != ntitle(r['title']): continue
    for c in row.cells: shade(c, 'FFF2CC')
    cell = row.cells[6]
    for par in cell.paragraphs:
        for run in par.runs: run.font.strike = True
    par = cell.add_paragraph(); run = par.add_run(f"← مقترح: {p['proposed']}"); run.bold = True; run.font.color.rgb = RGBColor(0xC0, 0x00, 0x00)
    par2 = cell.add_paragraph(); run2 = par2.add_run(f"(القاعدة {p['rule']}) {p['reason']}"); run2.font.color.rgb = RGBColor(0x7F, 0x00, 0x00); run2.font.size = run2.font.size
    marked += 1
# ملحوظة في أول المستند
first = doc.paragraphs[0]
note = first.insert_paragraph_before(f"نسخة مراجعة التصنيف — {datetime.date.today()}: الصفوف الملوّنة ({marked}) مقترحٌ نقلها؛ في خانة «نوع المبحث» المبحثُ الحالي مشطوبًا، ثم المقترح بالأحمر وسببه. لم يُنقل شيء؛ القرار للباحث.")
for run in note.runs: run.bold = True; run.font.color.rgb = RGBColor(0xC0, 0x00, 0x00)
doc.save(f'{OUT}/القائمة_المعلَّمة.docx')

# ---------- HTML للتحويل إلى PDF ----------
H_ = ['<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>القائمة المعلَّمة</title><style>',
      "body{font-family:'Amiri','Traditional Arabic',serif;font-size:12pt;margin:18mm 14mm} h1{font-size:16pt;text-align:center} h2{font-size:14pt;margin-top:18pt;page-break-after:avoid}",
      'table{border-collapse:collapse;width:100%;font-size:10.5pt;page-break-inside:auto} tr{page-break-inside:avoid} th,td{border:1px solid #999;padding:3pt 4pt;vertical-align:top} th{background:#e7ede3}',
      'tr.p td{background:#fff2cc} .cur{text-decoration:line-through;color:#666} .new{color:#c00000;font-weight:bold} .why{color:#7f0000;font-size:9.5pt}',
      '.note{border:1px solid #c00000;padding:6pt;color:#c00000;font-weight:bold;margin-bottom:12pt}',
      '</style></head><body>']
H_.append('<h1>قائمة الرسائل العلمية الشاملة — نسخة مراجعة التصنيف</h1>')
H_.append(f'<div class="note">الصفوف الملوّنة ({marked}) مقترحٌ نقلها: المبحث الحالي مشطوب، والمقترح بالأحمر وسببه. لم يُنقل شيء في القائمة؛ القرار للباحث. التاريخ: {datetime.date.today()}.</div>')
for y in order:
    H_.append(f'<h2>رسائل عام {y}هـ</h2><table><thead><tr><th>م</th><th>عنوان الرسالة</th><th>الباحث</th><th>الجامعة</th><th>الدرجة</th><th>نوع المبحث</th><th>الرمز</th></tr></thead><tbody>')
    for r in [x for x in rows if x['year'] == y]:
        p = prop_by_i.get(r['i']); n = norm[r['i']]
        cls = ' class="p"' if p else ''
        mab = (f'<span class="cur">{r["current"]}</span><br><span class="new">← {p["proposed"]}</span><br><span class="why">(القاعدة {p["rule"]}) {p["reason"]}</span>') if p else r['current']
        H_.append(f'<tr{cls}><td>{r["pos"]}</td><td>{r["title"]}</td><td>{n["researcher"]}</td><td>{n["university"]}</td><td>{n["degree"]}</td><td>{mab}</td><td>{r["code"] or ""}</td></tr>')
    H_.append('</tbody></table>')
H_.append('</body></html>')
open(f'{OUT}/القائمة_المعلَّمة.html', 'w', encoding='utf-8').write('\n'.join(H_))

print(f"صفوف: {len(rows)} | اقتراحات: {len(proposals)} | وسوم: {len(tags)} | معلَّم في Word: {marked} | غير محلول: {len(unresolved)}")
print("قبل/بعد:", [(c['topic'][:14], c['before'], c['after']) for c in counter_rows if c['before'] or c['after']])
print("سلاسل موزَّعة قبل:", len(split_before), "بعد:", len(split_after))
