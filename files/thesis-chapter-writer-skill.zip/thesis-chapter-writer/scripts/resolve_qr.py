#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""من وثيقة العيّنة الإحصائية (PDF فيها رموز QR) إلى دليل الروابط `data/theses_urls.json`.

    python3 scripts/resolve_qr.py materials/statistical_sample.pdf
    python3 scripts/resolve_qr.py materials/statistical_sample.pdf --mabhath "الجرح والتعديل"   # مبحث واحد

الخطوات: فكّ الرموز وربطها بصفوفها (decode_qr.py) ← تصحيح الحروف المعكوسة ← مطابقة كل صفّ
بعنوانٍ في القائمة الشاملة داخل مبحثه ← جلب رابط PDF لكل رمز من scanned.page ← كتابة الدليل.

**المطابقة بالتشابه اللفظي تُخطئ.** درجة كل مطابقة مثبتة في `match_score`، وما دون 60 يُعلَّم
`needs_review: true`؛ والحكم النهائي لغلاف الرسالة لا للدليل — يثبته وكيل البطاقة.
"""
import argparse
import difflib
import json
import os
import re
import sys
import time
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# لا يعمل داخل مجلد السكيل (للقراءة فقط) — شغّل scripts/setup.py أولًا لينسخ الأداة إلى مجلد العمل
if "/skills/" in ROOT.replace("\\", "/") or not os.access(ROOT, os.W_OK):
    sys.exit("هذا مجلد السكيل لا مجلد العمل. شغّل أولًا: python3 \"" + os.path.join(ROOT, "scripts", "setup.py") + "\"  ثم اعمل داخل عدة_كتابة_المباحث/")
sys.path.insert(0, os.path.join(ROOT, "scripts"))
from decode_qr import decode, rows as link_rows          # noqa: E402
from extract_text import clean as fix_ligatures         # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("pdf", help="وثيقة العيّنة الإحصائية")
ap.add_argument("--mabhath", default=None, help="اقتصر على مبحث واحد")
ap.add_argument("--out", default=os.path.join(ROOT, "data", "theses_urls.json"))
ap.add_argument("--work", default=os.path.join(ROOT, "qr"))
ap.add_argument("--no-net", action="store_true", help="بلا جلب الروابط (اختبار)")
a = ap.parse_args()

theses = json.load(open(os.path.join(ROOT, "data", "theses_norm.json"), encoding="utf-8"))
TOPICS = sorted({(t.get("topic") or "").strip() for t in theses if t.get("topic")})


def norm(s):
    s = re.sub(r"[ً-ْٰـ]", "", s or "")
    s = re.sub(r"[أإآ]", "ا", s).replace("ى", "ي").replace("ة", "ه").replace("ؤ", "و").replace("ئ", "ي")
    s = re.sub(r"[^ء-ي0-9 ]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def topic_of(mabhath_text):
    """«مبحث اجلرح والتعديل» ← «الجرح والتعديل» في القائمة."""
    t = norm(fix_ligatures(mabhath_text or "")).replace("مبحث", "").strip()
    best = max(TOPICS, key=lambda x: difflib.SequenceMatcher(None, norm(x), t).ratio())
    return best if difflib.SequenceMatcher(None, norm(best), t).ratio() >= 0.6 else None


def candidates(row_text, topic, k=5):
    """أفضل k عناوين من القائمة كلها، مع أفضلية 8 درجات لعناوين المبحث نفسه."""
    txt = norm(fix_ligatures(row_text))
    scored = []
    for t in theses:
        ttl = norm(t.get("title") or "")
        if not ttl:
            continue
        tt = {w for w in ttl.split() if len(w) > 2}
        cont = sum(1 for w in tt if w in txt) / len(tt) if tt else 0
        seq = difflib.SequenceMatcher(None, ttl, txt).ratio()
        sc = 100 * (0.7 * cont + 0.3 * seq) + (8 if topic and (t.get("topic") or "").strip() == topic else 0)
        scored.append((sc, t))
    scored.sort(key=lambda x: -x[0])
    return [(round(min(sc, 100), 1), t) for sc, t in scored[:k]]


def year_in_period(year, period_text):
    """«عام 1431 - 1433» — هل سنة الصفّ المطابَق داخل كتلة الوثيقة؟ (لا كتلة = مقبول)"""
    ys = [int(x) for x in re.findall(r"1[34]\d\d", fix_ligatures(period_text or ""))]
    if not ys or not year:
        return True
    lo, hi = min(ys), max(ys)
    return lo <= int(year) <= hi


def fetch_pdf(code, tries=3):
    url = f"https://scanned.page/api/qr-code?uId={code}"
    for i in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"}), timeout=25) as r:
                j = json.loads(r.read().decode("utf-8", "replace"))
            return (j.get("data") or {}).get("pdf")
        except Exception as e:                                   # noqa: BLE001
            if i == tries - 1:
                return None
            time.sleep(2 * (i + 1))


# ── ١) فكّ الرموز وربطها بصفوفها ──
os.makedirs(a.work, exist_ok=True)
decoded = decode(a.pdf, a.work)
linked = link_rows(a.pdf, a.work, decoded) or json.load(open(os.path.join(a.work, "rows.json"), encoding="utf-8"))
with_code = [r for r in linked if r.get("code")]
print(f"صفوف الوثيقة: {len(linked)} — منها {len(with_code)} برمز QR")

# ── ٢) المطابقة ──
out = {}
if os.path.exists(a.out):
    out = json.load(open(a.out, encoding="utf-8"))          # يُحافَظ على ما سبق حلّه
# مرشَّحات كل صفّ، ثم توزيع لا يعطي عنوانًا واحدًا لرمزين (الأعلى درجةً أولًا)
pending = []
for r in with_code:
    topic = topic_of(r.get("mabhath"))
    if a.mabhath and topic != a.mabhath.strip():
        continue
    pending.append((r, topic, candidates(r.get("text") or "", topic)))
pending.sort(key=lambda x: -(x[2][0][0] if x[2] else 0))
taken = set()
low, matched = [], 0
for r, topic, cands in pending:
    code = r["code"]
    hit, sc = None, 0.0
    for c_sc, c_t in cands:
        if c_t.get("title") not in taken:
            hit, sc = c_t, c_sc
            break
    if hit:
        taken.add(hit.get("title"))
    entry = {
        "mabhath": topic or fix_ligatures(r.get("mabhath") or ""),
        "period": fix_ligatures(r.get("period") or ""),
        "row": r.get("row"),
        "row_text": fix_ligatures(r.get("text") or "")[:300],
        "match_title": hit.get("title") if hit else None,
        "year": hit.get("year") if hit else None,
        "researcher": hit.get("researcher") if hit else None,
        "university": hit.get("university_norm") or hit.get("university") if hit else None,
        "degree": hit.get("degree_norm") or hit.get("degree") if hit else None,
        "topic": topic,
        "list_topic": (hit.get("topic") or "").strip() if hit else None,
        "match_score": sc,
        "needs_review": sc < 60 or (bool(hit) and topic is not None and (hit.get("topic") or "").strip() != topic)
                        or (bool(hit) and not year_in_period(hit.get("year"), r.get("period"))),
        "code": code,
        "qr_page": f"https://scanned.page/{code}",
        "pdf": (out.get(code) or {}).get("pdf"),
    }
    if hit:
        matched += 1
    if entry["needs_review"]:
        why = ("دون 60" if sc < 60 else
               f"مصنَّفة في القائمة تحت «{entry['list_topic']}»" if (hit and topic and entry['list_topic'] != topic) else
               f"سنة الصفّ {entry['year']} خارج كتلة الوثيقة «{entry['period']}»")
        low.append((code, sc, why, entry["row_text"][:55], (hit or {}).get("title", "")[:50]))
    out[code] = entry
print(f"طُوبق {matched} من {len(pending)} صفًّا بعنوان في القائمة"
      + (f" — {len(low)} تحتاج مراجعة" if low else ""))
for c, sc, why, rt, ht in low[:10]:
    print(f"   ⚠️  [{c}] {sc} ({why}): «{rt}» ≈ «{ht}»")

# ── ٣) الروابط ──
if not a.no_net:
    todo = [c for c, v in out.items() if not v.get("pdf") and (not a.mabhath or v.get("topic") == a.mabhath.strip())]
    got = 0
    for i, c in enumerate(todo, 1):
        pdf = fetch_pdf(c)
        if pdf:
            out[c]["pdf"] = pdf
            got += 1
        print(f"\r   جلب الروابط {i}/{len(todo)}", end="", flush=True)
    print()
    print(f"حُلّ {got} رابط PDF جديد" + (f"، وتعذّر {len(todo) - got}" if len(todo) - got else ""))

os.makedirs(os.path.dirname(a.out), exist_ok=True)
json.dump(out, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
have = sum(1 for v in out.values() if v.get("pdf"))
print(f"كُتب {a.out}: {len(out)} رمزًا، {have} منها برابط PDF مباشر.")

# ── ٤) ملف العيّنة لكل مبحث (صفوف وثيقة العيّنة هي عيّنة الباحث نفسها) ──
sdir = os.path.join(ROOT, "data", "samples")
os.makedirs(sdir, exist_ok=True)
by_topic = {}
for v in out.values():
    if v.get("topic") and (not a.mabhath or v["topic"] == a.mabhath.strip()):
        by_topic.setdefault(v["topic"], []).append(v)
for topic, vs in by_topic.items():
    sp = os.path.join(sdir, topic.replace(" ", "_") + ".json")
    if os.path.exists(sp):
        continue                                            # لا يُمسّ ملف عيّنة موجود
    rows_out = [{"code": v["code"], "period": v.get("period"), "row": v.get("row"), "score": v.get("match_score"),
                 "year": v.get("year"), "title": v.get("match_title"), "researcher": v.get("researcher"),
                 "university": v.get("university"), "degree": v.get("degree"), "list_topic": v.get("list_topic"),
                 "needs_review": v.get("needs_review"), "pdf_url": v.get("pdf")} for v in vs]
    json.dump(rows_out, open(sp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"كُتب ملف العيّنة data/samples/{os.path.basename(sp)}: {len(rows_out)} رسالة"
          + (f" — {sum(1 for r in rows_out if r['needs_review'])} تحتاج مراجعة من الغلاف" if any(r["needs_review"] for r in rows_out) else ""))
print("التالي: python3 scripts/fetch_thesis.py --list \"<المبحث>\"")
