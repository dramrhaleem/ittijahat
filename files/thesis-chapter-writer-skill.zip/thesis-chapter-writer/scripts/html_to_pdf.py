#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""تحويل صفحة HTML (عربية، من اليمين إلى اليسار) إلى PDF بمتصفح خفي.
    python3 scripts/html_to_pdf.py <ملف.html> <ملف.pdf>
يعتمد على Playwright/Chromium المثبَّتين مع الأداة؛ وإن غابا فيُبلغ ولا يُخفق صامتًا.
"""
import sys, os, asyncio
async def main(src, dst):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page()
        await pg.goto('file://' + os.path.abspath(src))
        await pg.wait_for_timeout(500)
        await pg.pdf(path=dst, format='A4', print_background=True,
                     margin={'top':'15mm','bottom':'15mm','left':'12mm','right':'12mm'},
                     display_header_footer=True,
                     header_template='<div></div>',
                     footer_template='<div style="font-size:9pt;width:100%;text-align:center;font-family:Amiri,serif;"><span class="pageNumber"></span></div>')
        await b.close()
if __name__ == '__main__':
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    try:
        asyncio.run(main(sys.argv[1], sys.argv[2])); print('written', sys.argv[2], os.path.getsize(sys.argv[2]))
    except Exception as e:
        print('تعذّر التحويل إلى PDF:', e); sys.exit(2)
