#!/bin/bash
# تحويل Word إلى PDF بـLibreOffice إن وُجد (مع مهلة)، وإلا يُبلغ. الاستخدام: docx_to_pdf.sh <ملف.docx> [مجلد المخرج]
set -e
IN="$1"; OUTDIR="${2:-$(dirname "$IN")}"
command -v soffice >/dev/null 2>&1 || { echo "⚠️  LibreOffice غير مثبَّت؛ أخرج PDF من Word (حفظ باسم → PDF)."; exit 2; }
TMP=$(mktemp -d); cp "$IN" "$TMP/doc.docx"
timeout 240 soffice --headless --convert-to pdf --outdir "$TMP" "$TMP/doc.docx" >/dev/null 2>&1 || { echo "⚠️  تعلّق التحويل أو أخفق؛ أخرج PDF من Word."; exit 2; }
BASE=$(basename "$IN" .docx); mv "$TMP/doc.pdf" "$OUTDIR/$BASE.pdf"; rm -rf "$TMP"
echo "written $OUTDIR/$BASE.pdf"
