#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""مسوّدة Markdown → ملف Word عربي على قالب إثراء المتون، بحواشٍ حقيقية في أسفل الصفحة — بايثون خالص (بلا نود ولا مكتبات).

    CH_MD=out/علل_الحديث.md CH_OUT=out/علل_الحديث CH_DOCX="out/المبحث.docx" python3 scripts/build_docx.py
    python3 scripts/build_docx.py --md out/علل_الحديث.md --out out/علل_الحديث --docx "out/المبحث.docx" [--title "عنوان البحث"]

النسخة المكافئة لـbuild_docx.js (تُستعمل حيث لا نود، كبيئة ChatGPT). القواعد نفسها:
  #  عنوان المبحث (وسط) · ## المطالب/خلاصة المبحث/الفهرس · ### العناصر · **عريض** · ^[حاشية] · جداول | · [يوضع هنا الرسم…] · 1- بنود.
التنسيق: Traditional Arabic 18 كشيدة خفيفة، قبل الفقرة 6 نقاط · العنوان الأول PT Bold Heading 20 وسط · الثاني Sakkal Majalla 20 عريض ·
الحاشية Traditional Arabic 14 بإزاحة معلَّقة، ورقمها مرتفعًا بين قوسين · A4 وهوامش 2.54/2.54/2.5/2.5 سم · رقم الصفحة في الرأس مع عنوان
البحث، والصفحة الأولى بلا رأس. التفصيل في references/formatting.md
"""
import os, re, sys, zipfile, argparse, datetime
from xml.sax.saxutils import escape as _esc

FONT, FONT_H1, FONT_H2 = 'Traditional Arabic', 'PT Bold Heading', 'Sakkal Majalla'
BODY_SIZE, FN_SIZE, TEXT_WIDTH = 36, 28, 9070
DEFAULT_TITLE = 'الاتجاهات الحديثية في العقد الرابع من القرن الخامس عشر الهجري في المملكة العربية السعودية'
CHART = [(re.compile(r'الزمني|السنوات|1431'), 'chart_years.png'), (re.compile(r'الجامعات|المكاني'), 'chart_universities.png'),
         (re.compile(r'الدرجة'), 'chart_degree.png'), (re.compile(r'الموضوع'), 'chart_topics.png')]
CHART_SIZE = {'chart_years.png': (560, 286), 'chart_universities.png': (520, 324), 'chart_degree.png': (320, 320), 'chart_topics.png': (560, 331)}
EMU = 9525  # بكسل (96 نقطة/بوصة) → EMU

W_NS = ('xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
        'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
        'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
        'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"')


def esc(s):
    return _esc(str(s), {'"': '&quot;'})


def clean(t):
    t = t.replace('**', '')
    t = re.sub(r'(^|\s)\*(?=\S)', r'\1', t)
    t = re.sub(r'(\S)\*(?=\s|$|[،.؛:])', r'\1', t)
    return t.replace('`', '')


# ---------------------------------------------------------------- الحواشي
FOOTNOTES = {}


def split_footnotes(text):
    parts, buf, i = [], '', 0
    while i < len(text):
        if text[i] == '^' and i + 1 < len(text) and text[i + 1] == '[':
            depth, j, note = 1, i + 2, ''
            while j < len(text) and depth > 0:
                if text[j] == '[':
                    depth += 1
                elif text[j] == ']':
                    depth -= 1
                    if not depth:
                        break
                note += text[j]; j += 1
            if buf:
                parts.append(('t', buf)); buf = ''
            n = len(FOOTNOTES) + 1
            FOOTNOTES[n] = note.strip()
            parts.append(('fn', n))
            i = j + 1; continue
        buf += text[i]; i += 1
    if buf:
        parts.append(('t', buf))
    return parts


# ---------------------------------------------------------------- الأسطر (runs)
def rpr(font=FONT, size=BODY_SIZE, bold=False, style=None):
    x = '<w:rPr>'
    if style:
        x += f'<w:rStyle w:val="{style}"/>'
    x += f'<w:rFonts w:ascii="{font}" w:hAnsi="{font}" w:cs="{font}" w:eastAsia="{font}"/>'
    if bold:
        x += '<w:b/><w:bCs/>'
    x += f'<w:sz w:val="{size}"/><w:szCs w:val="{size}"/><w:rtl/></w:rPr>'
    return x


def run(text, **kw):
    if text == '':
        return ''
    return f'<w:r>{rpr(**kw)}<w:t xml:space="preserve">{esc(text)}</w:t></w:r>'


def inline_runs(text, **kw):
    out, last = [], 0
    for m in re.finditer(r'\*\*(.+?)\*\*', text):
        if m.start() > last:
            out.append(run(clean(text[last:m.start()]), **kw))
        out.append(run(clean(m.group(1)), **dict(kw, bold=True)))
        last = m.end()
    if last < len(text):
        out.append(run(clean(text[last:]), **kw))
    return ''.join(out)


def fn_ref(n):
    r = f'<w:rPr><w:rStyle w:val="FootnoteReference"/></w:rPr>'
    return (f'<w:r>{r}<w:t>(</w:t></w:r><w:r>{r}<w:footnoteReference w:id="{n}"/></w:r><w:r>{r}<w:t>)</w:t></w:r>')


def runs_with_notes(text, **kw):
    out = []
    for kind, v in split_footnotes(text):
        out.append(fn_ref(v) if kind == 'fn' else inline_runs(v, **kw))
    return ''.join(out)


# ---------------------------------------------------------------- الفقرات
def para(runs, jc='lowKashida', spacing=(120, 0, 240), ind='', style=None, tabs=''):
    before, after, line = spacing
    p = '<w:p><w:pPr>'
    if style:
        p += f'<w:pStyle w:val="{style}"/>'
    p += tabs
    p += f'<w:bidi/><w:spacing w:before="{before}" w:after="{after}" w:line="{line}" w:lineRule="auto"/>{ind}<w:jc w:val="{jc}"/></w:pPr>'
    return p + runs + '</w:p>'


def body(text):
    return para(runs_with_notes(text), ind='<w:ind w:firstLine="432"/>')


def h1(text):
    return para(run(clean(text), font=FONT_H1, size=40), jc='center', spacing=(240, 120, 240), style='Heading1')


def h2(text):
    return para(run(clean(text), font=FONT_H2, size=40, bold=True), jc='right', spacing=(240, 120, 240), style='Heading2')


def h3(text):
    return para(run(clean(text), size=36, bold=True), jc='right', spacing=(240, 120, 240), style='Heading3')


def list_item(text):
    return para(runs_with_notes(text), spacing=(60, 0, 240), ind='<w:ind w:right="504"/>')


IMAGES = []  # (rId, filename, bytes)


def img(out_dir, file):
    path = os.path.join(out_dir, file)
    if not os.path.exists(path):
        print('CHART FILE MISSING:', path, file=sys.stderr)
        return body(f'[يوضع هنا الرسم: {file}]')
    w, h = CHART_SIZE.get(file, (520, 320))
    rid = f'rIdImg{len(IMAGES) + 1}'
    IMAGES.append((rid, file, open(path, 'rb').read()))
    n = len(IMAGES)
    cx, cy = w * EMU, h * EMU
    drawing = (f'<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/>'
               f'<wp:docPr id="{n}" name="chart{n}"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
               f'<pic:pic><pic:nvPicPr><pic:cNvPr id="{n}" name="{esc(file)}"/><pic:cNvPicPr/></pic:nvPicPr>'
               f'<pic:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
               f'<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>'
               f'</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>')
    return para(drawing, jc='center', spacing=(160, 80, 240))


def table(rows):
    cells = [r[1:-1].split('|') for r in rows if not re.fullmatch(r'\|[\s\-|]+\|', r)]
    cells = [[c.strip() for c in r] for r in cells]
    n = len(cells[0])
    if n == 6:
        W = [480, 3870, 1750, 1430, 830, 710]
    elif n == 3:
        W = [2400, 830, 5840]
    else:
        W = [TEXT_WIDTH // n] * n
    W[-1] += TEXT_WIDTH - sum(W)
    b = '<w:top w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:left w:val="single" w:sz="4" w:space="0" w:color="000000"/>' \
        '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:right w:val="single" w:sz="4" w:space="0" w:color="000000"/>' \
        '<w:insideH w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
    x = (f'<w:tbl><w:tblPr><w:tblW w:w="{TEXT_WIDTH}" w:type="dxa"/><w:bidiVisual/><w:tblBorders>{b}</w:tblBorders>'
         f'<w:tblLayout w:type="fixed"/><w:tblCellMar><w:top w:w="60" w:type="dxa"/><w:left w:w="90" w:type="dxa"/>'
         f'<w:bottom w:w="60" w:type="dxa"/><w:right w:w="90" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>'
         + ''.join(f'<w:gridCol w:w="{w}"/>' for w in W) + '</w:tblGrid>')
    for ri, row in enumerate(cells):
        row = (row + [''] * n)[:n]
        x += '<w:tr>' + ('<w:trPr><w:tblHeader/></w:trPr>' if ri == 0 else '')
        for ci, c in enumerate(row):
            shd = '<w:shd w:val="clear" w:color="auto" w:fill="DEE6F2"/>' if ri == 0 else ''
            jc = 'right' if len(c) > 24 else 'center'
            x += (f'<w:tc><w:tcPr><w:tcW w:w="{W[ci]}" w:type="dxa"/>{shd}</w:tcPr>'
                  + para(inline_runs(c, size=26, bold=(ri == 0)), jc=jc, spacing=(0, 0, 260)) + '</w:tc>')
        x += '</w:tr>'
    x += '</w:tbl>' + para('', jc='right', spacing=(0, 200, 240))
    return x


# ---------------------------------------------------------------- تحليل Markdown
def parse(md, out_dir):
    lines = md.split('\n'); out = []; i = 0
    while i < len(lines):
        t = lines[i].strip()
        if t == '' or t == '---':
            i += 1; continue
        if t.startswith('# '):
            out.append(h1(t[2:].strip())); i += 1; continue
        if t.startswith('## '):
            txt = t[3:].strip()
            out.append(h2(txt) if re.match(r'^(المطلب|خلاصة المبحث|فهرس)', txt) else h1(txt)); i += 1; continue
        if t.startswith('### '):
            txt = t[4:].strip()
            out.append(h2(txt) if re.match(r'^المطلب', txt) else h3(txt)); i += 1; continue
        if t.startswith('[يوضع هنا'):
            hit = next((f for rx, f in CHART if rx.search(t)), None)
            if hit:
                out.append(img(out_dir, hit))
            else:
                print('UNMATCHED CHART:', t, file=sys.stderr); out.append(body(t))
            i += 1; continue
        if t.startswith('|'):
            rows = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                rows.append(lines[i].strip()); i += 1
            out.append(table(rows)); continue
        if re.match(r'^\d+-\s', t):
            out.append(list_item(t)); i += 1; continue
        out.append(body(t)); i += 1
    return ''.join(out)


# ---------------------------------------------------------------- الأجزاء
def styles_xml():
    def st(sid, name, kind, ppr='', rpr_='', extra=''):
        return (f'<w:style w:type="{kind}" w:styleId="{sid}"><w:name w:val="{name}"/>{extra}'
                f'<w:pPr>{ppr}</w:pPr><w:rPr>{rpr_}</w:rPr></w:style>')
    fonts = f'<w:rFonts w:ascii="{FONT}" w:hAnsi="{FONT}" w:cs="{FONT}" w:eastAsia="{FONT}"/>'
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles {W_NS}>'
            f'<w:docDefaults><w:rPrDefault><w:rPr>{fonts}<w:sz w:val="{BODY_SIZE}"/><w:szCs w:val="{BODY_SIZE}"/>'
            f'<w:lang w:val="ar-SA" w:bidi="ar-SA"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:bidi/></w:pPr></w:pPrDefault></w:docDefaults>'
            + st('Normal', 'Normal', 'paragraph', extra='<w:qFormat/>')
            + st('Heading1', 'heading 1', 'paragraph', '<w:keepNext/><w:outlineLvl w:val="0"/>', f'<w:rFonts w:ascii="{FONT_H1}" w:hAnsi="{FONT_H1}" w:cs="{FONT_H1}"/><w:sz w:val="40"/><w:szCs w:val="40"/>', '<w:basedOn w:val="Normal"/><w:qFormat/>')
            + st('Heading2', 'heading 2', 'paragraph', '<w:keepNext/><w:outlineLvl w:val="1"/>', f'<w:rFonts w:ascii="{FONT_H2}" w:hAnsi="{FONT_H2}" w:cs="{FONT_H2}"/><w:b/><w:bCs/><w:sz w:val="40"/><w:szCs w:val="40"/>', '<w:basedOn w:val="Normal"/><w:qFormat/>')
            + st('Heading3', 'heading 3', 'paragraph', '<w:keepNext/><w:outlineLvl w:val="2"/>', '<w:b/><w:bCs/>', '<w:basedOn w:val="Normal"/><w:qFormat/>')
            + st('FootnoteText', 'footnote text', 'paragraph', '<w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/>', f'<w:sz w:val="{FN_SIZE}"/><w:szCs w:val="{FN_SIZE}"/>', '<w:basedOn w:val="Normal"/>')
            + f'<w:style w:type="character" w:styleId="FootnoteReference"><w:name w:val="footnote reference"/><w:rPr>{fonts}<w:vertAlign w:val="superscript"/><w:sz w:val="36"/><w:szCs w:val="36"/></w:rPr></w:style>'
            + '</w:styles>')


def footnotes_xml():
    x = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:footnotes {W_NS}>'
         '<w:footnote w:type="separator" w:id="-1"><w:p><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:r><w:separator/></w:r></w:p></w:footnote>'
         '<w:footnote w:type="continuationSeparator" w:id="0"><w:p><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:r><w:continuationSeparator/></w:r></w:p></w:footnote>')
    r = '<w:rPr><w:rStyle w:val="FootnoteReference"/></w:rPr>'
    for n, txt in FOOTNOTES.items():
        runs = (f'<w:r>{r}<w:t>(</w:t></w:r><w:r>{r}<w:footnoteRef/></w:r><w:r>{r}<w:t xml:space="preserve">) </w:t></w:r>'
                + inline_runs(txt, size=FN_SIZE))
        x += f'<w:footnote w:id="{n}">' + para(runs, jc='lowKashida', spacing=(0, 0, 240), ind='<w:ind w:left="340" w:hanging="340"/>', style='FootnoteText') + '</w:footnote>'
    return x + '</w:footnotes>'


def header_xml(title, first=False):
    if first:
        inner = '<w:p><w:pPr><w:bidi/></w:pPr></w:p>'
    else:
        f = f'<w:rPr><w:rFonts w:ascii="{FONT}" w:hAnsi="{FONT}" w:cs="{FONT}"/><w:sz w:val="28"/><w:szCs w:val="28"/><w:rtl/></w:rPr>'
        field = (f'<w:r>{f}<w:fldChar w:fldCharType="begin"/></w:r><w:r>{f}<w:instrText xml:space="preserve"> PAGE </w:instrText></w:r>'
                 f'<w:r>{f}<w:fldChar w:fldCharType="separate"/></w:r><w:r>{f}<w:t>1</w:t></w:r><w:r>{f}<w:fldChar w:fldCharType="end"/></w:r>')
        inner = para(run(title, size=28) + f'<w:r>{f}<w:tab/></w:r>' + run('(', size=28) + field + run(')', size=28),
                     jc='right', spacing=(0, 0, 240), tabs=f'<w:tabs><w:tab w:val="right" w:pos="{TEXT_WIDTH}"/></w:tabs>')
    return f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:hdr {W_NS}>{inner}</w:hdr>'


def document_xml(body_xml):
    sect = ('<w:sectPr><w:headerReference w:type="default" r:id="rIdH1"/><w:headerReference w:type="first" r:id="rIdH2"/>'
            '<w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1418" w:bottom="1440" w:left="1418" w:header="680" w:footer="567" w:gutter="0"/>'
            '<w:titlePg/><w:bidi/></w:sectPr>')
    return f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document {W_NS}><w:body>{body_xml}{sect}</w:body></w:document>'


def build(md_path, out_dir, docx_path, title):
    md = open(md_path, encoding='utf-8').read()
    body_xml = parse(md, out_dir)
    rels = ('<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            '<Relationship Id="rIdSettings" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>'
            '<Relationship Id="rIdFn" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes" Target="footnotes.xml"/>'
            '<Relationship Id="rIdH1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/>'
            '<Relationship Id="rIdH2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header2.xml"/>')
    for rid, file, _ in IMAGES:
        rels += f'<Relationship Id="{rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/{file}"/>'
    doc_rels = f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">{rels}</Relationships>'
    root_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                 '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
                 '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
                 '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>')
    ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
          '<Default Extension="png" ContentType="image/png"/>'
          '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
          '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
          '<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>'
          '<Override PartName="/word/footnotes.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml"/>'
          '<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>'
          '<Override PartName="/word/header2.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>'
          '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
          '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>')
    settings = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings {W_NS}><w:defaultTabStop w:val="720"/>'
                '<w:footnotePr><w:footnote w:id="-1"/><w:footnote w:id="0"/></w:footnotePr><w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat></w:settings>')
    now = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
    core = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            f'<dc:title>{esc(title)}</dc:title><dcterms:created xsi:type="dcterms:W3CDTF">{now}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">{now}</dcterms:modified></cp:coreProperties>')
    app = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
           'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>build_docx.py</Application></Properties>')
    os.makedirs(os.path.dirname(os.path.abspath(docx_path)), exist_ok=True)
    with zipfile.ZipFile(docx_path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', ct)
        z.writestr('_rels/.rels', root_rels)
        z.writestr('word/document.xml', document_xml(body_xml))
        z.writestr('word/_rels/document.xml.rels', doc_rels)
        z.writestr('word/styles.xml', styles_xml())
        z.writestr('word/settings.xml', settings)
        z.writestr('word/footnotes.xml', footnotes_xml())
        z.writestr('word/header1.xml', header_xml(title))
        z.writestr('word/header2.xml', header_xml(title, first=True))
        for _, file, data in IMAGES:
            z.writestr('word/media/' + file, data)
        z.writestr('docProps/core.xml', core)
        z.writestr('docProps/app.xml', app)
    print('written', docx_path, os.path.getsize(docx_path), '| حواشي:', len(FOOTNOTES), '| رسوم:', len(IMAGES))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--md', default=os.environ.get('CH_MD'))
    ap.add_argument('--out', default=os.environ.get('CH_OUT'))
    ap.add_argument('--docx', default=os.environ.get('CH_DOCX'))
    ap.add_argument('--title', default=os.environ.get('CH_TITLE') or DEFAULT_TITLE)
    a = ap.parse_args()
    if not (a.md and a.docx):
        sys.exit('حدّد --md و--docx (أو المتغيّرين CH_MD وCH_DOCX)')
    out = a.out or os.path.splitext(a.md)[0]
    build(a.md, out, a.docx, a.title)


if __name__ == '__main__':
    main()
