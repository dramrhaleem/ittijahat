#!/usr/bin/env python3
"""تصدير بطاقات التحليل إلى Excel: ورقة «ملخص» + ورقة لكل رسالة.

    python3 scripts/cards_to_xlsx.py "الجرح والتعديل"                # → out/بطاقات_التحليل_<المبحث>.xlsx
    python3 scripts/cards_to_xlsx.py "الجرح والتعديل" --out ملف.xlsx

يقرأ data/cards/<المبحث>/*.json ويكتب: الملخص (رمز، عنوان، باحث، جامعة، درجة، سنة، صفحات، نوع الدراسة،
حكم كل بند)، ثم لكل رسالة ورقة فيها بنودها العشرة (المعيار، المؤشر، التحليل، الشواهد بصفحاتها، الحكم)
وملحوظات المبحث (سمات، تميّز، نقد، مقتبسات، نتائج، توصيات).
"""
import argparse
import glob
import json
import os
import re
import sys

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ap = argparse.ArgumentParser()
ap.add_argument("mabhath")
ap.add_argument("--out", default=None)
a = ap.parse_args()
SLUG = a.mabhath.strip().replace(" ", "_")
cdir = os.path.join(ROOT, "data", "cards", SLUG)
files = sorted(glob.glob(os.path.join(cdir, "*.json")))
if not files:
    sys.exit(f"لا بطاقات في {cdir}")
out = a.out or os.path.join(ROOT, "out", f"بطاقات_التحليل_{SLUG}.xlsx")
os.makedirs(os.path.dirname(out), exist_ok=True)

HEAD = Font(bold=True, name="Traditional Arabic", size=13)
BODY = Font(name="Traditional Arabic", size=12)
FILL = PatternFill("solid", fgColor="DEE6F2")
WRAP = Alignment(wrap_text=True, vertical="top", horizontal="right", readingOrder=2)


_used_names = set()


def sheet_name(s):
    s = re.sub(r"[\\/*?:\[\]]", " ", s)[:28].strip() or "ورقة"    # ٢٨ + لاحقة التمييز ≤ ٣١ (حدّ Excel)
    base, k = s, 1
    while s in _used_names:
        k += 1
        s = f"{base[:26]} {k}"
    _used_names.add(s)
    return s


def evid_text(ev):
    if isinstance(ev, list):
        parts = []
        for e in ev:
            if isinstance(e, dict):
                t = e.get("text") or e.get("quote") or ""
                pg = e.get("page") or e.get("p") or ""
                parts.append(f"{t} (ص {pg})" if pg else t)
            else:
                parts.append(str(e))
        return "\n".join(parts)
    return str(ev or "")


wb = Workbook()
ws = wb.active
ws.title = "ملخص"
ws.sheet_view.rightToLeft = True
cards = [json.load(open(f, encoding="utf-8")) for f in files]
crit = []
for c in cards:
    for it in c.get("items") or []:
        n = it.get("criterion") or f"بند {it.get('no')}"
        if n not in crit:
            crit.append(n)
cols = ["الرمز", "مصدر البطاقة", "العنوان", "الباحث", "الجامعة", "الدرجة", "السنة", "الصفحات", "نوع الدراسة"] + [f"حكم: {x}" for x in crit]
ws.append(cols)
for c in cards:
    m = c.get("meta") or {}
    judg = {(it.get("criterion") or f"بند {it.get('no')}"): it.get("judgment") for it in (c.get("items") or [])}
    src = "بطاقة الباحث اليدوية" if c.get("manual") else "الأداة"
    ws.append([c.get("code"), src, m.get("title"), m.get("researcher"), m.get("university"), m.get("degree"),
               m.get("year_h") or m.get("year"), m.get("pages"), m.get("study_type")] + [judg.get(x, "") for x in crit])
for i, w in enumerate([10, 16, 60, 28, 22, 10, 8, 9, 16] + [18] * len(crit), 1):
    ws.column_dimensions[get_column_letter(i)].width = w
for cell in ws[1]:
    cell.font = HEAD
    cell.fill = FILL
    cell.alignment = WRAP
for row in ws.iter_rows(min_row=2):
    for cell in row:
        cell.font = BODY
        cell.alignment = WRAP
ws.freeze_panes = "A2"

for c in cards:
    m = c.get("meta") or {}
    w2 = wb.create_sheet(sheet_name(f"{c.get('code')} {m.get('title') or ''}"))
    w2.sheet_view.rightToLeft = True
    w2.append(["العنوان", m.get("title")])
    w2.append(["مصدر البطاقة", "بطاقة الباحث اليدوية — حُمِّلت كما هي" if c.get("manual") else "الأداة"])
    w2.append(["الباحث", m.get("researcher")])
    w2.append(["الجامعة / الكلية", f"{m.get('university') or ''} — {m.get('faculty_dept') or ''}"])
    w2.append(["الدرجة / السنة / الصفحات", f"{m.get('degree') or ''} / {m.get('year_h') or m.get('year') or ''} / {m.get('pages') or ''}"])
    w2.append(["نوع الدراسة", m.get("study_type")])
    w2.append(["المنهج المصرَّح به", m.get("method_declared")])
    w2.append([])
    w2.append(["#", "المعيار", "المؤشر", "التحليل", "الشواهد (بصفحاتها)", "الحكم"])
    hdr_row = w2.max_row
    for it in c.get("items") or []:
        w2.append([it.get("no"), it.get("criterion"), it.get("indicator"), it.get("analysis"), evid_text(it.get("evidence")), it.get("judgment")])
    w2.append([])
    notes = c.get("chapter_notes") or {}
    for key, label in (("features", "سمات"), ("distinctions", "أوجه تميّز"), ("critiques", "مواطن نقد"),
                       ("quotable", "مقتبسات"), ("key_results", "أبرز النتائج"), ("recommendations", "التوصيات")):
        v = notes.get(key)
        if not v:
            continue
        w2.append([label])
        w2.cell(row=w2.max_row, column=1).font = HEAD
        for x in (v if isinstance(v, list) else [v]):
            if isinstance(x, dict):
                x = "؛ ".join(f"{k}: {val}" for k, val in x.items())
            w2.append(["", str(x)])
    if c.get("reading_coverage"):
        w2.append([])
        w2.append(["ما قُرئ", c.get("reading_coverage")])
    for i, wdt in enumerate([5, 26, 26, 70, 70, 14], 1):
        w2.column_dimensions[get_column_letter(i)].width = wdt
    for row in w2.iter_rows():
        for cell in row:
            cell.font = BODY
            cell.alignment = WRAP
    for cell in w2[hdr_row]:
        cell.font = HEAD
        cell.fill = FILL

wb.save(out)
n_ev = sum(len(it.get("evidence") or []) for c in cards for it in (c.get("items") or []) if isinstance(it.get("evidence"), list))
print(f"كُتب {out}: {len(cards)} رسالة، {n_ev} شاهدًا.")
