# -*- coding: utf-8 -*-
"""توحيد بيانات قائمة الرسائل الشاملة (theses_all.json) → data/theses_norm.json/csv
الاستخدام: python3 scripts/normalize_data.py <path/to/theses_all.json>
"""
import json, csv, sys, re, unicodedata, collections
UNIV = {
 'أم القرى':'جامعة أم القرى','جامعة أم القرى':'جامعة أم القرى',
 'الجامعة الإسلامية':'الجامعة الإسلامية بالمدينة المنورة',
 'الإمام محمد بن سعود':'جامعة الإمام محمد بن سعود الإسلامية',
 'الملك سعود':'جامعة الملك سعود','الملك خالد':'جامعة الملك خالد',
 'القصيم':'جامعة القصيم','جامعة القصيم':'جامعة القصيم',
 'طيبة':'جامعة طيبة','جامعة طيبة':'جامعة طيبة','طيبة لم تتضح لي':'جامعة طيبة',
 'حائل':'جامعة حائل','الملك فيصل':'جامعة الملك فيصل',
 'سطام بن عبد العزيز':'جامعة الأمير سطام بن عبد العزيز',
 'الإمام عبد الرحمن بن فيصل':'جامعة الإمام عبد الرحمن بن فيصل','عبد الرحمن بن فيصل':'جامعة الإمام عبد الرحمن بن فيصل','الدمام':'جامعة الإمام عبد الرحمن بن فيصل',
 'المجمعة':'جامعة المجمعة','الأميرة نورة بنت عبد الرحمن':'جامعة الأميرة نورة بنت عبد الرحمن','الأميرة نورة':'جامعة الأميرة نورة بنت عبد الرحمن',
 'تبوك':'جامعة تبوك','نجران':'جامعة نجران','الملك عبد العزيز':'جامعة الملك عبد العزيز','سنار - السودان':'جامعة سنار (السودان)',
}
DEGREE = {'ماجستير':'ماجستير','ماجستير موازي':'ماجستير','دكتوراه':'دكتوراه','دكتوراة':'دكتوراه','دكتزراه':'دكتوراه','الدكتوراة':'دكتوراه','الماجستير':'ماجستير'}
TOPIC = {'الموضوعات البينيّة':'الموضوعات البينية','الموضوعات البينية':'الموضوعات البينية','مناهج المُحدِّثين':'مناهج المحدثين','جهود المُحدِّثين':'جهود المحدثين'}
def norm_topic(t):
    t=t.strip(); return TOPIC.get(t,t)
def main(src):
    recs=json.load(open(src))
    out=[]; issues=[]
    for i,r in enumerate(recs):
        u=r['university'].strip(); d=r['degree'].strip(); t=norm_topic(r['topic'])
        rec=dict(r)
        rec['university_norm']=UNIV.get(u, u or 'غير محدد')
        rec['degree_norm']=DEGREE.get(d, 'غير محدد')
        rec['parallel']= 'موازي' in d
        rec['topic_norm']= t if t else 'غير مصنف'
        if u not in UNIV: issues.append((i, 'university', u, r['title'][:60]))
        if d not in DEGREE: issues.append((i, 'degree', d, r['title'][:60]))
        if not t: issues.append((i,'topic','', r['title'][:60]))
        out.append(rec)
    json.dump(out, open('data/theses_norm.json','w'), ensure_ascii=False, indent=1)
    with open('data/theses_norm.csv','w',newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(out[0].keys())); w.writeheader(); w.writerows(out)
    with open('data/normalization_issues.tsv','w') as f:
        for it in issues: f.write('\t'.join(str(x) for x in it)+'\n')
    print('records', len(out), 'issues', len(issues))
    print(collections.Counter(r['topic_norm'] for r in out).most_common())
if __name__=='__main__':
    main(sys.argv[1] if len(sys.argv)>1 else '../data/theses_all.json')
