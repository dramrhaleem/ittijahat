#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""حالة الأداة بين الجلسات (لبيئةٍ لا تحفظ الملفات، مثل ChatGPT): تصدير ما تغيّر في ملفٍ واحد، واستيراده في الجلسة التالية.

    python3 scripts/state.py export [--to /mnt/data]      # → حالة_الأداة_<التاريخ>.zip (data/ و out/ و packs/ و ocr/ — بلا ملفات PDF)
    python3 scripts/state.py import <حالة_الأداة_….zip>   # يفكّه فوق مجلد العمل (الأحدث يغلب)
    python3 scripts/state.py status                        # ما الذي سيُصدَّر وحجمه

القاعدة: في نهاية كل جلسة عملٍ (نقل، اعتماد، بطاقات، مبحث) صدِّر الحالة وسلّم الملف للباحث؛ وفي بداية الجلسة التالية استورده قبل أي أمر.
"""
import os, sys, zipfile, datetime, argparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
INCLUDE = ['data', 'out', 'packs', 'ocr', 'القرارات_المطلوبة.md']
EXCLUDE_EXT = {'.pdf'}


def files():
    for top in INCLUDE:
        if os.path.isfile(top):
            yield top
        for d, _, fs in os.walk(top):
            for f in fs:
                if os.path.splitext(f)[1].lower() in EXCLUDE_EXT or '__pycache__' in d:
                    continue
                yield os.path.join(d, f)


def cmd_export(a):
    name = f'حالة_الأداة_{datetime.date.today().isoformat()}.zip'
    dst = os.path.join(a.to or ROOT, name)
    n = 0
    with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in files():
            z.write(f, f); n += 1
    print(f'صُدِّرت الحالة: {dst} ({n} ملفًا، {os.path.getsize(dst) / 2**20:.1f} م.ب). سلّم هذا الملف للباحث ليرفعه في الجلسة التالية.')


def cmd_import(a):
    if not os.path.isfile(a.zip):
        sys.exit(f'الملف غير موجود: {a.zip}')
    n = 0
    with zipfile.ZipFile(a.zip) as z:
        for m in z.namelist():
            if m.endswith('/') or m.startswith(('/', '..')) or '..' in m.split('/'):
                continue
            z.extract(m, ROOT); n += 1
    print(f'استُوردت الحالة من {os.path.basename(a.zip)}: {n} ملفًا فوق مجلد العمل.')


def cmd_status(a):
    fs = list(files()); size = sum(os.path.getsize(f) for f in fs)
    print(f'{len(fs)} ملفًا سيُصدَّر ({size / 2**20:.1f} م.ب) من: ' + '، '.join(INCLUDE))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter); sp = ap.add_subparsers(dest='cmd')
    s = sp.add_parser('export'); s.add_argument('--to'); s.set_defaults(f=cmd_export)
    s = sp.add_parser('import'); s.add_argument('zip'); s.set_defaults(f=cmd_import)
    s = sp.add_parser('status'); s.set_defaults(f=cmd_status)
    a = ap.parse_args()
    if not a.cmd:
        ap.print_help(); return
    a.f(a)


if __name__ == '__main__':
    main()
