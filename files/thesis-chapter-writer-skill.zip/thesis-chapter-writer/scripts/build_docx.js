const fs = require('fs');
const path = require('path');
const d = require('docx');
const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, ImageRun,
        Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle, PageBreak,
        Header, Footer, PageNumber, convertInchesToTwip, FootnoteReferenceRun } = d;

// ---- الحواشي: تُكتب في الـMarkdown بصيغة ^[نصّ الحاشية] ----
const FOOTNOTES = {};
let fnCount = 0;
function splitFootnotes(text) {
  // يُرجع مصفوفة أجزاء: {t:'نص'} أو {fn:رقم}
  const parts = []; let buf = ''; let i = 0;
  while (i < text.length) {
    if (text[i] === '^' && text[i + 1] === '[') {
      let depth = 1, j = i + 2, note = '';
      while (j < text.length && depth > 0) {
        if (text[j] === '[') depth++;
        else if (text[j] === ']') { depth--; if (!depth) break; }
        note += text[j]; j++;
      }
      if (buf) { parts.push({ t: buf }); buf = ''; }
      fnCount++;
      FOOTNOTES[fnCount] = note.trim();
      parts.push({ fn: fnCount });
      i = j + 1; continue;
    }
    buf += text[i]; i++;
  }
  if (buf) parts.push({ t: buf });
  return parts;
}

// ---- التنسيق المعتمد: «قالب إثراء المتون للباحثين» (ملف القالب .dotx إصدار 2017) ----
// مستخرَج من أنماط القالب نفسها: المتن Traditional Arabic 18 مضبوطًا بالكشيدة الخفيفة، تباعد مفرد، قبل الفقرة 6 نقاط ·
// العنوان الأول PT Bold Heading 20 وسط · العنوان الثاني Sakkal Majalla 20 عريض · العنوان الثالث Traditional Arabic 18 عريض ·
// الحاشية Traditional Arabic 14 بإزاحة معلّقة · رقم الحاشية مرتفعًا بين قوسين · الصفحة A4 وهوامشها 2.54/2.54/2.5/2.5 سم ·
// رقم الصفحة في رأس الصفحة بين قوسين مع عنوان البحث، والصفحة الأولى بلا رأس. التفصيل في references/formatting.md
const FONT = 'Traditional Arabic';
const FONT_H1 = 'PT Bold Heading';
const FONT_H2 = 'Sakkal Majalla';
const FONT2 = 'Amiri';
const BODY_SIZE = 36;      // 18 نقطة
const FN_SIZE = 28;        // 14 نقطة
const TEXT_WIDTH = 9070;   // عرض النصّ بالتوِپ داخل هوامش القالب
const THESIS_TITLE = process.env.CH_TITLE || 'الاتجاهات الحديثية في العقد الرابع من القرن الخامس عشر الهجري في المملكة العربية السعودية';
const OUT = process.env.CH_OUT || 'skill/out/علل_الحديث';
const md = fs.readFileSync(process.env.CH_MD || 'out/ch1_ilal.md', 'utf8');

// العنصر النائب `[يوضع هنا الرسم البياني لـ…]` يُطابَق بأي صيغة تصف الرسم: الزمني/السنوات · الجامعات/المكاني · الدرجة · الموضوعي/الموضوعات
const CHART = [
  [/الزمني|السنوات|1431/,   'chart_years.png'],
  [/الجامعات|المكاني/,      'chart_universities.png'],
  [/الدرجة/,                'chart_degree.png'],
  [/الموضوع/,               'chart_topics.png'],
];
const CHART_SIZE = {
  'chart_years.png':        { width: 560, height: 286 },
  'chart_universities.png': { width: 520, height: 324 },
  'chart_degree.png':       { width: 320, height: 320 },
  'chart_topics.png':       { width: 560, height: 331 },
};

function rtl(opts) { return Object.assign({ bidirectional: true, alignment: AlignmentType.JUSTIFIED }, opts); }
function run(text, opts) {
  return new TextRun(Object.assign({ text, font: FONT, size: BODY_SIZE, rightToLeft: true }, opts || {}));
}
// **عريض** داخل السطر → run عريض؛ وأي نجمة أو علامة Markdown متبقّية تُحذف ولا تُطبع أبدًا
function inlineRuns(text, opts) {
  const out = [];
  const re = /\*\*(.+?)\*\*/g;
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(run(clean(text.slice(last, m.index)), opts));
    out.push(run(clean(m[1]), Object.assign({}, opts || {}, { bold: true })));
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push(run(clean(text.slice(last)), opts));
  return out;
}
function clean(t) {
  return t.replace(/\*\*/g, '').replace(/(^|\s)\*(?=\S)/g, '$1').replace(/(\S)\*(?=\s|$|[،.؛:])/g, '$1')
          .replace(/`/g, '');
}
function runsWithNotes(text, opts) {
  const parts = [];
  for (const p of splitFootnotes(text)) {
    if (p.fn) { parts.push(new TextRun({ text: '(', style: 'FootnoteReference' })); parts.push(new FootnoteReferenceRun(p.fn)); parts.push(new TextRun({ text: ')', style: 'FootnoteReference' })); }
    else parts.push(...inlineRuns(p.t, opts));
  }
  return parts;
}
function body(text) {
  return new Paragraph(rtl({
    children: runsWithNotes(text),
    alignment: AlignmentType.LOW_KASHIDA,
    spacing: { line: 240, before: 120, after: 0 },
    indent: { firstLine: convertInchesToTwip(0.3) },
  }));
}
function h1(text) {
  return new Paragraph({
    bidirectional: true, alignment: AlignmentType.CENTER,
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 240, after: 120 },
    children: [run(clean(text), { font: FONT_H1, size: 40 })],
  });
}
function h2(text) {
  return new Paragraph({
    bidirectional: true, alignment: AlignmentType.RIGHT,
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120 },
    children: [run(clean(text), { font: FONT_H2, bold: true, size: 40 })],
  });
}
function h3(text) {
  return new Paragraph({
    bidirectional: true, alignment: AlignmentType.RIGHT,
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 240, after: 120 },
    children: [run(clean(text), { bold: true, size: 36 })],
  });
}
function img(file) {
  const s = CHART_SIZE[file];
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER, spacing: { before: 160, after: 80 },
      children: [new ImageRun({ type: 'png', data: fs.readFileSync(path.join(OUT, file)),
                                transformation: { width: s.width, height: s.height } })],
    }),
  ];
}

// ---- parse markdown ----
const lines = md.split('\n');
const children = [];
let i = 0;
while (i < lines.length) {
  let L = lines[i];
  const t = L.trim();
  if (t === '' ) { i++; continue; }
  if (t === '---') { i++; continue; }
  // المستويات: `#` عنوان المبحث (h1 في الوسط) · `##` المطالب و«خلاصة المبحث» و«فهرس الرسائل» (h2 بخطّ سفلي)
  // · `###` العناصر: أولًا، ثانيًا… (h3). ويُقبل `### المطلب…` و`## عنوان فرعي للمبحث` من مسوّدات أقدم.
  if (t.startsWith('# ')) { children.push(h1(t.slice(2).trim())); i++; continue; }
  if (t.startsWith('## ')) {
    const txt = t.slice(3).trim();
    if (/^(المطلب|خلاصة المبحث|فهرس)/.test(txt)) children.push(h2(txt)); else children.push(h1(txt));
    i++; continue;
  }
  if (t.startsWith('### ')) {
    const txt = t.slice(4).trim();
    if (/^المطلب/.test(txt)) children.push(h2(txt)); else children.push(h3(txt));
    i++; continue;
  }
  if (t.startsWith('[يوضع هنا')) {
    const hit = CHART.find(([k]) => k.test(t));
    if (hit) { img(hit[1]).forEach(p => children.push(p)); }
    else { console.error('UNMATCHED CHART:', t); children.push(body(t)); }
    i++; continue;
  }
  if (t.startsWith('|')) {  // table
    const rows = [];
    while (i < lines.length && lines[i].trim().startsWith('|')) { rows.push(lines[i].trim()); i++; }
    const cells = rows.filter(r => !/^\|[\s\-|]+\|$/.test(r))
                      .map(r => r.slice(1, -1).split('|').map(c => c.trim()));
    const n = cells[0].length;
    const W = n === 6 ? [480, 3870, 1750, 1430, 830, 710]
            : n === 3 ? [2400, 830, 5840]
            : new Array(n).fill(Math.floor(TEXT_WIDTH / n));
    while (W.reduce((a, b) => a + b, 0) !== TEXT_WIDTH) W[W.length - 1] += TEXT_WIDTH - W.reduce((a, b) => a + b, 0);
    const tbl = new Table({
      columnWidths: W, width: { size: TEXT_WIDTH, type: WidthType.DXA }, visuallyRightToLeft: true,
      rows: cells.map((row, ri) => new TableRow({
        tableHeader: ri === 0,
        children: row.map((c, ci) => new TableCell({
          width: { size: W[ci], type: WidthType.DXA },
          shading: ri === 0 ? { type: ShadingType.CLEAR, fill: 'DEE6F2' } : undefined,
          margins: { top: 60, bottom: 60, left: 90, right: 90 },
          children: [new Paragraph({
            bidirectional: true,
            alignment: (row[ci] || '').length > 24 ? AlignmentType.RIGHT : AlignmentType.CENTER,
            spacing: { line: 260 },
            children: inlineRuns(c, { size: 26, bold: ri === 0 }),
          })],
        })),
      })),
    });
    children.push(tbl);
    children.push(new Paragraph({ spacing: { after: 200 }, children: [] }));
    continue;
  }
  // numbered plan items 1- 2- ...
  if (/^\d+-\s/.test(t)) {
    children.push(new Paragraph(rtl({
      children: runsWithNotes(t), spacing: { line: 240, before: 60, after: 0 },
      indent: { right: convertInchesToTwip(0.35) },
    })));
    i++; continue;
  }
  children.push(body(t));
  i++;
}

const footnotes = {};
for (const [id, txt] of Object.entries(FOOTNOTES)) {
  footnotes[id] = { children: [new Paragraph({
    bidirectional: true, alignment: AlignmentType.LOW_KASHIDA,
    spacing: { line: 240, before: 0, after: 0 },
    indent: { left: 340, hanging: 340 },
    children: inlineRuns(txt, { size: FN_SIZE }),
  })] };
}

const doc = new Document({
  footnotes,
  styles: {
    default: { document: { run: { font: FONT, size: BODY_SIZE, rightToLeft: true } } },
    characterStyles: [{ id: 'FootnoteReference', name: 'Footnote Reference', run: { font: FONT, size: 36, superScript: true } }],
    paragraphStyles: [{ id: 'FootnoteText', name: 'Footnote Text', run: { font: FONT, size: FN_SIZE }, paragraph: { spacing: { before: 0, after: 0, line: 240 } } }],
  },
  sections: [{
    properties: {
      // A4 وهوامش قالب إثراء المتون: أعلى وأسفل 2.54 سم، يمين ويسار 2.5 سم؛ والصفحة الأولى بلا رأس
      page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1418, right: 1418, header: 680, footer: 567 } },
      titlePage: true,
    },
    // رقم الصفحة في رأس الصفحة بين قوسين مع عنوان البحث — كما في القالب
    headers: {
      default: new Header({ children: [new Paragraph({
        bidirectional: true, alignment: AlignmentType.RIGHT,
        tabStops: [{ type: 'right', position: TEXT_WIDTH }],
        children: [run(THESIS_TITLE, { size: 28 }), new TextRun({ text: '\t', font: FONT, size: 28 }), run('(', { size: 28 }),
                   new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 28, rightToLeft: true }), run(')', { size: 28 })],
      })] }),
      first: new Header({ children: [new Paragraph({ children: [] })] }),
    },
    children,
  }],
});

// بعد البناء: رقم الحاشية في ذيل الصفحة بين قوسين أيضًا (كما في المتن) — يُعدَّل word/footnotes.xml في الملف الناتج
async function parenthesizeFootnoteNumbers(buf) {
  let JSZip;
  try { JSZip = require('jszip'); }
  catch (e) { JSZip = require(require.resolve('jszip', { paths: [path.dirname(require.resolve('docx')), path.join(path.dirname(require.resolve('docx')), '..', '..')] })); }
  const zip = await JSZip.loadAsync(buf);
  const f = zip.file('word/footnotes.xml');
  if (!f) return buf;
  let xml = await f.async('string');
  const re = /<w:r>(<w:rPr>(?:(?!<\/w:rPr>).)*<w:rStyle w:val="FootnoteReference"\/>(?:(?!<\/w:rPr>).)*<\/w:rPr>)<w:footnoteRef\/><\/w:r>/g;
  // لا تُمسّ حواشي الفاصل (separator/continuationSeparator)؛ الأقواس لحواشي النصّ وحدها
  xml = xml.replace(/<w:footnote w:id="(\d+)">([\s\S]*?)<\/w:footnote>/g, (whole, id, inner) =>
    `<w:footnote w:id="${id}">` + inner.replace(re, (m, rpr) => `<w:r>${rpr}<w:t>(</w:t></w:r>${m}<w:r>${rpr}<w:t xml:space="preserve">) </w:t></w:r>`) + '</w:footnote>');
  zip.file('word/footnotes.xml', xml);
  return zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
}
Packer.toBuffer(doc).then(async b => {
  const o = process.env.CH_DOCX || 'out/الفصل_الأول_المبحث_الثاني_علل_الحديث.docx';
  let out = b;
  try { out = await parenthesizeFootnoteNumbers(b); } catch (e) { console.error('تعذّر وضع أقواس أرقام الحواشي:', e.message); }
  fs.writeFileSync(o, out); console.log('written', o, out.length, '| حواشي:', Object.keys(FOOTNOTES).length);
});
