#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""استيراد بطاقات التحليل اليدوية (التي ملأها الباحث في Excel) إلى بطاقات JSON بوسم «تصنيف يدوي».

    python3 scripts/import_manual_cards.py materials/بطاقات_الباحث_اليدوية_الجرح_والتعديل.xlsx
    python3 scripts/import_manual_cards.py <ملف.xlsx> --mabhath "الجرح والتعديل"     # يفرض المبحث إن خلت البطاقة منه

كل ورقة في الملف بطاقة رسالة واحدة على بنية «بطاقة التحليل المعيارية» (بيانات تعريفية + عشرة بنود بثلاثة شواهد وحكم).
تُكتب في data/cards/<المبحث>/manual_<رقم>.json بالبنية نفسها التي تنتجها الأداة، مع:
  "source": "بطاقة الباحث اليدوية", "manual": true, "manual_sheet": "<اسم الورقة>", "list_match": {...}
ولا تُعدَّل بطاقة يدوية بعد استيرادها؛ وإن وُجدت بطاقة آلية للرسالة نفسها بقيتا معًا (اليدوية مقدَّمة عند التعارض).
"""
import sys, os, re, json, glob, argparse
from openpyxl import load_workbook

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
MABAHITH = ['الجرح والتعديل','علل الحديث','الاتصال والانقطاع','فقه الحديث','الناسخ والمنسوخ','مشكل الحديث','مختلف الحديث',
            'غريب الحديث','الحديث الموضوعي','مصطلح الحديث','تحقيق الكتب الحديثية','الحديث التحليلي','الموضوعات البينية',
            'الدفاع عن السنة','مناهج المحدثين','جهود المحدثين','الاستدراك الحديثي']
def strip_d(s): return re.sub(r'[ً-ْٰ]', '', str(s or ''))
def ntitle(s):
    s = strip_d(s); s = re.sub(r'[أإآ]', 'ا', s).replace('ة','ه').replace('ى','ي'); s = re.sub(r'[^\w\s]', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()
def canon(t):
    t = strip_d(t).strip()
    for m in MABAHITH:
        if strip_d(m) == t or strip_d(m) in t: return m
    return None
def sim(a, b):
    A, B = set(ntitle(a).split()), set(ntitle(b).split())
    return len(A & B) / max(1, len(A | B))

def parse_sheet(ws):
    rows = [[c for c in r] for r in ws.iter_rows(values_only=True)]
    if not rows: return None
    header = [str(h or '').strip() for h in rows[0]]
    def col(name):
        for i, h in enumerate(header):
            if name in h: return i
        return None
    c_sec, c_no, c_crit, c_ind, c_an = col('القسم'), col('رقم البند'), col('المعيار الرئيس'), (col('البند/') if col('البند/') is not None else col('المؤشر')), col('الوصف')
    c_e = [col('الشاهد 1'), col('الشاهد 2'), col('الشاهد 3')]; c_j = col('الحكم')
    if c_ind is None or c_an is None: return None
    meta = {}; items = []; notes = []
    for r in rows[1:]:
        if not any(v is not None for v in r): continue
        sec = str(r[c_sec] or '').strip() if c_sec is not None else ''
        ind = str(r[c_ind] or '').strip(); an = r[c_an]
        ev = [str(r[i]).strip() for i in c_e if i is not None and i < len(r) and r[i] not in (None, '')]
        jd = str(r[c_j]).strip() if c_j is not None and c_j < len(r) and r[c_j] not in (None, '') else ''
        if sec.startswith('المعيار') or (str(r[c_no] or '').strip().isdigit() and not sec.startswith(('البيانات','التصنيف','التوصيف','ملاحظات'))):
            try: no = int(str(r[c_no]).strip())
            except Exception: no = len(items) + 1
            items.append(dict(no=no, criterion=str(r[c_crit] or '').strip() if c_crit is not None else '', indicator=ind,
                              analysis=str(an or '').strip(), evidence=[dict(text=e, page=(re.search(r'ص\s*\(?\s*(\d+)', e).group(0) if re.search(r'ص\s*\(?\s*(\d+)', e) else '')) for e in ev],
                              judgment=jd))
        else:
            val = str(an or '').strip()
            if 'عنوان الرسالة' in ind: meta['title'] = val
            elif 'اسم الباحث' in ind: meta['researcher'] = val
            elif ind.startswith('الجامعة'): meta['university'] = val
            elif 'الكلية' in ind: meta['faculty_dept'] = val
            elif 'الدرجة' in ind: meta['degree'] = 'دكتوراه' if 'دكتور' in val else ('ماجستير' if 'ماجستير' in val else val)
            elif 'سنة' in ind:
                m = re.search(r'1[34]\d\d', val); meta['year_h'] = int(m.group()) if m else val
            elif 'عدد الصفحات' in ind:
                m = re.search(r'\d+', val); meta['pages'] = int(m.group()) if m else val
            elif 'لغة' in ind: meta['language'] = val
            elif 'التخصص' in ind: meta['specialization'] = val
            elif 'المبحث' in ind: meta['mabhath'] = canon(val)
            elif 'نوع الدراسة' in ind: meta['study_type'] = val
            elif 'المنهج المعتمد' in ind: meta['method_declared'] = val
            elif 'موضوع الرسالة' in ind: meta['short_topic'] = val
            elif 'توفر نسخة' in ind: meta['full_copy_available'] = val.startswith('نعم')
            elif 'ملاحظات' in ind: notes = [val] + ev
    meta['non_evaluative_notes'] = notes
    return dict(meta=meta, items=items)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('xlsx'); ap.add_argument('--mabhath', default=None); a = ap.parse_args()
    wb = load_workbook(a.xlsx, data_only=True)
    theses = json.load(open('data/theses_norm.json', encoding='utf-8'))
    codes = {}
    for f in glob.glob('data/samples/*.json'):
        for r in json.load(open(f, encoding='utf-8')): codes[ntitle(r['title'])] = r['code']
    written = []; skipped = []
    for n, name in enumerate(wb.sheetnames, 1):
        if name.strip() in ('Dashboard', 'Research Evaluation Matrix'): continue
        card = parse_sheet(wb[name])
        if not card or not card['meta'].get('title') or len(card['items']) < 5: skipped.append(name); continue
        m = card['meta']
        # مطابقة بالقائمة الشاملة
        best = max(theses, key=lambda t: sim(t['title'], m['title'])); s = sim(best['title'], m['title'])
        mab = m.get('mabhath') or a.mabhath or (canon(best['topic_norm']) if s >= 0.5 else None)
        if not mab: skipped.append(name + ' (بلا مبحث)'); continue
        match = dict(score=round(s, 2), list_title=best['title'], list_topic=best['topic_norm'], year=best['year']) if s >= 0.5 else dict(score=round(s, 2))
        code = codes.get(ntitle(best['title']), '') if s >= 0.5 else ''
        out = dict(code=code or f'manual_{n}', source='بطاقة الباحث اليدوية', manual=True, manual_sheet=name, list_match=match,
                   meta=dict(m, mabhath=mab), items=card['items'],
                   chapter_notes=dict(features=[], distinctions=[], critiques=[], quotable=[], key_results=[], recommendations=[]),
                   reading_coverage='بطاقة ملأها الباحث يدويًّا؛ لم تُقرأ الرسالة بالأداة.')
        d = os.path.join('data/cards', mab.replace(' ', '_')); os.makedirs(d, exist_ok=True)
        p = os.path.join(d, f'manual_{n:02d}.json'); json.dump(out, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        written.append((p, m['title'][:50], match.get('score'), match.get('list_topic', '—')))
    print(f'استُوردت {len(written)} بطاقة يدوية؛ وتُركت {len(skipped)}: {skipped}')
    for p, t, s, lt in written: print(f'  {p} | {t} | مطابقة القائمة {s} | مبحث القائمة: {lt}')
if __name__ == '__main__': main()
