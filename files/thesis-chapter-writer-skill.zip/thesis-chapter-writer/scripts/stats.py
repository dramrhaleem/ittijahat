# -*- coding: utf-8 -*-
"""إحصاءات المطلب الأول (التوصيف) لمبحث معيّن + الرسوم البيانية.
الاستخدام: python3 scripts/stats.py "علل الحديث" [--out out/ilal]
المخرجات: <out>/stats.json + <out>/chart_years.png, chart_universities.png, chart_degree.png, chart_topics.png (إن وُجد ملف التصنيف الموضوعي data/clusters/<slug>.json)
"""
import sys, json, os, collections, argparse, re, glob
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
try:
    import arabic_reshaper
    from bidi.algorithm import get_display
except ImportError:                                   # بيئة بلا pip (مثل ChatGPT): النسخ المشحونة في vendor/
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'vendor'))
    import arabic_reshaper
    from bidi.algorithm import get_display
from matplotlib import font_manager as fm
HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
# لا يعمل داخل مجلد السكيل (للقراءة فقط) — شغّل scripts/setup.py أولًا لينسخ الأداة إلى مجلد العمل
if any(k in ROOT.replace("\\", "/") for k in ("/.claude/", "/mnt/skills/", "/.agents/skills/", "/.codex/skills/")) or not os.access(ROOT, os.W_OK):
    sys.exit("هذا مجلد السكيل لا مجلد العمل. شغّل أولًا: python3 \"" + os.path.join(ROOT, "scripts", "setup.py") + "\"  ثم اعمل داخل عدة_كتابة_المباحث/")
PHASES=[('المرحلة الأولى',1431,1433),('المرحلة الوسطى',1434,1436),('المرحلة المتأخرة',1437,1440)]
def ar(s): return get_display(arabic_reshaper.reshape(str(s)))
def slug(name): return re.sub(r'\s+','_',name.strip())
def setup_font():
    # الخط مشحون مع الأداة (assets/fonts) فلا يعتمد على تثبيت النظام
    for ttf in glob.glob(os.path.join(ROOT,'assets','fonts','*.ttf')):
        try: fm.fontManager.addfont(ttf)
        except Exception: pass
    for cand in ['Amiri','Noto Naskh Arabic','KacstOne','DejaVu Sans']:
        if any(f.name==cand for f in fm.fontManager.ttflist):
            plt.rcParams['font.family']=cand; return cand
def pct(a,b): return round(100*a/b) if b else 0
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('mabhath'); ap.add_argument('--out',default=None); ap.add_argument('--data',default=os.path.join(ROOT,'data/theses_norm.json'))
    a=ap.parse_args()
    out=a.out or os.path.join(ROOT,'out',slug(a.mabhath)); os.makedirs(out,exist_ok=True)
    recs=[r for r in json.load(open(a.data)) if r['topic_norm']==a.mabhath]
    n=len(recs)
    by_year=collections.OrderedDict((y,0) for y in range(1431,1441))
    for r in recs: by_year[r['year']]+=1
    phases=[]
    for name,s,e in PHASES:
        cnt=sum(by_year[y] for y in range(s,e+1)); phases.append(dict(name=name,start=s,end=e,count=cnt,pct=pct(cnt,n),years={y:by_year[y] for y in range(s,e+1)}))
    by_univ=collections.Counter(r['university_norm'] for r in recs).most_common()
    by_deg=collections.Counter(r['degree_norm'] for r in recs)
    deg_year={y:{'ماجستير':0,'دكتوراه':0} for y in by_year}
    for r in recs:
        if r['degree_norm'] in deg_year[r['year']]: deg_year[r['year']][r['degree_norm']]+=1
    by_gender=collections.Counter(r['gender'] for r in recs)
    # التوصيف المنهجي من العناوين بعد توحيد الرسم — لا يُحسب من رأس الكاتب
    def normt(t):
        t=re.sub(r'[\u064B-\u0652\u0670\u0640]','',t or ''); t=re.sub(r'[أإآ]','ا',t)
        return t.replace('ى','ي').replace('ة','ه').replace('ؤ','و').replace('ئ','ي')
    # الصيغ المنهجية كما ترد في العناوين؛ «المصرِّحة» ما طابق عنوانها صيغةً منها (لا كل عنوان فيه لفظ «دراسة»:
    # فـ«مع دراسة مروياتهم» وصفٌ للنطاق لا تصريحٌ بالمنهج). وقد يجتمع في العنوان الواحد أكثر من صيغة.
    METHOD_TERMS=[('جمعًا ودراسة',r'جمع\w*(?:\s+و\w+)*\s+و\s*دراس'),('نظرية تطبيقية',r'نظري\w*\s+و?\s*تطبيقي'),
                  ('دراسة تطبيقية',r'(?<!نظريه\s)دراسه\s+تطبيقي'),('دراسة تحليلية',r'تحليلي'),('دراسة نقدية',r'نقدي'),
                  ('دراسة موازنة',r'موازن'),('عرضًا ودراسة',r'عرض\w*\s+و\s*دراس'),('نقدًا ودراسة',r'نقد\w*\s+و\s*دراس'),
                  ('عرض ونقد',r'عرض\w*\s+و\s*نقد'),('تخريجًا ودراسة',r'تخريج\w*\s+و\s*دراس'),('دراسة وتحقيق',r'تحقيق'),
                  ('استقرائية',r'استقرا'),('وصفية',r'وصفي')]
    terms=collections.OrderedDict(); declared=0
    for r in recs:
        nt=normt(r['title']); hit=False
        for label,rx in METHOD_TERMS:
            if re.search(rx,nt): terms[label]=terms.get(label,0)+1; hit=True
        declared+=hit
    method_desc=dict(declared=declared,silent=n-declared,declared_pct=pct(declared,n),silent_pct=pct(n-declared,n),
                     terms=collections.OrderedDict(sorted(terms.items(),key=lambda kv:-kv[1])),
                     definition='المصرِّحة: ما طابق عنوانها صيغةً منهجية (جمعًا ودراسة، نظرية تطبيقية، دراسة تطبيقية، تحليلية، نقدية، موازنة، عرضًا ودراسة، نقدًا ودراسة، عرض ونقد، تخريجًا ودراسة، تحقيق، استقرائية، وصفية) بعد توحيد الرسم؛ والساكتة ما خلا منها. ومجرد لفظ «دراسة» في وصف النطاق («مع دراسة مروياتهم») لا يُعدّ تصريحًا. وقد يجتمع في العنوان الواحد أكثر من صيغة.')
    ymax=max(by_year,key=by_year.get); ymin=min(by_year,key=by_year.get)
    stats=dict(mabhath=a.mabhath,total=n,mean_per_year=round(n/10,1),mean_per_year_int=round(n/10),by_year=by_year,phases=phases,method_desc=method_desc,
               max_year=ymax,max_count=by_year[ymax],min_year=ymin,min_count=by_year[ymin],
               by_university=[dict(name=u,count=c,pct=pct(c,n)) for u,c in by_univ],
               top2_pct=pct(sum(c for _,c in by_univ[:2]),n),
               by_degree=dict(by_deg),degree_by_year=deg_year,by_gender=dict(by_gender),
               theses=[dict(year=r['year'],title=r['title'],researcher=r['researcher'],university=r['university_norm'],degree=r['degree_norm'],availability=r['availability']) for r in sorted(recs,key=lambda r:(r['year'],r['title']))])
    # clusters
    cl_path=os.path.join(ROOT,'data/clusters',slug(a.mabhath)+'.json')
    if os.path.exists(cl_path):
        cl=json.load(open(cl_path))  # {cluster_name: [title,...]} or {title: cluster}
        if all(isinstance(v,list) for v in cl.values()):
            t2c={t:c for c,ts in cl.items() for t in ts}
        else: t2c=cl
        cc=collections.Counter(t2c.get(r['title'],'غير مصنف') for r in recs)
        stats['clusters']=[dict(name=k,count=v,pct=pct(v,n)) for k,v in cc.most_common()]
        stats['unclustered']=[r['title'] for r in recs if r['title'] not in t2c]
        if stats['unclustered']:
            print(f"⚠️  {len(stats['unclustered'])} رسالة بلا محور في التصنيف — الشرط: مجموع المحاور = {n} بالضبط", file=sys.stderr)
    else:
        print(f"⚠️  لا تصنيف موضوعي بعد: أنشئ data/clusters/{slug(a.mabhath)}.json (كل عنوان في محور واحد، ومجموع المحاور = {n}) ثم أعد التشغيل لبناء chart_topics.png", file=sys.stderr)
    json.dump(stats,open(os.path.join(out,'stats.json'),'w'),ensure_ascii=False,indent=1)
    # charts
    font=setup_font(); plt.rcParams['font.size']=12
    def bar(labels,vals,title,fname,rot=0,color='#4a6fa5',figsize=(8,4.5)):
        fig,ax=plt.subplots(figsize=figsize,dpi=200)
        xs=range(len(vals)); ax.bar(xs,vals,color=color)
        ax.set_xticks(list(xs)); ax.set_xticklabels([ar(l) for l in labels],rotation=rot,ha='right' if rot else 'center')
        for i,v in enumerate(vals): ax.text(i,v+max(vals)*0.01,str(v),ha='center',va='bottom',fontsize=11)
        ax.set_title(ar(title),fontsize=14); ax.spines[['top','right']].set_visible(False); ax.set_ylim(0,max(vals)*1.15 if vals else 1)
        fig.tight_layout(); fig.savefig(os.path.join(out,fname)); plt.close(fig)
    bar([f'{y}هـ' for y in by_year],list(by_year.values()),f'التوزيع الزمني لرسائل {a.mabhath} (1431–1440هـ)','chart_years.png')
    bar([u for u,_ in by_univ],[c for _,c in by_univ],f'توزيع رسائل {a.mabhath} على الجامعات','chart_universities.png',rot=35,figsize=(10,5.5))
    fig,ax=plt.subplots(figsize=(5,5),dpi=200)
    labs=['ماجستير','دكتوراه']; vals=[by_deg.get('ماجستير',0),by_deg.get('دكتوراه',0)]
    ax.pie(vals,labels=[ar(f'{l} ({v})') for l,v in zip(labs,vals)],autopct='%1.0f%%',colors=['#4a6fa5','#c9a227'],startangle=90,textprops={'fontsize':12})
    ax.set_title(ar(f'توزيع رسائل {a.mabhath} بحسب الدرجة العلمية'),fontsize=13); fig.tight_layout(); fig.savefig(os.path.join(out,'chart_degree.png')); plt.close(fig)
    if 'clusters' in stats:
        bar([c['name'] for c in stats['clusters']],[c['count'] for c in stats['clusters']],f'التوزيع الموضوعي لرسائل {a.mabhath}','chart_topics.png',rot=30,figsize=(10,6),color='#7a9e7e')
    print(json.dumps({k:stats[k] for k in ('total','mean_per_year','by_year','by_degree','top2_pct')},ensure_ascii=False))
    print('method_desc:',dict(declared=method_desc['declared'],silent=method_desc['silent']),dict(method_desc['terms']))
    print('universities:',[(u['name'],u['count'],u['pct']) for u in stats['by_university']])
    print('phases:',[(p['name'],p['count'],p['pct']) for p in phases])
    if 'clusters' in stats: print('clusters:',[(c['name'],c['count']) for c in stats['clusters']], 'unclustered:',len(stats['unclustered']))
if __name__=='__main__': main()
