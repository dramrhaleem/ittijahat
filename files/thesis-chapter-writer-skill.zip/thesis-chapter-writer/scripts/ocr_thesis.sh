#!/bin/bash
# OCR لرسالة ليس فيها طبقة نص صالحة. الاستخدام: ocr_thesis.sh <ملف.pdf> <مجلد المخرج> [عدد المعالجات]
# يبدأ بالصفحات المهمة (المقدمة والخاتمة وعيّنات المتن) ثم يكمل الباقي.
set -e
PDF="$1"; OUT="$2"; JOBS="${3:-2}"
N=$(pdfinfo "$PDF" | awk '/^Pages/{print $2}')
mkdir -p "$OUT"
{
  seq 1 45
  seq $((N-34)) $N
  for f in 25 45 65 85; do s=$((46 + (N-81)*f/100)); seq $s $((s+5)); done
  seq 1 $N
} | awk '!seen[$0]++' | awk -v n="$N" '$1>=1 && $1<=n' > "$OUT/.queue"
if ! tesseract --list-langs 2>/dev/null | grep -qx ara; then echo "⚠️  حزمة العربية للتعرّف الضوئي غير مركّبة (tesseract-ocr-ara) — شغّل scripts/setup.py"; exit 2; fi
export OMP_THREAD_LIMIT=1
cat "$OUT/.queue" | xargs -P "$JOBS" -I{} bash -c '
  p={}; f=$(printf "%s/p_%04d" "'"$OUT"'" "$p")
  [ -s "$f.txt" ] && exit 0
  pdftoppm -f $p -l $p -r 200 -gray -png "'"$PDF"'" "$f.tmp" >/dev/null 2>&1
  img=$(ls $f.tmp*.png 2>/dev/null | head -1); [ -z "$img" ] && exit 0
  tesseract "$img" "$f" -l ara --psm 6 >/dev/null 2>&1; rm -f $f.tmp*.png'
NONEMPTY=$(find "$OUT" -name 'p_*.txt' -size +20c 2>/dev/null | wc -l)
EMPTY=$(( $(ls $OUT/p_*.txt 2>/dev/null | wc -l) - NONEMPTY ))
echo "تمّ: $NONEMPTY صفحة أخرجت نصًّا من $N — وفارغة: $EMPTY"
if [ "$NONEMPTY" -eq 0 ]; then echo "⚠️  لم يخرج نصٌّ من أي صفحة. تحقّق من حزمة العربية: tesseract --list-langs (يلزم ara)"; exit 2; fi
