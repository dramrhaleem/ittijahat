# -*- coding: utf-8 -*-
"""بناء «حزمة القراءة» لرسالة واحدة من نصوص صفحاتها (ocr/theses/<code>/p_XXXX.txt)
الاستخدام: python3 scripts/reading_pack.py <code> --pages-dir <dir> --out <dir> [--front 45] [--windows 4] [--win-size 6]
المخرجات: pack_front.txt, pack_toc.txt, pack_body.txt, pack_end.txt, pagemap.json
"""
import os, re, sys, json, argparse, glob, unicodedata
AR_DIG = str.maketrans('٠١٢٣٤٥٦٧٨٩','0123456789')
def load_pages(d):
    files=sorted(glob.glob(os.path.join(d,'p_*.txt')))
    pages={}
    for f in files:
        i=int(re.search(r'p_(\d+)\.txt',f).group(1)); pages[i]=open(f,encoding='utf-8',errors='replace').read()
    return pages
def printed_number(text):
    """يحاول التقاط رقم الصفحة المطبوع من أول/آخر سطور الصفحة"""
    lines=[l.strip() for l in text.split('\n') if l.strip()]
    cands=lines[:2]+lines[-2:]
    for l in cands:
        m=re.fullmatch(r'[\(\[]?\s*([0-9٠-٩]{1,4})\s*[\)\]]?', l)
        if m:
            n=int(m.group(1).translate(AR_DIG))
            if 0<n<3000: return n
    for l in cands:
        if len(l.split())<=9:
            m=re.match(r'^[\(\[]?\s*([0-9٠-٩]{1,4})\s*[\)\]]?\s+\S', l) or re.search(r'\S\s+[\(\[]?\s*([0-9٠-٩]{1,4})\s*[\)\]]?$', l)
            if m:
                n=int(m.group(1).translate(AR_DIG))
                if 0<n<3000: return n
    return None
def build_pagemap(pages):
    pm={}
    for i,t in pages.items():
        pm[i]=printed_number(t)
    # offset voting: printed - index
    from collections import Counter
    offs=Counter(pm[i]-i for i in pm if pm[i] is not None)
    off=offs.most_common(1)[0][0] if offs else None
    conf=offs.most_common(1)[0][1]/max(1,len(pages)) if offs else 0
    return pm, off, conf
def label(i, pm, off):
    p=pm.get(i)
    if p is None and off is not None: p=i+off; est='~'
    else: est=''
    return f"[PDF {i} | ص {est}{p if p is not None else '?'}]"
def find_heading(pages, pattern, start_frac=0.0, end_frac=1.0):
    n=max(pages); res=[]
    for i in sorted(pages):
        if i < n*start_frac or i > n*end_frac: continue
        for l in [x for x in pages[i].split('\n') if x.strip()][:8]:
            s=re.sub('[ـ\u200c\u200d]','',l.strip())
            s=re.sub(r'^[\W_]+|[\W_]+$','',s)
            if re.fullmatch(pattern, s): res.append(i); break
    return res
def khatima_from_toc(pages, pm, off):
    """يستخرج رقم صفحة الخاتمة من فهرس الموضوعات ثم يحوله إلى فهرس PDF"""
    n=max(pages)
    for i in sorted(pages, reverse=True):
        for l in pages[i].split('\n'):
            s=re.sub('[ـ\u200c\u200d\.…]+',' ',l)
            if re.search(r'(^|\s)الخاتمة(\s|$)', s):
                nums=[int(x.translate(AR_DIG)) for x in re.findall(r'[0-9٠-٩]{2,4}', s)]
                nums=[x for x in nums if x<n+500]
                if nums:
                    printed=nums[-1]
                    # ابحث عن صفحة رقمها المطبوع = printed
                    for j,p in pm.items():
                        if p==printed and j>n*0.5: return j
                    if off is not None and n*0.5 < printed-off <= n: return printed-off
    return None
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('code'); ap.add_argument('--pages-dir',required=True); ap.add_argument('--out',required=True)
    ap.add_argument('--front',type=int,default=45); ap.add_argument('--windows',type=int,default=4); ap.add_argument('--win-size',type=int,default=6); ap.add_argument('--end',type=int,default=35); ap.add_argument('--offset',type=int,default=None,help='فرض فرق ثابت بين رقم PDF والرقم المطبوع'); ap.add_argument('--khatima',type=int,default=None,help='فرض رقم صفحة PDF التي تبدأ عندها الخاتمة')
    a=ap.parse_args()
    pages=load_pages(a.pages_dir); n=max(pages); os.makedirs(a.out,exist_ok=True)
    pm,off,conf=build_pagemap(pages)
    if a.offset is not None: off=a.offset; conf=1.0; pm={i:None for i in pm}
    # خاتمة
    khat=find_heading(pages, r'(الخاتمة|الخامتة|اخلامتة|اخلاتمة|الخاتمه|خاتمة|خامتة|خاتمة البحث|خامتة البحث|الخاتمة والنتائج|الخامتة وأهم نتائج البحث|الخاتمة وأهم نتائج البحث|الخاتمة وفيها أهم النتائج والتوصيات|الخامتة وفيها أهم النتائج والتوصيات|أهم النتائج|نتائج البحث|الخاتمة: النتائج والتوصيات|الخامتة: النتائج والتوصيات)', 0.55, 1.0)
    toc=find_heading(pages, r'(فهرس الموضوعات|فهرس المحتويات|المحتويات|الفهرس|فهرس محتويات|فهرس الموضوعات والمحتويات|قائمة المحتويات|محتويات الرسالة)', 0.0, 1.0)
    if a.khatima: khat=[a.khatima]
    if not khat:
        k=khatima_from_toc(pages, pm, off)
        if k: khat=[k]
    def dump(fname, idxs, title):
        with open(os.path.join(a.out,fname),'w') as f:
            f.write(f"##### {title} — {a.code} — عدد صفحات الملف: {n}\n")
            for i in idxs:
                if i in pages:
                    f.write(f"\n===== {label(i,pm,off)} =====\n{pages[i].strip()}\n")
    front=list(range(1,min(a.front,n)+1))
    dump('pack_front.txt', front, 'المقدمة والصفحات الأولى')
    toc_pages=[]
    if toc:
        t0=toc[-1]; toc_pages=list(range(t0, min(t0+12,n)+1))
    else:
        toc_pages=list(range(max(1,n-14), n+1))
    dump('pack_toc.txt', toc_pages, 'فهرس الموضوعات (أو الصفحات الأخيرة)')
    if khat:
        k0=khat[0]; end_pages=list(range(k0, min(k0+a.end,n)+1))
    else:
        end_pages=list(range(max(1,n-a.end), n+1))
    dump('pack_end.txt', end_pages, 'الخاتمة والنتائج والتوصيات')
    body_s, body_e = a.front+1, (khat[0]-1 if khat else n-a.end)
    wins=[]
    for k in range(a.windows):
        frac=(k+0.5)/a.windows; s=int(body_s+(body_e-body_s)*frac); wins+=list(range(s,s+a.win_size))
    dump('pack_body.txt', wins, 'عيّنات من متن الرسالة')
    json.dump(dict(code=a.code,n_pages=n,offset=off,offset_confidence=round(conf,2),khatima_pages=khat,toc_pages=toc,front=front[-1],body_windows=wins,end_pages=[end_pages[0],end_pages[-1]],pagemap={i:pm[i] for i in pm}),open(os.path.join(a.out,'pagemap.json'),'w'),ensure_ascii=False)
    sizes={f:os.path.getsize(os.path.join(a.out,f)) for f in os.listdir(a.out)}
    print(a.code, 'pages',n,'offset',off,'conf',round(conf,2),'khatima',khat[-3:],'toc',toc[-3:],'sizes',sizes)
if __name__=='__main__': main()
