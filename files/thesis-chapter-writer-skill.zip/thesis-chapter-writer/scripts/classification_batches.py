#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""تجهيز دفعات مراجعة التصنيف للوكلاء: يقسّم رسائل القائمة إلى ملفات JSON في out/تصنيف/in/ (نحو 200 رسالة للدفعة).

    python3 scripts/classification_batches.py            # الدفعات كلها (المباحث الكبيرة تُقسَّم)
    python3 scripts/classification_batches.py --mabhath "علل الحديث"   # دفعة لمبحث واحد

ثم لكل دفعة وكيلٌ فرعيّ يقرأ out/تصنيف/in/تعليمات_المراجعة.md ويكتب out/تصنيف/review_<الدفعة>.json،
ثم python3 scripts/classification_report.py يجمع المخرجات في التقرير والنسخة المعلَّمة والعدّادات.
"""
import json, os, re, glob, collections, argparse
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
def strip(s): return re.sub(r'[ً-ْٰ]', '', s or '')
ap = argparse.ArgumentParser(); ap.add_argument('--mabhath'); ap.add_argument('--size', type=int, default=200); a = ap.parse_args()
d = json.load(open('data/theses_norm.json', encoding='utf-8'))
code = {}
for f in glob.glob('data/samples/*.json'):
    for r in json.load(open(f, encoding='utf-8')): code[r['title']] = r['code']
rows = []; pos = collections.Counter()
for r in d:
    pos[r['year']] += 1
    rows.append(dict(id=f"{r['year']}/{pos[r['year']]}", code=code.get(r['title'], ''), title=r['title'], current=strip(r['topic_norm'])))
os.makedirs('out/تصنيف/in', exist_ok=True)
import shutil; shutil.copy('references/review-instructions.md', 'out/تصنيف/in/تعليمات_المراجعة.md')
by = collections.defaultdict(list)
for x in rows: by[x['current']].append(x)
if a.mabhath:
    sel = by.get(strip(a.mabhath), []); p = f"out/تصنيف/in/g_{strip(a.mabhath).replace(' ', '_')}.json"
    json.dump(sel, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=0); print(p, len(sel))
else:
    small = []; n = 0
    for m, v in sorted(by.items(), key=lambda kv: -len(kv[1])):
        if len(v) > a.size * 0.6:
            for i in range(0, len(v), a.size):
                n += 1; p = f"out/تصنيف/in/g{n}_{m.replace(' ', '_')}_{i//a.size+1}.json"; json.dump(v[i:i+a.size], open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=0); print(p, len(v[i:i+a.size]))
        else: small += v
    for i in range(0, len(small), a.size):
        n += 1; p = f"out/تصنيف/in/g{n}_متفرقة_{i//a.size+1}.json"; json.dump(small[i:i+a.size], open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=0); print(p, len(small[i:i+a.size]))
print('المجموع', len(rows))
